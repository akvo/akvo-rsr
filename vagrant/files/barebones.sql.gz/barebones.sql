-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: rsr
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
INSERT INTO `auth_group` VALUES (1,'RSR editors'),(2,'RSR users'),(3,'RSR partner admins'),(4,'RSR partner editors'),(5,'SMS updater'),(6,'SMS manager'),(7,'RSR managers');
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_425ae3c4` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=605 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
INSERT INTO `auth_group_permissions` VALUES (553,1,106),(552,1,98),(551,1,97),(550,1,96),(549,1,347),(548,1,346),(547,1,345),(546,1,344),(545,1,343),(544,1,342),(543,1,213),(542,1,212),(541,1,339),(540,1,210),(539,1,209),(538,1,78),(537,1,77),(536,1,76),(535,1,75),(534,1,74),(533,1,73),(532,1,72),(531,1,71),(530,1,70),(529,1,66),(32,2,64),(33,2,37),(579,3,346),(578,3,345),(577,3,344),(576,3,343),(575,3,342),(574,3,213),(573,3,212),(572,3,339),(571,3,210),(601,4,346),(600,4,340),(599,4,105),(556,1,211),(559,1,341),(528,1,65),(527,1,64),(570,3,335),(512,7,338),(511,7,200),(510,7,208),(509,7,207),(508,7,206),(507,7,205),(506,7,204),(505,7,203),(504,7,202),(503,7,201),(502,7,328),(501,7,327),(569,3,334),(568,3,333),(567,3,75),(566,3,74),(565,3,329),(564,3,71),(563,3,70),(582,3,105),(558,1,340),(555,1,108),(562,3,73),(561,3,34),(560,3,214),(598,4,214),(597,4,213),(596,4,212),(595,4,339),(594,4,210),(593,4,335),(592,4,334),(591,4,333),(590,4,75),(589,4,74),(581,3,95),(557,1,83),(554,1,107),(588,4,73),(587,4,71),(586,4,70),(500,7,326),(499,7,337),(498,7,336),(526,1,42),(525,1,41),(524,1,40),(523,1,39),(522,1,38),(521,1,37),(520,1,36),(519,1,35),(518,1,34),(517,1,8),(580,3,347),(516,1,214),(513,7,334),(514,7,333),(515,7,335),(583,3,109),(584,3,340),(585,3,341),(602,4,347),(603,4,345),(604,4,341);
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_message`
--

DROP TABLE IF EXISTS `auth_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_message_403f60f` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2153 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_message`
--

LOCK TABLES `auth_message` WRITE;
/*!40000 ALTER TABLE `auth_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=390 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add message',1,'add_message'),(2,'Can change message',1,'change_message'),(3,'Can delete message',1,'delete_message'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add permission',4,'add_permission'),(11,'Can change permission',4,'change_permission'),(12,'Can delete permission',4,'delete_permission'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add log entry',8,'add_logentry'),(23,'Can change log entry',8,'change_logentry'),(24,'Can delete log entry',8,'delete_logentry'),(34,'Can add project',12,'add_project'),(35,'Can change project',12,'change_project'),(36,'Can delete project',12,'delete_project'),(37,'Can add project update',13,'add_projectupdate'),(38,'Can change project update',13,'change_projectupdate'),(39,'Can delete project update',13,'delete_projectupdate'),(40,'Can add organisation',14,'add_organisation'),(41,'Can change organisation',14,'change_organisation'),(42,'Can delete organisation',14,'delete_organisation'),(98,'Can delete organisation account',34,'delete_organisationaccount'),(97,'Can change organisation account',34,'change_organisationaccount'),(95,'RSR limited change organisation',14,'rsr_limited_change_organisation'),(96,'Can add organisation account',34,'add_organisationaccount'),(64,'Can add project comment',22,'add_projectcomment'),(65,'Can change project comment',22,'change_projectcomment'),(66,'Can delete project comment',22,'delete_projectcomment'),(70,'Can add country',24,'add_country'),(71,'Can change country',24,'change_country'),(72,'Can delete country',24,'delete_country'),(73,'Can add link',25,'add_link'),(74,'Can change link',25,'change_link'),(75,'Can delete link',25,'delete_link'),(76,'Can add registration profile',26,'add_registrationprofile'),(77,'Can change registration profile',26,'change_registrationprofile'),(78,'Can delete registration profile',26,'delete_registrationprofile'),(104,'Can delete pay pal ipn',32,'delete_paypalipn'),(103,'Can change pay pal ipn',32,'change_paypalipn'),(102,'Can add pay pal ipn',32,'add_paypalipn'),(82,'Can add user profile',28,'add_userprofile'),(83,'Can change user profile',28,'change_userprofile'),(84,'Can delete user profile',28,'delete_userprofile'),(105,'RSR limited change project',12,'rsr_limited_change_project'),(106,'Can add publishing status',35,'add_publishingstatus'),(107,'Can change publishing status',35,'change_publishingstatus'),(108,'Can delete publishing status',35,'delete_publishingstatus'),(109,'RSR limited change user profile',28,'rsr_limited_change_userprofile'),(197,'Can add focus area',47,'add_focusarea'),(198,'Can change focus area',47,'change_focusarea'),(199,'Can delete focus area',47,'delete_focusarea'),(200,'Can add benchmark name',48,'add_benchmarkname'),(201,'Can change benchmark name',48,'change_benchmarkname'),(202,'Can delete benchmark name',48,'delete_benchmarkname'),(203,'Can add category',49,'add_category'),(204,'Can change category',49,'change_category'),(205,'Can delete category',49,'delete_category'),(206,'Can add MiniCMS',44,'add_minicms'),(207,'Can change MiniCMS',44,'change_minicms'),(208,'Can delete MiniCMS',44,'delete_minicms'),(209,'Can add benchmark',46,'add_benchmark'),(210,'Can change benchmark',46,'change_benchmark'),(211,'Can delete benchmark',46,'delete_benchmark'),(212,'Can add Budget item',36,'add_budgetitem'),(213,'Can change Budget item',36,'change_budgetitem'),(214,'Can delete Budget item',36,'delete_budgetitem'),(215,'RSR limited change budget',36,'rsr_limited_change_budget'),(219,'Can add sms reporter',64,'add_smsreporter'),(220,'Can change sms reporter',64,'change_smsreporter'),(221,'Can delete sms reporter',64,'delete_smsreporter'),(222,'RSR limited change sms reporter',64,'rsr_limited_change_smsreporter'),(223,'Can add PayPal gateway',40,'add_paypalgateway'),(224,'Can change PayPal gateway',40,'change_paypalgateway'),(225,'Can delete PayPal gateway',40,'delete_paypalgateway'),(226,'Can add Mollie/iDEAL gateway',41,'add_molliegateway'),(227,'Can change Mollie/iDEAL gateway',41,'change_molliegateway'),(228,'Can delete Mollie/iDEAL gateway',41,'delete_molliegateway'),(229,'Can add Project payment gateway configuration',42,'add_paymentgatewayselector'),(230,'Can change Project payment gateway configuration',42,'change_paymentgatewayselector'),(231,'Can delete Project payment gateway configuration',42,'delete_paymentgatewayselector'),(232,'Can add invoice',43,'add_invoice'),(233,'Can change invoice',43,'change_invoice'),(234,'Can delete invoice',43,'delete_invoice'),(235,'Can add gateway',65,'add_gateway'),(236,'Can change gateway',65,'change_gateway'),(237,'Can delete gateway',65,'delete_gateway'),(238,'Can add gateway number',66,'add_gatewaynumber'),(239,'Can change gateway number',66,'change_gatewaynumber'),(240,'Can delete gateway number',66,'delete_gatewaynumber'),(241,'Can add mo sms',67,'add_mosms'),(242,'Can change mo sms',67,'change_mosms'),(243,'Can delete mo sms',67,'delete_mosms'),(244,'Can add PayPal IPN',39,'add_paypalipn'),(245,'Can change PayPal IPN',39,'change_paypalipn'),(246,'Can delete PayPal IPN',39,'delete_paypalipn'),(247,'Can add View Counter',51,'add_viewcounter'),(248,'Can change View Counter',51,'change_viewcounter'),(249,'Can delete View Counter',51,'delete_viewcounter'),(250,'Can add Download Counter',68,'add_redircounter'),(251,'Can change Download Counter',68,'change_redircounter'),(252,'Can delete Download Counter',68,'delete_redircounter'),(253,'Can add Referer',69,'add_referer'),(254,'Can change Referer',69,'change_referer'),(255,'Can delete Referer',69,'delete_referer'),(256,'Can add stored OEmbed',70,'add_storedoembed'),(257,'Can change stored OEmbed',70,'change_storedoembed'),(258,'Can delete stored OEmbed',70,'delete_storedoembed'),(259,'Can add stored provider',50,'add_storedprovider'),(260,'Can change stored provider',50,'change_storedprovider'),(261,'Can delete stored provider',50,'delete_storedprovider'),(262,'Can add aggregate media',71,'add_aggregatemedia'),(263,'Can change aggregate media',71,'change_aggregatemedia'),(264,'Can delete aggregate media',71,'delete_aggregatemedia'),(265,'Can add notice type',72,'add_noticetype'),(266,'Can change notice type',72,'change_noticetype'),(267,'Can delete notice type',72,'delete_noticetype'),(268,'Can add notice setting',73,'add_noticesetting'),(269,'Can change notice setting',73,'change_noticesetting'),(270,'Can delete notice setting',73,'delete_noticesetting'),(271,'Can add notice',74,'add_notice'),(272,'Can change notice',74,'change_notice'),(273,'Can delete notice',74,'delete_notice'),(274,'Can add notice queue batch',75,'add_noticequeuebatch'),(275,'Can change notice queue batch',75,'change_noticequeuebatch'),(276,'Can delete notice queue batch',75,'delete_noticequeuebatch'),(277,'Can add observed item',76,'add_observeditem'),(278,'Can change observed item',76,'change_observeditem'),(279,'Can delete observed item',76,'delete_observeditem'),(280,'Can add permission',77,'add_permission'),(281,'Can change permission',77,'change_permission'),(282,'Can delete permission',77,'delete_permission'),(283,'Can add object permission',78,'add_objectpermission'),(284,'Can change object permission',78,'change_objectpermission'),(285,'Can delete object permission',78,'delete_objectpermission'),(286,'Can add object permission inheritance block',79,'add_objectpermissioninheritanceblock'),(287,'Can change object permission inheritance block',79,'change_objectpermissioninheritanceblock'),(288,'Can delete object permission inheritance block',79,'delete_objectpermissioninheritanceblock'),(289,'Can add role',80,'add_role'),(290,'Can change role',80,'change_role'),(291,'Can delete role',80,'delete_role'),(292,'Can add principal role relation',81,'add_principalrolerelation'),(293,'Can change principal role relation',81,'change_principalrolerelation'),(294,'Can delete principal role relation',81,'delete_principalrolerelation'),(295,'Can add workflow',82,'add_workflow'),(296,'Can change workflow',82,'change_workflow'),(297,'Can delete workflow',82,'delete_workflow'),(298,'Can add state',83,'add_state'),(299,'Can change state',83,'change_state'),(300,'Can delete state',83,'delete_state'),(301,'Can add transition',84,'add_transition'),(302,'Can change transition',84,'change_transition'),(303,'Can delete transition',84,'delete_transition'),(304,'Can add state object relation',85,'add_stateobjectrelation'),(305,'Can change state object relation',85,'change_stateobjectrelation'),(306,'Can delete state object relation',85,'delete_stateobjectrelation'),(307,'Can add workflow object relation',86,'add_workflowobjectrelation'),(308,'Can change workflow object relation',86,'change_workflowobjectrelation'),(309,'Can delete workflow object relation',86,'delete_workflowobjectrelation'),(310,'Can add workflow model relation',87,'add_workflowmodelrelation'),(311,'Can change workflow model relation',87,'change_workflowmodelrelation'),(312,'Can delete workflow model relation',87,'delete_workflowmodelrelation'),(313,'Can add workflow permission relation',88,'add_workflowpermissionrelation'),(314,'Can change workflow permission relation',88,'change_workflowpermissionrelation'),(315,'Can delete workflow permission relation',88,'delete_workflowpermissionrelation'),(316,'Can add state inheritance block',89,'add_stateinheritanceblock'),(317,'Can change state inheritance block',89,'change_stateinheritanceblock'),(318,'Can delete state inheritance block',89,'delete_stateinheritanceblock'),(319,'Can add state permission relation',90,'add_statepermissionrelation'),(320,'Can change state permission relation',90,'change_statepermissionrelation'),(321,'Can delete state permission relation',90,'delete_statepermissionrelation'),(326,'Can add partner site',92,'add_partnersite'),(327,'Can change partner site',92,'change_partnersite'),(328,'Can delete partner site',92,'delete_partnersite'),(329,'RSR limited change partnersite',92,'rsr_limited_change_partnersite'),(330,'Can add migration history',93,'add_migrationhistory'),(331,'Can change migration history',93,'change_migrationhistory'),(332,'Can delete migration history',93,'delete_migrationhistory'),(333,'Can add Project partner',94,'add_partnership'),(334,'Can change Project partner',94,'change_partnership'),(335,'Can delete Project partner',94,'delete_partnership'),(336,'Can add budget item label',95,'add_budgetitemlabel'),(337,'Can change budget item label',95,'change_budgetitemlabel'),(338,'Can delete budget item label',95,'delete_budgetitemlabel'),(339,'Can add goal',96,'add_goal'),(340,'Can change goal',96,'change_goal'),(341,'Can delete goal',96,'delete_goal'),(342,'Can add organisation location',97,'add_organisationlocation'),(343,'Can change organisation location',97,'change_organisationlocation'),(344,'Can delete organisation location',97,'delete_organisationlocation'),(345,'Can add project location',98,'add_projectlocation'),(346,'Can change project location',98,'change_projectlocation'),(347,'Can delete project location',98,'delete_projectlocation'),(348,'Can add api access',99,'add_apiaccess'),(349,'Can change api access',99,'change_apiaccess'),(350,'Can delete api access',99,'delete_apiaccess'),(351,'Can add api key',100,'add_apikey'),(352,'Can change api key',100,'change_apikey'),(353,'Can delete api key',100,'delete_apikey'),(354,'Can add task state',101,'add_taskmeta'),(355,'Can change task state',101,'change_taskmeta'),(356,'Can delete task state',101,'delete_taskmeta'),(357,'Can add saved group result',102,'add_tasksetmeta'),(358,'Can change saved group result',102,'change_tasksetmeta'),(359,'Can delete saved group result',102,'delete_tasksetmeta'),(360,'Can add interval',103,'add_intervalschedule'),(361,'Can change interval',103,'change_intervalschedule'),(362,'Can delete interval',103,'delete_intervalschedule'),(363,'Can add crontab',104,'add_crontabschedule'),(364,'Can change crontab',104,'change_crontabschedule'),(365,'Can delete crontab',104,'delete_crontabschedule'),(366,'Can add periodic tasks',105,'add_periodictasks'),(367,'Can change periodic tasks',105,'change_periodictasks'),(368,'Can delete periodic tasks',105,'delete_periodictasks'),(369,'Can add periodic task',106,'add_periodictask'),(370,'Can change periodic task',106,'change_periodictask'),(371,'Can delete periodic task',106,'delete_periodictask'),(372,'Can add worker',107,'add_workerstate'),(373,'Can change worker',107,'change_workerstate'),(374,'Can delete worker',107,'delete_workerstate'),(375,'Can add task',108,'add_taskstate'),(376,'Can change task',108,'change_taskstate'),(377,'Can delete task',108,'delete_taskstate'),(378,'Can add queue',109,'add_queue'),(379,'Can change queue',109,'change_queue'),(380,'Can delete queue',109,'delete_queue'),(381,'Can add message',110,'add_message'),(382,'Can change message',110,'change_message'),(383,'Can delete message',110,'delete_message'),(384,'Can add internal organisation id',111,'add_internalorganisationid'),(385,'Can change internal organisation id',111,'change_internalorganisationid'),(386,'Can delete internal organisation id',111,'delete_internalorganisationid'),(387,'Can add partner type',112,'add_partnertype'),(388,'Can change partner type',112,'change_partnertype'),(389,'Can delete partner type',112,'delete_partnertype');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=1182 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1181,'akvodev','','','akvodev@akvo.org','pbkdf2_sha256$10000$tQS4T8vJAE16$RabaUiTm7z81GdGKKY1wl+/F3IKouCQkjEXIjr8f4LY=',1,1,1,'2013-07-09 09:40:35','2013-07-09 09:38:25');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_403f60f` (`user_id`),
  KEY `auth_user_groups_425ae3c4` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=961 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
INSERT INTO `auth_user_groups` VALUES (960,1181,7),(959,1181,6),(958,1181,5),(957,1181,4),(956,1181,3),(955,1181,2),(954,1181,1);
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_403f60f` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=527 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` VALUES (283,1181,3),(282,1181,2),(281,1181,1),(313,1181,42),(312,1181,41),(311,1181,40),(310,1181,39),(309,1181,38),(308,1181,37),(307,1181,36),(306,1181,35),(301,1181,21),(300,1181,20),(299,1181,19),(298,1181,18),(297,1181,17),(296,1181,16),(295,1181,15),(294,1181,14),(293,1181,13),(292,1181,12),(291,1181,11),(290,1181,10),(289,1181,9),(288,1181,8),(287,1181,7),(286,1181,6),(285,1181,5),(321,1181,74),(320,1181,73),(319,1181,72),(318,1181,71),(305,1181,34),(304,1181,24),(303,1181,23),(302,1181,22),(317,1181,70),(316,1181,66),(315,1181,65),(314,1181,64),(284,1181,4),(322,1181,75),(323,1181,76),(324,1181,77),(325,1181,78),(326,1181,82),(327,1181,83),(328,1181,84),(329,1181,95),(330,1181,96),(331,1181,97),(332,1181,98),(333,1181,102),(334,1181,103),(335,1181,104),(336,1181,105),(337,1181,106),(338,1181,107),(339,1181,108),(340,1181,109),(341,1181,197),(342,1181,198),(343,1181,199),(344,1181,200),(345,1181,201),(346,1181,202),(347,1181,203),(348,1181,204),(349,1181,205),(350,1181,206),(351,1181,207),(352,1181,208),(353,1181,209),(354,1181,210),(355,1181,211),(356,1181,212),(357,1181,213),(358,1181,214),(359,1181,215),(360,1181,219),(361,1181,220),(362,1181,221),(363,1181,222),(364,1181,223),(365,1181,224),(366,1181,225),(367,1181,226),(368,1181,227),(369,1181,228),(370,1181,229),(371,1181,230),(372,1181,231),(373,1181,232),(374,1181,233),(375,1181,234),(376,1181,235),(377,1181,236),(378,1181,237),(379,1181,238),(380,1181,239),(381,1181,240),(382,1181,241),(383,1181,242),(384,1181,243),(385,1181,244),(386,1181,245),(387,1181,246),(388,1181,247),(389,1181,248),(390,1181,249),(391,1181,250),(392,1181,251),(393,1181,252),(394,1181,253),(395,1181,254),(396,1181,255),(397,1181,256),(398,1181,257),(399,1181,258),(400,1181,259),(401,1181,260),(402,1181,261),(403,1181,262),(404,1181,263),(405,1181,264),(406,1181,265),(407,1181,266),(408,1181,267),(409,1181,268),(410,1181,269),(411,1181,270),(412,1181,271),(413,1181,272),(414,1181,273),(415,1181,274),(416,1181,275),(417,1181,276),(418,1181,277),(419,1181,278),(420,1181,279),(421,1181,280),(422,1181,281),(423,1181,282),(424,1181,283),(425,1181,284),(426,1181,285),(427,1181,286),(428,1181,287),(429,1181,288),(430,1181,289),(431,1181,290),(432,1181,291),(433,1181,292),(434,1181,293),(435,1181,294),(436,1181,295),(437,1181,296),(438,1181,297),(439,1181,298),(440,1181,299),(441,1181,300),(442,1181,301),(443,1181,302),(444,1181,303),(445,1181,304),(446,1181,305),(447,1181,306),(448,1181,307),(449,1181,308),(450,1181,309),(451,1181,310),(452,1181,311),(453,1181,312),(454,1181,313),(455,1181,314),(456,1181,315),(457,1181,316),(458,1181,317),(459,1181,318),(460,1181,319),(461,1181,320),(462,1181,321),(463,1181,326),(464,1181,327),(465,1181,328),(466,1181,329),(467,1181,330),(468,1181,331),(469,1181,332),(470,1181,333),(471,1181,334),(472,1181,335),(473,1181,336),(474,1181,337),(475,1181,338),(476,1181,339),(477,1181,340),(478,1181,341),(479,1181,342),(480,1181,343),(481,1181,344),(482,1181,345),(483,1181,346),(484,1181,347),(485,1181,348),(486,1181,349),(487,1181,350),(488,1181,351),(489,1181,352),(490,1181,353),(491,1181,354),(492,1181,355),(493,1181,356),(494,1181,357),(495,1181,358),(496,1181,359),(497,1181,360),(498,1181,361),(499,1181,362),(500,1181,363),(501,1181,364),(502,1181,365),(503,1181,366),(504,1181,367),(505,1181,368),(506,1181,369),(507,1181,370),(508,1181,371),(509,1181,372),(510,1181,373),(511,1181,374),(512,1181,375),(513,1181,376),(514,1181,377),(515,1181,378),(516,1181,379),(517,1181,380),(518,1181,381),(519,1181,382),(520,1181,383),(521,1181,384),(522,1181,385),(523,1181,386),(524,1181,387),(525,1181,388),(526,1181,389);
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `celery_taskmeta`
--

DROP TABLE IF EXISTS `celery_taskmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `celery_taskmeta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `result` longtext,
  `date_done` datetime NOT NULL,
  `traceback` longtext,
  `hidden` tinyint(1) NOT NULL,
  `meta` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `celery_taskmeta_c91f1bf` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `celery_taskmeta`
--

LOCK TABLES `celery_taskmeta` WRITE;
/*!40000 ALTER TABLE `celery_taskmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `celery_taskmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `celery_tasksetmeta`
--

DROP TABLE IF EXISTS `celery_tasksetmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `celery_tasksetmeta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskset_id` varchar(255) NOT NULL,
  `result` longtext NOT NULL,
  `date_done` datetime NOT NULL,
  `hidden` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `taskset_id` (`taskset_id`),
  KEY `celery_tasksetmeta_c91f1bf` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `celery_tasksetmeta`
--

LOCK TABLES `celery_tasksetmeta` WRITE;
/*!40000 ALTER TABLE `celery_tasksetmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `celery_tasksetmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_403f60f` (`user_id`),
  KEY `django_admin_log_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24136 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'message','auth','message'),(2,'group','auth','group'),(3,'user','auth','user'),(4,'permission','auth','permission'),(5,'content type','contenttypes','contenttype'),(6,'session','sessions','session'),(7,'site','sites','site'),(8,'log entry','admin','logentry'),(12,'project','rsr','project'),(13,'project update','rsr','projectupdate'),(14,'organisation','rsr','organisation'),(16,'link','feedjack','link'),(17,'site','feedjack','site'),(18,'feed','feedjack','feed'),(19,'tag','feedjack','tag'),(20,'post','feedjack','post'),(21,'subscriber','feedjack','subscriber'),(22,'project comment','rsr','projectcomment'),(24,'country','rsr','country'),(25,'link','rsr','link'),(26,'registration profile','registration','registrationprofile'),(28,'user profile','rsr','userprofile'),(32,'PayPal IPN','standard','paypalipn'),(34,'organisation account','rsr','organisationaccount'),(35,'publishing status','rsr','publishingstatus'),(36,'budget item','rsr','budgetitem'),(39,'PayPal IPN','ipn','paypalipn'),(40,'PayPal gateway','rsr','paypalgateway'),(41,'Mollie/iDEAL gateway','rsr','molliegateway'),(42,'Project payment gateway configuration','rsr','paymentgatewayselector'),(43,'invoice','rsr','invoice'),(44,'MiniCMS','rsr','minicms'),(46,'benchmark','rsr','benchmark'),(47,'focus area','rsr','focusarea'),(48,'benchmark name','rsr','benchmarkname'),(49,'category','rsr','category'),(50,'stored provider','oembed','storedprovider'),(51,'View Counter','django_counter','viewcounter'),(64,'sms reporter','rsr','smsreporter'),(65,'gateway','gateway','gateway'),(66,'gateway number','gateway','gatewaynumber'),(67,'mo sms','gateway','mosms'),(68,'Download Counter','django_counter','redircounter'),(69,'Referer','django_counter','referer'),(70,'stored OEmbed','oembed','storedoembed'),(71,'aggregate media','oembed','aggregatemedia'),(72,'notice type','notification','noticetype'),(73,'notice setting','notification','noticesetting'),(74,'notice','notification','notice'),(75,'notice queue batch','notification','noticequeuebatch'),(76,'observed item','notification','observeditem'),(77,'permission','permissions','permission'),(78,'object permission','permissions','objectpermission'),(79,'object permission inheritance block','permissions','objectpermissioninheritanceblock'),(80,'role','permissions','role'),(81,'principal role relation','permissions','principalrolerelation'),(82,'workflow','workflows','workflow'),(83,'state','workflows','state'),(84,'transition','workflows','transition'),(85,'state object relation','workflows','stateobjectrelation'),(86,'workflow object relation','workflows','workflowobjectrelation'),(87,'workflow model relation','workflows','workflowmodelrelation'),(88,'workflow permission relation','workflows','workflowpermissionrelation'),(89,'state inheritance block','workflows','stateinheritanceblock'),(90,'state permission relation','workflows','statepermissionrelation'),(92,'partner site','rsr','partnersite'),(93,'migration history','south','migrationhistory'),(94,'Project partner','rsr','partnership'),(95,'budget item label','rsr','budgetitemlabel'),(96,'goal','rsr','goal'),(97,'organisation location','rsr','organisationlocation'),(98,'project location','rsr','projectlocation'),(99,'api access','tastypie','apiaccess'),(100,'api key','tastypie','apikey'),(101,'task state','djcelery','taskmeta'),(102,'saved group result','djcelery','tasksetmeta'),(103,'interval','djcelery','intervalschedule'),(104,'crontab','djcelery','crontabschedule'),(105,'periodic tasks','djcelery','periodictasks'),(106,'periodic task','djcelery','periodictask'),(107,'worker','djcelery','workerstate'),(108,'task','djcelery','taskstate'),(109,'queue','django','queue'),(110,'message','django','message'),(111,'internal organisation id','rsr','internalorganisationid'),(112,'partner type','rsr','partnertype');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_counter_redircounter`
--

DROP TABLE IF EXISTS `django_counter_redircounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_counter_redircounter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `url` varchar(255) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_counter_redircounter`
--

LOCK TABLES `django_counter_redircounter` WRITE;
/*!40000 ALTER TABLE `django_counter_redircounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_counter_redircounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_counter_referer`
--

DROP TABLE IF EXISTS `django_counter_referer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_counter_referer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `counter_id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  `update_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_counter_referer_7952d08b` (`counter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_counter_referer`
--

LOCK TABLES `django_counter_referer` WRITE;
/*!40000 ALTER TABLE `django_counter_referer` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_counter_referer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_counter_viewcounter`
--

DROP TABLE IF EXISTS `django_counter_viewcounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_counter_viewcounter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`object_id`),
  KEY `django_counter_viewcounter_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4858 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_counter_viewcounter`
--

LOCK TABLES `django_counter_viewcounter` WRITE;
/*!40000 ALTER TABLE `django_counter_viewcounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_counter_viewcounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_3da3d3d8` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('07f1936007ceff8476c7ac45eed76555','ZTVmYzkzODQwNmNhZTE1NTY4Y2MxMmI4YTQ1OGI2NDg1OWFkYTQyNDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQSKAp0EdS4=\n','2013-07-23 09:40:35');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=207 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'www.akvo.org','www.akvo.org'),(2,'test.akvo.org','test.akvo.org'),(3,'test2.akvo.org','test2.akvo.org'),(4,'gabriel.akvo.org','gabriel.akvo.org'),(5,'daniel.akvo.org','daniel.akvo.org'),(6,'paul.akvo.org','paul.akvo.org'),(7,'demo.akvo.org','demo.akvo.org'),(8,'uat.akvo.org','uat.akvo.org'),(9,'akvo.org','akvo.org'),(10,'akvo.akvoapp.org','akvo.akvoapp.org'),(11,'wash.simavi.nl','wash.simavi.nl'),(12,'undp.akvoapp.org','undp.akvoapp.org'),(13,'connect4change.akvoapp.org','connect4change.akvoapp.org'),(14,'liveearth.akvoapp.org','liveearth.akvoapp.org'),(15,'simavi.akvoapp.org','simavi.akvoapp.org'),(16,'impulsis.akvoapp.org','impulsis.akvoapp.org'),(17,'walkingforwater.akvoapp.org','walkingforwater.akvoapp.org'),(18,'washalliance.akvoapp.org','washalliance.akvoapp.org'),(19,'sujol.akvoapp.org','sujol.akvoapp.org'),(20,'wandelenvoorwater.akvoapp.org','wandelenvoorwater.akvoapp.org'),(21,'commonsites.akvoapp.org','commonsites.akvoapp.org'),(22,'blog.akvo.org','blog.akvo.org'),(23,'projects.iicd.org','projects.iicd.org'),(24,'aqua4all.akvoapp.org','aqua4all.akvoapp.org'),(25,'projects.connect4change.nl','projects.connect4change.nl'),(26,'rain.akvoapp.org','rain.akvoapp.org'),(27,'projecten.aquaforall.nl','projecten.aquaforall.nl'),(28,'greenadsblue.akvoapp.org','greenadsblue.akvoapp.org'),(29,'projects.earthwater.nl','projects.earthwater.nl'),(30,'projects.commonsites.net','projects.commonsites.net'),(31,'gkp.akvoapp.org','gkp.akvoapp.org'),(32,'redticbolivia.akvoapp.org','redticbolivia.akvoapp.org'),(33,'forum.akvo.org','forum.akvo.org'),(34,'earthwater.akvoapp.org','earthwater.akvoapp.org'),(35,'rabobank.akvoapp.org','rabobank.akvoapp.org'),(36,'iicd.akvoapp.org','iicd.akvoapp.org'),(37,'mars.akvoapp.org','mars.akvoapp.org'),(38,'www.prfektkontor.akvoapp.org','www.prfektkontor.akvoapp.org'),(39,'www.undp.akvoapp.org','www.undp.akvoapp.org'),(40,'prfektkontor.akvoapp.org','prfektkontor.akvoapp.org'),(41,'marsnaff.akvoapp.org','marsnaff.akvoapp.org'),(42,'www.sujol.akvoapp.org','www.sujol.akvoapp.org'),(43,'texttochange.akvoapp.org','texttochange.akvoapp.org'),(44,'usaid.akvoapp.org','usaid.akvoapp.org'),(45,'edukans.akvoapp.org','edukans.akvoapp.org'),(46,'cordaid.akvoapp.org','cordaid.akvoapp.org'),(47,'pumpaid.akvoapp.org','pumpaid.akvoapp.org'),(48,'parade.akvoapp.org','parade.akvoapp.org'),(49,'helderwater.akvoapp.org','helderwater.akvoapp.org'),(50,'waste.akvoapp.org','waste.akvoapp.org'),(51,'rotary.akvoapp.org','rotary.akvoapp.org'),(52,'dance4life.akvoapp.org','dance4life.akvoapp.org'),(53,'www.mars.akvoapp.org','www.mars.akvoapp.org'),(54,'designtest.akvoapp.org','designtest.akvoapp.org'),(55,'worldcoaches.akvoapp.org','worldcoaches.akvoapp.org'),(56,'waterforlife.akvoapp.org','waterforlife.akvoapp.org'),(57,'www.gkp.akvoapp.org','www.gkp.akvoapp.org'),(58,'www.connect4change.akvoapp.org','www.connect4change.akvoapp.org'),(59,'www.rabobank.akvoapp.org','www.rabobank.akvoapp.org'),(60,'leidenarch.akvoapp.org','leidenarch.akvoapp.org'),(61,'mlambe.akvoapp.org','mlambe.akvoapp.org'),(62,'www.simavi.akvoapp.org','www.simavi.akvoapp.org'),(63,'www.earthwater.akvoapp.org','www.earthwater.akvoapp.org'),(64,'www.liveearth.akvoapp.org','www.liveearth.akvoapp.org'),(65,'evides.akvoapp.org','evides.akvoapp.org'),(66,'vei.akvoapp.org','vei.akvoapp.org'),(67,'vitens.akvoapp.org','vitens.akvoapp.org'),(68,'vitensevidesinternational.akvoapp.org','vitensevidesinternational.akvoapp.org'),(69,'vjnns.akvoapp.org','vjnns.akvoapp.org'),(70,'www.impulsis.akvoapp.org','www.impulsis.akvoapp.org'),(71,'www.aqua4all.akvoapp.org','www.aqua4all.akvoapp.org'),(72,'sendadrop.akvoapp.org','sendadrop.akvoapp.org'),(73,'www.sendadrop.akvoapp.org','www.sendadrop.akvoapp.org'),(74,'www.akvo.akvoapp.org','www.akvo.akvoapp.org'),(75,'www.rain.akvoapp.org','www.rain.akvoapp.org'),(76,'nagafoundation.akvoapp.org','nagafoundation.akvoapp.org'),(77,'www.nagafoundation.akvoapp.org','www.nagafoundation.akvoapp.org'),(78,'waterbedrijfgroningen.akvoapp.org','waterbedrijfgroningen.akvoapp.org'),(79,'www.waterbedrijfgroningen.akvoapp.org','www.waterbedrijfgroningen.akvoapp.org'),(80,'www.redticbolivia.akvoapp.org','www.redticbolivia.akvoapp.org'),(81,'wiki.akvo.org','wiki.akvo.org'),(82,'www.blog.akvo.org','www.blog.akvo.org'),(83,'www.greenadsblue.akvoapp.org','www.greenadsblue.akvoapp.org'),(84,'www.ucmb.akvoapp.org','www.ucmb.akvoapp.org'),(85,'www.evides.akvoapp.org','www.evides.akvoapp.org'),(86,'startwithwater.akvoapp.org','startwithwater.akvoapp.org'),(87,'www.startwithwater.akvoapp.org','www.startwithwater.akvoapp.org'),(88,'unicefnl.akvoapp.org','unicefnl.akvoapp.org'),(89,'www.unicefnl.akvoapp.org','www.unicefnl.akvoapp.org'),(90,'www.washalliance.akvoapp.org','www.washalliance.akvoapp.org'),(91,'www.iicd.akvoapp.org','www.iicd.akvoapp.org'),(92,'www.dance4life.akvoapp.org','www.dance4life.akvoapp.org'),(93,'www.amref.akvoapp.org','www.amref.akvoapp.org'),(94,'www.edukans.akvoapp.org','www.edukans.akvoapp.org'),(95,'www.texttochange.akvoapp.org','www.texttochange.akvoapp.org'),(96,'www.commonsites.akvoapp.org','www.commonsites.akvoapp.org'),(97,'www.greengraffiti.akvoapp.org','www.greengraffiti.akvoapp.org'),(98,'www.usaid.akvoapp.org','www.usaid.akvoapp.org'),(99,'www.cordaid.akvoapp.org','www.cordaid.akvoapp.org'),(100,'www.rotary.akvoapp.org','www.rotary.akvoapp.org'),(101,'www.waste.akvoapp.org','www.waste.akvoapp.org'),(102,'www.helderwater.akvoapp.org','www.helderwater.akvoapp.org'),(103,'www.parade.akvoapp.org','www.parade.akvoapp.org'),(104,'www.one.akvoapp.org','www.one.akvoapp.org'),(105,'www.openaid.akvoapp.org','www.openaid.akvoapp.org'),(106,'openaid.akvoapp.org','openaid.akvoapp.org'),(107,'www.wandelenvoorwater.akvoapp.org','www.wandelenvoorwater.akvoapp.org'),(108,'www.walkingforwater.akvoapp.org','www.walkingforwater.akvoapp.org'),(109,'www.worldcoaches.akvoapp.org','www.worldcoaches.akvoapp.org'),(110,'www.memisa.akvoapp.org','www.memisa.akvoapp.org'),(111,'www.oceanfdn.akvoapp.org','www.oceanfdn.akvoapp.org'),(112,'www.cisco.akvoapp.org','www.cisco.akvoapp.org'),(113,'www.waterforpeople.akvoapp.org','www.waterforpeople.akvoapp.org'),(114,'www.wash-united.akvoapp.org','www.wash-united.akvoapp.org'),(115,'www.mwawater.akvoapp.org','www.mwawater.akvoapp.org'),(116,'www.marsnaff.akvoapp.org','www.marsnaff.akvoapp.org'),(117,'www.waterforlife.akvoapp.org','www.waterforlife.akvoapp.org'),(118,'www.leidenarch.akvoapp.org','www.leidenarch.akvoapp.org'),(119,'www.mlambe.akvoapp.org','www.mlambe.akvoapp.org'),(120,'www.vitensevidesinternational.akvoapp.org','www.vitensevidesinternational.akvoapp.org'),(121,'www.vitens.akvoapp.org','www.vitens.akvoapp.org'),(122,'ucmb.akvoapp.org','ucmb.akvoapp.org'),(123,'www.unicef.akvoapp.org','www.unicef.akvoapp.org'),(124,'ghanaf4w.akvoapp.org','ghanaf4w.akvoapp.org'),(125,'kenyaf4w.akvoapp.org','kenyaf4w.akvoapp.org'),(126,'mozambiquef4w.akvoapp.org','mozambiquef4w.akvoapp.org'),(127,'owa.akvoapp.org','owa.akvoapp.org'),(128,'www.owa.akvoapp.org','www.owa.akvoapp.org'),(129,'hivgaps.akvoapp.org','hivgaps.akvoapp.org'),(130,'wash-united.akvoapp.org','wash-united.akvoapp.org'),(131,'greengraffiti.akvoapp.org','greengraffiti.akvoapp.org'),(132,'texttochangec4c.akvoapp.org','texttochangec4c.akvoapp.org'),(133,'unesco-ihr.akvoapp.org','unesco-ihr.akvoapp.org'),(134,'unesco-ihe.akvoapp.org','unesco-ihe.akvoapp.org'),(135,'projects.texttochange.org','projects.texttochange.org'),(136,'projectsc4c.texttochange.org','projectsc4c.texttochange.org'),(137,'amref.akvoapp.org','amref.akvoapp.org'),(138,'spa.akvoapp.org','spa.akvoapp.org'),(139,'www.spa.akvoapp.org','www.spa.akvoapp.org'),(140,'www.texttochangec4c.akvoapp.org','www.texttochangec4c.akvoapp.org'),(141,'www.kenyaf4w.akvoapp.org','www.kenyaf4w.akvoapp.org'),(142,'minbuza.akvoapp.org','minbuza.akvoapp.org'),(143,'walkingforwater2013.akvoapp.org','walkingforwater2013.akvoapp.org'),(144,'wandelenvoorwater2013.akvoapp.org','wandelenvoorwater2013.akvoapp.org'),(145,'my.ebay.de, uotcuzvy.typepad.com, us.linkedin.com, www.therelaxationcompany.com, bvsqyfvesnk.cd1350.','my.ebay.de, uotcuzvy.typepad.com, us.linkedin.com,'),(146,'www.gamespot.com, supergaia.com, www.templatehelp.com, mapas.guiamais.com.br, subscribe.ru, www.tvtr','www.gamespot.com, supergaia.com, www.templatehelp.'),(147,'akvodemo.akvoapp.org','akvodemo.akvoapp.org'),(148,'act.akvoapp.org','act.akvoapp.org'),(149,'dailybooth.com, budlybni.blogspot.com, tsc.edu.my, sports.yahoo.com, www.85broads.com, cgi.idealo.de','dailybooth.com, budlybni.blogspot.com, tsc.edu.my,'),(150,'www.thebookmyfriend.com, com.reversephonewhitepages.qirina.com, katy-bourne.com, c.actiondesk.com, w','www.thebookmyfriend.com, com.reversephonewhitepage'),(151,'www.comune.nuoro.it, oauth.vkontakte.ru, hegicodenii.88n.eu, xxsweetbutterfly.a-lsawards.com, wantit','www.comune.nuoro.it, oauth.vkontakte.ru, hegicoden'),(152,'projects.leidenarch.akvoapp.org','projects.leidenarch.akvoapp.org'),(153,'nsa.akvoapp.org','nsa.akvoapp.org'),(154,'nexusheritage.akvoapp.org','nexusheritage.akvoapp.org'),(155,'memisa.akvoapp.org','memisa.akvoapp.org'),(156,'agentschapnl.akvoapp.org','agentschapnl.akvoapp.org'),(157,'50745d79b4d436.22471038.undp.akvoapp.org','50745d79b4d436.22471038.undp.akvoapp.org'),(158,'webmail.commonsites.akvoapp.org','webmail.commonsites.akvoapp.org'),(159,'webmail.gkp.akvoapp.org','webmail.gkp.akvoapp.org'),(160,'webmail.iicd.akvoapp.org','webmail.iicd.akvoapp.org'),(161,'webmail.impulsis.akvoapp.org','webmail.impulsis.akvoapp.org'),(162,'webmail.rain.akvoapp.org','webmail.rain.akvoapp.org'),(163,'webmail.redticbolivia.akvoapp.org','webmail.redticbolivia.akvoapp.org'),(164,'webmail.simavi.akvoapp.org','webmail.simavi.akvoapp.org'),(165,'webmail.sujol.akvoapp.org','webmail.sujol.akvoapp.org'),(166,'webmail.undp.akvoapp.org','webmail.undp.akvoapp.org'),(167,'webmail.walkingforwater.akvoapp.org','webmail.walkingforwater.akvoapp.org'),(168,'webmail.wandelenvoorwater.akvoapp.org','webmail.wandelenvoorwater.akvoapp.org'),(169,'webmail.washalliance.akvoapp.org','webmail.washalliance.akvoapp.org'),(170,'projects.archaeology.leiden.edu','projects.archaeology.leiden.edu'),(171,'un-habitat.akvoapp.org','un-habitat.akvoapp.org'),(172,'www.ghanaf4w.akvoapp.org','www.ghanaf4w.akvoapp.org'),(173,'ecom.akvoapp.org','ecom.akvoapp.org'),(174,'knvb.akvoapp.org','knvb.akvoapp.org'),(175,'righttoplay.akvoapp.org','righttoplay.akvoapp.org'),(176,'www.ecom.akvoapp.org','www.ecom.akvoapp.org'),(177,'snvkenya.akvoapp.org','snvkenya.akvoapp.org'),(178,'www.righttoplay.akvoapp.org','www.righttoplay.akvoapp.org'),(179,'undp.akvoapp.orgnwww.undp.akvoapp.org','undp.akvoapp.orgnwww.undp.akvoapp.org'),(180,'www.wandelenvoorwater2013.akvoapp.org','www.wandelenvoorwater2013.akvoapp.org'),(181,'gatesfoundation.akvoapp.org','gatesfoundation.akvoapp.org'),(182,'sportfordevelopment.akvoapp.org','sportfordevelopment.akvoapp.org'),(183,'projects.projectafrica.com','projects.projectafrica.com'),(184,'mwawater.akvoapp.org','mwawater.akvoapp.org'),(185,'projects.sportfordevelopment.nl','projects.sportfordevelopment.nl'),(186,'www.walkingforwater2013.akvoapp.org','www.walkingforwater2013.akvoapp.org'),(187,'philipsafricaroadshow.akvoapp.org','philipsafricaroadshow.akvoapp.org'),(188,'vidare.akvoapp.org','vidare.akvoapp.org'),(189,'www.sportfordevelopment.akvoapp.org','www.sportfordevelopment.akvoapp.org'),(190,'www.mozambiquef4w.akvoapp.org','www.mozambiquef4w.akvoapp.org'),(191,'mpwliberia.akvoapp.org','mpwliberia.akvoapp.org'),(192,'wash-liberia.akvoapp.org','wash-liberia.akvoapp.org'),(193,'www.wash-liberia.akvoapp.org','www.wash-liberia.akvoapp.org'),(194,'www.nexusheritage.akvoapp.org','www.nexusheritage.akvoapp.org'),(195,'help.akvo.org','help.akvo.org'),(196,'f4winternational.akvoapp.org','f4winternational.akvoapp.org'),(197,'iati-test.akvo.org','iati-test.akvo.org'),(198,'srhr.akvoapp.org','srhr.akvoapp.org'),(199,'sandbox.akvo.org','sandbox.akvo.org'),(200,'bopinc.akvoapp.org','bopinc.akvoapp.org'),(201,'ginks.akvoapp.org','ginks.akvoapp.org'),(202,'ifad.akvoapp.org','ifad.akvoapp.org'),(203,'wandelenvoorwater2014.akvoapp.org','wandelenvoorwater2014.akvoapp.org'),(204,'oceanfdn.akvoapp.org','oceanfdn.akvoapp.org'),(205,'waterforpeople.akvoapp.org','waterforpeople.akvoapp.org'),(206,'localdev.akvo.org','localdev.akvo.org');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djcelery_crontabschedule`
--

DROP TABLE IF EXISTS `djcelery_crontabschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djcelery_crontabschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `minute` varchar(64) NOT NULL,
  `hour` varchar(64) NOT NULL,
  `day_of_week` varchar(64) NOT NULL,
  `day_of_month` varchar(64) NOT NULL,
  `month_of_year` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djcelery_crontabschedule`
--

LOCK TABLES `djcelery_crontabschedule` WRITE;
/*!40000 ALTER TABLE `djcelery_crontabschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `djcelery_crontabschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djcelery_intervalschedule`
--

DROP TABLE IF EXISTS `djcelery_intervalschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djcelery_intervalschedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `every` int(11) NOT NULL,
  `period` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djcelery_intervalschedule`
--

LOCK TABLES `djcelery_intervalschedule` WRITE;
/*!40000 ALTER TABLE `djcelery_intervalschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `djcelery_intervalschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djcelery_periodictask`
--

DROP TABLE IF EXISTS `djcelery_periodictask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djcelery_periodictask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `task` varchar(200) NOT NULL,
  `interval_id` int(11) DEFAULT NULL,
  `crontab_id` int(11) DEFAULT NULL,
  `args` longtext NOT NULL,
  `kwargs` longtext NOT NULL,
  `queue` varchar(200) DEFAULT NULL,
  `exchange` varchar(200) DEFAULT NULL,
  `routing_key` varchar(200) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `last_run_at` datetime DEFAULT NULL,
  `total_run_count` int(10) unsigned NOT NULL,
  `date_changed` datetime NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `djcelery_periodictask_17d2d99d` (`interval_id`),
  KEY `djcelery_periodictask_7aa5fda` (`crontab_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djcelery_periodictask`
--

LOCK TABLES `djcelery_periodictask` WRITE;
/*!40000 ALTER TABLE `djcelery_periodictask` DISABLE KEYS */;
/*!40000 ALTER TABLE `djcelery_periodictask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djcelery_periodictasks`
--

DROP TABLE IF EXISTS `djcelery_periodictasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djcelery_periodictasks` (
  `ident` smallint(6) NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`ident`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djcelery_periodictasks`
--

LOCK TABLES `djcelery_periodictasks` WRITE;
/*!40000 ALTER TABLE `djcelery_periodictasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `djcelery_periodictasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djcelery_taskstate`
--

DROP TABLE IF EXISTS `djcelery_taskstate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djcelery_taskstate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(64) NOT NULL,
  `task_id` varchar(36) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `tstamp` datetime NOT NULL,
  `args` longtext,
  `kwargs` longtext,
  `eta` datetime DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `result` longtext,
  `traceback` longtext,
  `runtime` double DEFAULT NULL,
  `retries` int(11) NOT NULL,
  `worker_id` int(11) DEFAULT NULL,
  `hidden` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `djcelery_taskstate_355bfc27` (`state`),
  KEY `djcelery_taskstate_52094d6e` (`name`),
  KEY `djcelery_taskstate_f459b00` (`tstamp`),
  KEY `djcelery_taskstate_20fc5b84` (`worker_id`),
  KEY `djcelery_taskstate_c91f1bf` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djcelery_taskstate`
--

LOCK TABLES `djcelery_taskstate` WRITE;
/*!40000 ALTER TABLE `djcelery_taskstate` DISABLE KEYS */;
/*!40000 ALTER TABLE `djcelery_taskstate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djcelery_workerstate`
--

DROP TABLE IF EXISTS `djcelery_workerstate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djcelery_workerstate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(255) NOT NULL,
  `last_heartbeat` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hostname` (`hostname`),
  KEY `djcelery_workerstate_1475381c` (`last_heartbeat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djcelery_workerstate`
--

LOCK TABLES `djcelery_workerstate` WRITE;
/*!40000 ALTER TABLE `djcelery_workerstate` DISABLE KEYS */;
/*!40000 ALTER TABLE `djcelery_workerstate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djkombu_message`
--

DROP TABLE IF EXISTS `djkombu_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djkombu_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `visible` tinyint(1) NOT NULL,
  `sent_at` datetime DEFAULT NULL,
  `payload` longtext NOT NULL,
  `queue_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `djkombu_message_16b2708a` (`visible`),
  KEY `djkombu_message_774871ae` (`sent_at`),
  KEY `djkombu_message_1e72d6b8` (`queue_id`)
) ENGINE=MyISAM AUTO_INCREMENT=145331 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djkombu_message`
--

LOCK TABLES `djkombu_message` WRITE;
/*!40000 ALTER TABLE `djkombu_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `djkombu_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `djkombu_queue`
--

DROP TABLE IF EXISTS `djkombu_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `djkombu_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `djkombu_queue`
--

LOCK TABLES `djkombu_queue` WRITE;
/*!40000 ALTER TABLE `djkombu_queue` DISABLE KEYS */;
INSERT INTO `djkombu_queue` VALUES (1,'celery');
/*!40000 ALTER TABLE `djkombu_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateway_gateway`
--

DROP TABLE IF EXISTS `gateway_gateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_gateway` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `host_name` varchar(255) NOT NULL,
  `send_path` varchar(255) NOT NULL,
  `sender` varchar(30) NOT NULL,
  `receiver` varchar(30) NOT NULL,
  `message` varchar(30) NOT NULL,
  `timestamp` varchar(30) NOT NULL,
  `msg_id` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gateway_gateway_52094d6e` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_gateway`
--

LOCK TABLES `gateway_gateway` WRITE;
/*!40000 ALTER TABLE `gateway_gateway` DISABLE KEYS */;
INSERT INTO `gateway_gateway` VALUES (1,'42it','server2.msgtoolbox.com','/api/current/send/message.php','sender','to','text','delivered','incsmsid');
/*!40000 ALTER TABLE `gateway_gateway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateway_gatewaynumber`
--

DROP TABLE IF EXISTS `gateway_gatewaynumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_gatewaynumber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) NOT NULL,
  `number` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gateway_gatewaynumber_7702dc03` (`gateway_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_gatewaynumber`
--

LOCK TABLES `gateway_gatewaynumber` WRITE;
/*!40000 ALTER TABLE `gateway_gatewaynumber` DISABLE KEYS */;
INSERT INTO `gateway_gatewaynumber` VALUES (3,1,'46731233401'),(2,1,'46731233400'),(1,1,'467301203262115');
/*!40000 ALTER TABLE `gateway_gatewaynumber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gateway_mosms`
--

DROP TABLE IF EXISTS `gateway_mosms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gateway_mosms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(30) NOT NULL,
  `receiver` varchar(30) NOT NULL,
  `message` longtext NOT NULL,
  `timestamp` varchar(50) NOT NULL,
  `msg_id` varchar(100) NOT NULL,
  `saved_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_mosms`
--

LOCK TABLES `gateway_mosms` WRITE;
/*!40000 ALTER TABLE `gateway_mosms` DISABLE KEYS */;
INSERT INTO `gateway_mosms` VALUES (1,'14158235494','46731233400',' Jbwhbq  ','1304114511','13041145115639250741','2011-04-30 00:01:52'),(2,'14158235494','46731233400','Loafers, wingtips, oxfords, derby, blucher, balmoral! Monkstrap slip-ons, white buck, black tie, dress boots and more are here now!!','1304114958','13041149584849270741','2011-04-30 00:09:19'),(3,'14158235494','46731233400','Loafers, wingtips, oxfords, derby, blucher, balmoral! Monkstrap slip-ons, white buck, black tie, dress boots and more are here now!!','1304115321','13041153215189280741','2011-04-30 00:15:23'),(4,'31647037166','46731233400','NXUNH7','1304336856','13043368568097070741','2011-05-02 13:47:38'),(5,'31644950646','46731233400','N3GDF4','1304337083','13043370837597080741','2011-05-02 13:51:25'),(6,'31644950646','46731233400','Demo sms test from Uganda with NL phone number, Kathelyne','1304337645','13043376458969400741','2011-05-02 14:00:47'),(7,'256778052613','46731233400','9TSQT6','1304365234','13043652340390860741','2011-05-02 21:40:35'),(8,'256778052613','46731233400','Testing from Uganda phone ','1304365278','13043652784737850741','2011-05-02 21:41:19'),(9,'256778052613','46731233400','On my way to visit this project. Still stuck in Kampala traffic.','1304402752','13044027525647980741','2011-05-03 08:05:53'),(10,'31647037166','46731233400','Looking forward to visiting this project today. Driving towards site now.','1304402915','13044029158148000741','2011-05-03 08:08:37'),(11,'31647037166','46731233400','Still stuck in Kampala traffic, slowly moving towards Mmamze.','1304404104','13044041045768030741','2011-05-03 08:28:26'),(12,'256778052613','46731233401','Just picked up Hope Harriet in Masulita, outside Kampala. ','1304405968','13044059687098060741','2011-05-03 08:59:30'),(13,'256778052613','46731233400','Arrived at the project site in Mmamze. The new latrines at the school look great!','1304413146','13044131462258410741','2011-05-03 10:59:07'),(14,'256778052613','46731233400','The RWH tank is nearly constructed. By the end of the month it will be operational.','1304413247','13044132477419900741','2011-05-03 11:00:48'),(15,'256778052613','46731233401','Some of the latrines have already been constructed.','1304414361','13044143610541150741','2011-05-03 11:19:22'),(16,'256778052613','46731233401','The old latrines were meant to be temporarily, but have been used for 7 years now.','1304414467','13044144670018450741','2011-05-03 11:21:09'),(17,'256778052613','46731233401','The rainwater harvesting tank is nearly fully constructed. A pipeline will be dug so the kids have water from a tap.','1304414612','13044146129808460741','2011-05-03 11:23:35'),(18,'256778052613','46731233400','Great to see a fully functional Rainwater Harvesting system! ','1304415406','13044154068309920741','2011-05-03 11:36:49'),(19,'256778052613','46731233401','Leaving Mmamze. Thank you so much Mulindwa from MACEDURET! Keep up the good work!','1304418984','13044189848058540741','2011-05-03 12:36:25'),(20,'256778052613','46731233400','Leaving Mmamze. The work that is being done is amazing. Finally people have clean water and proper sanitation!','1304418990','13044189903929940741','2011-05-03 12:36:31'),(21,'256778052611','46731233400','Vzh4bu','1304487100','13044871005109230741','2011-05-04 07:31:42'),(22,'256778052613','46731233400','DFDXGL','1304539912','13045399124990340741','2011-05-04 22:11:54'),(23,'256778052611','46731233400','We just arrived in Jinja, waiting for Eddy who will take us to Kisozi, Kamuli district, to visit the project. ','1304578989','13045789899901690741','2011-05-05 09:03:11'),(24,'256778052613','46731233400','Eddy from Hope Alive Uganda is escorting us to Kisozi, where the project is located.','1304582471','13045824712093520741','2011-05-05 10:01:13'),(25,'31647037166','46731233400','JR8QAK','1304589893','13045898934512050741','2011-05-05 12:04:54'),(26,'31647037166','46731233400','We have arrived in Kisozi! Eddy is showing us the Hope Alive Uganda office.','1304590017','13045900175131210741','2011-05-05 12:06:58'),(27,'31647037166','46731233400','We have arrived at the water point. The community is very happy with it!','1304599780','13045997803372210741','2011-05-05 14:49:41'),(28,'256778052611','46731233400','Visiting the water pump, unfortunately the pump broke down last night. The construction company provides a 6 months garantee. ','1304604564','13046045646002320741','2011-05-05 16:09:25'),(29,'256778052611','46731233400','The technician have been called, hopefully they come to fix this soon so the community don\'t have to walk long distances for clean water. ','1304604806','13046048060392330741','2011-05-05 16:13:28'),(30,'254703391362','46731233400','ARTVJC','1304876775','13048767759634540741','2011-05-08 19:46:18'),(31,'254735487192','46731233400','LWBUUE','1304877187','13048771872886170741','2011-05-08 19:53:08'),(32,'254735487192','46731233400','Leaving Nairobi, on route to Kaijado. We\'re travelling with a group of WASH Alliance partners.','1304933527','13049335276096700741','2011-05-09 11:32:09'),(33,'254735487192','46731233401','We are now travelling towards Kaijado where this project is located. I\'m very eager to get a chance to see what the status is.','1304933673','13049336737526720741','2011-05-09 11:34:35'),(34,'254735487192','46731233400','We have arrived in Kaijado! Today we have meetings with local partners. Tommorow project visit.','1304936996','13049369963325110741','2011-05-09 12:29:57'),(35,'254735487192','46731233401','We have arrived in Kaijado. Just visited the AMREF local office and staff. Tommorow we will visit the project.','1304937105','13049371050866840741','2011-05-09 12:31:46'),(36,'254735487192','46731233400','We are now going to visit the borehole! Really exciting to see what has been happening.','1305008841','13050088410625610741','2011-05-10 08:27:24'),(37,'254703391362','46731233400','On our way to the borehole we discover that the road is flooded we have to take another route','1305016233','13050162330275710741','2011-05-10 10:30:34'),(38,'254735487192','46731233400','We are still on route to the project site. We had to take a detour because a stream has flooded the road.','1305016357','13050163571577720741','2011-05-10 10:32:39'),(39,'254735487192','46731233401','Just visited a school in Kaijado District. They now have proper toilet facilities and simple handwashing systems.','1305026075','13050260751668040741','2011-05-10 13:14:36'),(40,'254735487192','46731233401','A new Rainwater Harvesting Tank has just arrived. This way children can have enough clean water all year round!','1305029191','13050291918058160741','2011-05-10 14:06:33'),(41,'254735487192','46731233400','We have arrived at the project site. We received a warm welcome from the local Masai community with singing.','1305037296','13050372960393380741','2011-05-10 16:21:36'),(42,'254735487192','46731233400','People are very happy with the new toilets and bathing facilities, especially the women! Great stuff!','1305037667','13050376677056220741','2011-05-10 16:27:50'),(43,'31644950646','46731233400','4CQB2Q','1305885069','13058850696779630741','2011-05-20 11:51:11'),(44,'31647037166','46731233400','BDG4QW','1306407881','13064078811788280741','2011-05-26 13:04:43'),(45,'31647037166','46731233400','Showing our partners at the Akvo workshop how SMS updates works!','1306415414','13064154144648550741','2011-05-26 15:10:15'),(46,'31624129876','46731233400','AW24HP','1309075256','13090752569577280741','2011-06-26 10:00:59'),(47,'31644950646','46731233401','Pseqp4','1322646046','13226460461580770741','2011-11-30 10:40:48'),(48,'31644950646','46731233400','Testing','1322646211','13226462119310830741','2011-11-30 10:43:33'),(49,'59168122917','46731233401','Caahmg','1323284390','13232843900378400741','2011-12-07 19:59:52'),(50,'59168122917','46731233400','Testing sms here in La Paz, Bolivia','1323284577','13232845779651500741','2011-12-07 20:02:59'),(51,'31644950646','46731233401','FKNA6F','1323395883','13233958836851960741','2011-12-09 02:58:09'),(52,'59168122917','46731233401','Test sms from oruro using entel with entel simcard','1323447485','13234474852234930741','2011-12-09 17:18:07'),(53,'31644950646','46731233401','Test Sms from Oruro, Bolivia provider VIVA, Dutch number, cheers kathelyne','1323447764','13234477645444970741','2011-12-09 17:22:46'),(54,'31644950646','46731233400','We are here with hunderds of kids showing educational games they work with at school, in Oruro on the Feria organized by Educatic Bolivia','1323457951','13234579516355150741','2011-12-09 20:12:32'),(55,'59168122917','46731233401','Test tallapata movil bolivian nr kathelyne','1323531037','13235310376398040741','2011-12-10 16:30:40'),(56,'59168122917','46731233400','Visiting the biggest Organic Quinua fabrique in Oruro, in Tallapata with FAUTAPO.  ','1323531341','13235313414270140741','2011-12-10 16:35:43'),(57,'31638531941','46731233401','AWZSG9','1325754097','13257540975652050741','2012-01-05 10:01:39'),(58,'31638531941','46731233401','Happy New Year to all of you following the Tell Balata Project!','1325754449','13257544498845930741','2012-01-05 10:07:31'),(59,'31638531941','46731233401','CommonSites welcomes Nexus to Leiden.','1325768291','13257682917123130741','2012-01-05 13:58:13'),(60,'46707277477','46731233401','Foo','1340028541','13400285412688810741','2012-06-18 16:09:03'),(61,'46707277477','46731233401','Dvkk4e','1340031185','13400311852504080741','2012-06-18 16:53:06'),(62,'46707277477','46731233401','Test from Rotebro!','1340031310','13400313107888900741','2012-06-18 16:55:12'),(63,'','','','','','2012-08-14 16:49:48'),(64,'31638531941','46731233401','Our Mota-dach - Leiden team welcomes miss Lubna Taha, who will start working on the Arabic translation of the teachers handbook!','1348480495','13484804954788750741','2012-09-24 11:54:57'),(65,'962795664449','46731233401','ØªÙØ§Ù Ø§ÙØ§ ÙØªØ¨Øª Ø§ÙØ±Ø¯ Ø§Ø¯Ø§ ÙØ§ ÙØµÙ Ø¨ÙØºÙÙ','1351699212','13516992121213390741','2012-10-31 17:00:15');
/*!40000 ALTER TABLE `gateway_mosms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_notice`
--

DROP TABLE IF EXISTS `notification_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `message` longtext NOT NULL,
  `notice_type_id` int(11) NOT NULL,
  `added` datetime NOT NULL,
  `unseen` tinyint(1) NOT NULL,
  `archived` tinyint(1) NOT NULL,
  `on_site` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_notice_32f69dc` (`recipient_id`),
  KEY `notification_notice_6fe0a617` (`sender_id`),
  KEY `notification_notice_d734034` (`notice_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=168 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_notice`
--

LOCK TABLES `notification_notice` WRITE;
/*!40000 ALTER TABLE `notification_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_noticequeuebatch`
--

DROP TABLE IF EXISTS `notification_noticequeuebatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_noticequeuebatch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pickled_data` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_noticequeuebatch`
--

LOCK TABLES `notification_noticequeuebatch` WRITE;
/*!40000 ALTER TABLE `notification_noticequeuebatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_noticequeuebatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_noticesetting`
--

DROP TABLE IF EXISTS `notification_noticesetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_noticesetting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `notice_type_id` int(11) NOT NULL,
  `medium` varchar(10) NOT NULL,
  `send` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`notice_type_id`,`medium`),
  KEY `notification_noticesetting_403f60f` (`user_id`),
  KEY `notification_noticesetting_d734034` (`notice_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_noticesetting`
--

LOCK TABLES `notification_noticesetting` WRITE;
/*!40000 ALTER TABLE `notification_noticesetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_noticesetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_noticetype`
--

DROP TABLE IF EXISTS `notification_noticetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_noticetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(40) NOT NULL,
  `display` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `default` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_noticetype`
--

LOCK TABLES `notification_noticetype` WRITE;
/*!40000 ALTER TABLE `notification_noticetype` DISABLE KEYS */;
INSERT INTO `notification_noticetype` VALUES (7,'phone_added','Phone number added','Your mobile phone has been added to your user profile',2),(8,'phone_confirmed','Phone confirmed','Your mobile phone number has been confirmed for use in updating RSR projects',2),(9,'reporting_enabled','SMS updates enabled for project','You can now send SMS-updates to an RSR project',2),(10,'reporting_cancelled','SMS updates cancelled','SMS-updates to an RSR project has been cancelled',2),(11,'phone_disabled','Phone disabled','SMS-updates from your mobile phone are no longer accepted',2),(12,'update_received','Update received','Akvo has received an update from your phone',2);
/*!40000 ALTER TABLE `notification_noticetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_observeditem`
--

DROP TABLE IF EXISTS `notification_observeditem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_observeditem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `object_id` int(10) unsigned NOT NULL,
  `notice_type_id` int(11) NOT NULL,
  `added` datetime NOT NULL,
  `signal` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_observeditem_403f60f` (`user_id`),
  KEY `notification_observeditem_1bb8f392` (`content_type_id`),
  KEY `notification_observeditem_d734034` (`notice_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_observeditem`
--

LOCK TABLES `notification_observeditem` WRITE;
/*!40000 ALTER TABLE `notification_observeditem` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_observeditem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oembed_aggregatemedia`
--

DROP TABLE IF EXISTS `oembed_aggregatemedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oembed_aggregatemedia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` longtext NOT NULL,
  `object_id` int(11) DEFAULT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oembed_aggregatemedia_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oembed_aggregatemedia`
--

LOCK TABLES `oembed_aggregatemedia` WRITE;
/*!40000 ALTER TABLE `oembed_aggregatemedia` DISABLE KEYS */;
/*!40000 ALTER TABLE `oembed_aggregatemedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oembed_storedoembed`
--

DROP TABLE IF EXISTS `oembed_storedoembed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oembed_storedoembed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `match` longtext NOT NULL,
  `response_json` longtext NOT NULL,
  `resource_type` varchar(8) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_expires` datetime DEFAULT NULL,
  `maxwidth` int(11) DEFAULT NULL,
  `maxheight` int(11) DEFAULT NULL,
  `object_id` int(11) DEFAULT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oembed_storedoembed_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=476 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oembed_storedoembed`
--

LOCK TABLES `oembed_storedoembed` WRITE;
/*!40000 ALTER TABLE `oembed_storedoembed` DISABLE KEYS */;
/*!40000 ALTER TABLE `oembed_storedoembed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oembed_storedprovider`
--

DROP TABLE IF EXISTS `oembed_storedprovider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oembed_storedprovider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `endpoint_url` varchar(255) NOT NULL,
  `regex` varchar(255) NOT NULL,
  `wildcard_regex` varchar(255) NOT NULL,
  `resource_type` varchar(8) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `provides` tinyint(1) NOT NULL,
  `scheme_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oembed_storedprovider`
--

LOCK TABLES `oembed_storedprovider` WRITE;
/*!40000 ALTER TABLE `oembed_storedprovider` DISABLE KEYS */;
/*!40000 ALTER TABLE `oembed_storedprovider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_ipn`
--

DROP TABLE IF EXISTS `paypal_ipn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_ipn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business` varchar(127) NOT NULL,
  `charset` varchar(32) NOT NULL,
  `custom` varchar(255) NOT NULL,
  `notify_version` decimal(64,2) DEFAULT NULL,
  `parent_txn_id` varchar(19) NOT NULL,
  `receiver_email` varchar(127) NOT NULL,
  `receiver_id` varchar(127) NOT NULL,
  `residence_country` varchar(2) NOT NULL,
  `test_ipn` tinyint(1) NOT NULL,
  `txn_id` varchar(19) NOT NULL,
  `txn_type` varchar(128) NOT NULL,
  `verify_sign` varchar(255) NOT NULL,
  `address_country` varchar(64) NOT NULL,
  `address_city` varchar(40) NOT NULL,
  `address_country_code` varchar(64) NOT NULL,
  `address_name` varchar(128) NOT NULL,
  `address_state` varchar(40) NOT NULL,
  `address_status` varchar(11) NOT NULL,
  `address_street` varchar(200) NOT NULL,
  `address_zip` varchar(20) NOT NULL,
  `contact_phone` varchar(20) NOT NULL,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `payer_business_name` varchar(127) NOT NULL,
  `payer_email` varchar(127) NOT NULL,
  `payer_id` varchar(13) NOT NULL,
  `auth_amount` decimal(64,2) DEFAULT NULL,
  `auth_exp` varchar(28) NOT NULL,
  `auth_id` varchar(19) NOT NULL,
  `auth_status` varchar(9) NOT NULL,
  `exchange_rate` decimal(64,16) DEFAULT NULL,
  `invoice` varchar(127) NOT NULL,
  `item_name` varchar(127) NOT NULL,
  `item_number` varchar(127) NOT NULL,
  `mc_currency` varchar(32) NOT NULL,
  `mc_fee` decimal(64,2) DEFAULT NULL,
  `mc_gross` decimal(64,2) DEFAULT NULL,
  `mc_handling` decimal(64,2) DEFAULT NULL,
  `mc_shipping` decimal(64,2) DEFAULT NULL,
  `memo` varchar(255) NOT NULL,
  `num_cart_items` int(11) DEFAULT NULL,
  `option_name1` varchar(64) NOT NULL,
  `option_name2` varchar(64) NOT NULL,
  `payer_status` varchar(10) NOT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_gross` decimal(64,2) DEFAULT NULL,
  `payment_status` varchar(9) NOT NULL,
  `payment_type` varchar(7) NOT NULL,
  `pending_reason` varchar(14) NOT NULL,
  `protection_eligibility` varchar(32) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `reason_code` varchar(15) NOT NULL,
  `remaining_settle` decimal(64,2) DEFAULT NULL,
  `settle_amount` decimal(64,2) DEFAULT NULL,
  `settle_currency` varchar(32) NOT NULL,
  `shipping` decimal(64,2) DEFAULT NULL,
  `shipping_method` varchar(255) NOT NULL,
  `tax` decimal(64,2) DEFAULT NULL,
  `transaction_entity` varchar(7) NOT NULL,
  `auction_buyer_id` varchar(64) NOT NULL,
  `auction_closing_date` datetime DEFAULT NULL,
  `auction_multi_item` int(11) DEFAULT NULL,
  `for_auction` decimal(64,2) DEFAULT NULL,
  `amount` decimal(64,2) DEFAULT NULL,
  `amount_per_cycle` decimal(64,2) DEFAULT NULL,
  `initial_payment_amount` decimal(64,2) DEFAULT NULL,
  `next_payment_date` datetime DEFAULT NULL,
  `outstanding_balance` decimal(64,2) DEFAULT NULL,
  `payment_cycle` varchar(32) NOT NULL,
  `period_type` varchar(32) NOT NULL,
  `product_name` varchar(128) NOT NULL,
  `product_type` varchar(128) NOT NULL,
  `profile_status` varchar(32) NOT NULL,
  `recurring_payment_id` varchar(128) NOT NULL,
  `rp_invoice_id` varchar(127) NOT NULL,
  `time_created` datetime DEFAULT NULL,
  `amount1` decimal(64,2) DEFAULT NULL,
  `amount2` decimal(64,2) DEFAULT NULL,
  `amount3` decimal(64,2) DEFAULT NULL,
  `mc_amount1` decimal(64,2) DEFAULT NULL,
  `mc_amount2` decimal(64,2) DEFAULT NULL,
  `mc_amount3` decimal(64,2) DEFAULT NULL,
  `password` varchar(24) NOT NULL,
  `period1` varchar(32) NOT NULL,
  `period2` varchar(32) NOT NULL,
  `period3` varchar(32) NOT NULL,
  `reattempt` varchar(1) NOT NULL,
  `recur_times` int(11) DEFAULT NULL,
  `recurring` varchar(1) NOT NULL,
  `retry_at` datetime DEFAULT NULL,
  `subscr_date` datetime DEFAULT NULL,
  `subscr_effective` datetime DEFAULT NULL,
  `subscr_id` varchar(19) NOT NULL,
  `username` varchar(64) NOT NULL,
  `case_creation_date` datetime DEFAULT NULL,
  `case_id` varchar(14) NOT NULL,
  `case_type` varchar(24) NOT NULL,
  `receipt_id` varchar(64) NOT NULL,
  `currency_code` varchar(32) NOT NULL,
  `handling_amount` decimal(64,2) DEFAULT NULL,
  `transaction_subject` varchar(255) NOT NULL,
  `ipaddress` char(15) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  `flag_code` varchar(16) NOT NULL,
  `flag_info` longtext NOT NULL,
  `query` longtext NOT NULL,
  `response` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `from_view` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paypal_ipn_7ff10c6f` (`txn_id`)
) ENGINE=MyISAM AUTO_INCREMENT=571 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_ipn`
--

LOCK TABLES `paypal_ipn` WRITE;
/*!40000 ALTER TABLE `paypal_ipn` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_ipn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_objectpermission`
--

DROP TABLE IF EXISTS `permissions_objectpermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_objectpermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `permission_id` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `content_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_objectpermission_40f80fc0` (`role_id`),
  KEY `permissions_objectpermission_1e014c8f` (`permission_id`),
  KEY `permissions_objectpermission_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=201 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_objectpermission`
--

LOCK TABLES `permissions_objectpermission` WRITE;
/*!40000 ALTER TABLE `permissions_objectpermission` DISABLE KEYS */;
INSERT INTO `permissions_objectpermission` VALUES (131,2,2,28,61),(160,2,2,28,67),(73,1,1,28,63),(72,2,2,28,63),(122,2,2,28,106),(123,1,1,28,106),(53,2,2,28,255),(75,2,2,28,50),(79,2,2,28,264),(80,1,1,28,264),(149,2,2,28,265),(150,1,1,28,265),(94,2,2,28,275),(95,1,1,28,275),(200,2,2,28,22),(196,2,2,28,360),(163,2,2,28,447),(183,2,2,28,366),(184,1,1,28,366),(141,2,2,28,370),(157,2,2,28,363),(166,2,2,28,488),(193,2,2,28,421),(199,2,2,28,458),(187,2,2,28,335),(195,2,2,28,659),(198,2,2,28,281);
/*!40000 ALTER TABLE `permissions_objectpermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_objectpermissioninheritanceblock`
--

DROP TABLE IF EXISTS `permissions_objectpermissioninheritanceblock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_objectpermissioninheritanceblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `content_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_objectpermissioninheritanceblock_1e014c8f` (`permission_id`),
  KEY `permissions_objectpermissioninheritanceblock_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_objectpermissioninheritanceblock`
--

LOCK TABLES `permissions_objectpermissioninheritanceblock` WRITE;
/*!40000 ALTER TABLE `permissions_objectpermissioninheritanceblock` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_objectpermissioninheritanceblock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_permission`
--

DROP TABLE IF EXISTS `permissions_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `codename` (`codename`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_permission`
--

LOCK TABLES `permissions_permission` WRITE;
/*!40000 ALTER TABLE `permissions_permission` DISABLE KEYS */;
INSERT INTO `permissions_permission` VALUES (1,'Add SMS updates','add_sms_updates'),(2,'Manage SMS updates','manage_sms_updates');
/*!40000 ALTER TABLE `permissions_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_permission_content_types`
--

DROP TABLE IF EXISTS `permissions_permission_content_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_permission_content_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `contenttype_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_id` (`permission_id`,`contenttype_id`),
  KEY `permissions_permission_content_types_1e014c8f` (`permission_id`),
  KEY `permissions_permission_content_types_5e7b3bd8` (`contenttype_id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_permission_content_types`
--

LOCK TABLES `permissions_permission_content_types` WRITE;
/*!40000 ALTER TABLE `permissions_permission_content_types` DISABLE KEYS */;
INSERT INTO `permissions_permission_content_types` VALUES (49,1,28),(50,2,28);
/*!40000 ALTER TABLE `permissions_permission_content_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_principalrolerelation`
--

DROP TABLE IF EXISTS `permissions_principalrolerelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_principalrolerelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `content_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permissions_principalrolerelation_403f60f` (`user_id`),
  KEY `permissions_principalrolerelation_425ae3c4` (`group_id`),
  KEY `permissions_principalrolerelation_40f80fc0` (`role_id`),
  KEY `permissions_principalrolerelation_1bb8f392` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_principalrolerelation`
--

LOCK TABLES `permissions_principalrolerelation` WRITE;
/*!40000 ALTER TABLE `permissions_principalrolerelation` DISABLE KEYS */;
INSERT INTO `permissions_principalrolerelation` VALUES (1,NULL,5,1,NULL,NULL),(2,NULL,6,1,NULL,NULL),(3,NULL,6,2,NULL,NULL);
/*!40000 ALTER TABLE `permissions_principalrolerelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_role`
--

DROP TABLE IF EXISTS `permissions_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_role`
--

LOCK TABLES `permissions_role` WRITE;
/*!40000 ALTER TABLE `permissions_role` DISABLE KEYS */;
INSERT INTO `permissions_role` VALUES (2,'SMS manager'),(1,'SMS updater');
/*!40000 ALTER TABLE `permissions_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration_registrationprofile`
--

DROP TABLE IF EXISTS `registration_registrationprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registration_registrationprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `activation_key` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1167 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration_registrationprofile`
--

LOCK TABLES `registration_registrationprofile` WRITE;
/*!40000 ALTER TABLE `registration_registrationprofile` DISABLE KEYS */;
/*!40000 ALTER TABLE `registration_registrationprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_benchmark`
--

DROP TABLE IF EXISTS `rsr_benchmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_benchmark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_benchmark_499df97c` (`project_id`),
  KEY `rsr_benchmark_42dc49bc` (`category_id`),
  KEY `rsr_benchmark_632e075f` (`name_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18848 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_benchmark`
--

LOCK TABLES `rsr_benchmark` WRITE;
/*!40000 ALTER TABLE `rsr_benchmark` DISABLE KEYS */;
INSERT INTO `rsr_benchmark` VALUES (8943,613,31,69,50),(8944,613,31,65,0),(8945,613,31,66,0),(8946,613,31,68,0),(8947,613,31,67,0),(8948,613,33,69,3),(8949,613,33,73,1),(8950,613,33,75,10),(8951,613,33,74,3),(8952,613,32,69,3),(8953,613,32,70,10),(8954,613,32,67,50),(13292,789,38,99,0),(13293,789,38,100,0),(13294,789,38,104,0),(13295,789,38,102,0),(13296,789,38,101,0),(13297,789,38,103,0),(13298,789,5,84,0),(13299,789,5,114,0),(13300,789,5,85,0),(13301,789,5,4,0),(13302,789,37,118,0),(13303,789,2,132,0),(13304,789,2,97,0),(13305,789,2,96,0),(13306,789,2,5,0),(13307,789,2,6,0),(13308,789,2,2,0),(13309,789,2,3,0),(13310,789,4,4,0),(13311,789,1,119,0),(13312,789,1,132,0),(13313,789,1,87,0),(13314,789,1,122,0),(13315,789,1,111,0),(13316,789,1,1,0),(13317,789,1,2,0),(13318,789,1,3,0),(15448,869,24,78,0),(15449,869,24,77,0),(15450,869,24,46,0),(15451,869,24,57,0),(15452,869,24,89,0),(15453,869,24,63,0),(15454,869,24,136,0),(15455,869,24,76,0),(15456,869,24,123,0),(15457,869,24,84,0),(15458,869,24,86,0),(15459,869,24,117,0),(15460,869,24,64,0),(15461,869,24,45,0),(15462,869,24,85,0),(15463,869,24,40,0),(15464,869,24,41,0),(15465,869,24,62,0),(15466,869,24,54,0),(15467,869,24,53,0),(15468,869,24,60,0),(15469,869,24,61,0),(15470,869,24,4,0),(15471,869,28,47,0),(15472,869,28,48,0),(15473,869,28,141,0),(15474,869,28,87,0),(15475,869,28,21,0),(15476,869,28,140,0),(15477,869,28,92,0),(15478,869,28,62,0),(17078,869,25,42,0),(17079,869,25,21,0),(17080,869,27,43,0),(17081,869,16,44,0),(17082,869,16,23,0),(17083,869,16,22,0),(17084,869,16,80,0),(17085,869,16,79,0),(17086,869,40,110,0),(17087,869,40,109,0),(17088,869,40,113,0),(17089,869,40,120,0),(17090,869,40,121,0),(17091,869,15,32,0),(17092,869,15,21,0),(17093,869,15,31,0),(17094,869,15,4,0),(17095,869,26,20,0),(17096,869,26,4,0);
/*!40000 ALTER TABLE `rsr_benchmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_benchmarkname`
--

DROP TABLE IF EXISTS `rsr_benchmarkname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_benchmarkname` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=324 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_benchmarkname`
--

LOCK TABLES `rsr_benchmarkname` WRITE;
/*!40000 ALTER TABLE `rsr_benchmarkname` DISABLE KEYS */;
INSERT INTO `rsr_benchmarkname` VALUES (1,'water systems',100),(2,'people affected',3000),(3,'years duration',4000),(4,'trainees',2000),(5,'sanitation systems',200),(6,'hygiene facilities',300),(12,'mobile devices',1200),(10,'computer software and hardware',1100),(13,'information systems',1000),(14,'internet connections',1300),(15,'users',1500),(16,'people running sustainable business',0),(17,'entrepreneurship trainees',0),(18,'new partnerships',0),(19,'new clients/customers',0),(20,'new jobs',0),(21,'people reached',0),(22,'increased awareness',0),(23,'HIV/AIDS tested',0),(24,'hospitals using telemedicine',0),(25,'health centers using telemedicine',0),(26,'consultations ',0),(29,'business centers',0),(30,'radio station',0),(31,'with access to health information',0),(32,'health training materials',0),(33,'hospitals',0),(34,'local health clinics',0),(35,'micro-finance bodies',0),(36,'medical cases uploaded',0),(38,'e-courses',0),(39,'farmers trained',0),(40,'teachers use ICT',0),(41,'teaching notes uploaded',0),(42,'community educators trained',0),(43,'equipment installed',0),(44,'children / (childheaded) families taken care of',0),(45,'teachers reached',0),(46,'children reached',0),(47,'health facilties reached',0),(48,'health workers trained',0),(49,'staff trained',0),(50,'organisations trained',0),(51,'producer organisations reached',0),(52,'producers/entrepreneurs trained',0),(53,'women learn vocational skills',0),(54,'women learn to read and write',0),(55,'women join co-operative',0),(56,'women lift themselves out of poverty',0),(57,'former child soldiers complete their education',0),(63,'outreach counsellors trained in counseling skills',0),(62,'trauma victims are offered support and counseling',0),(60,'others in community mentored',100),(61,'former child soldiers are lifted out of poverty',200),(64,'surveys carried out with beneficiaries',0),(65,'excavations',0),(66,'publications',0),(67,'students and/or staff trained',0),(68,'research programs',0),(69,'communities helped',0),(70,'sites managed and conserved',0),(74,'teaching programs ',0),(73,'exhibitions created',0),(75,'sites interpreted',0),(76,'percentage of girls in secondary education',0),(77,'children participating in reading aloud',0),(78,'children participating in mixed sports',0),(79,'people reached by HIV socialization',0),(80,'medical staff receive HIV training',0),(81,'cataract operations',0),(82,'postgraduate seminar trainees',0),(83,'euros in medical equipment',0),(84,'schools reached',0),(85,'teachers trained',0),(86,'students reached',0),(87,'people in communities reached',0),(88,'daily SMS on market info.',0),(89,'new construction ',0),(91,'SMS send monthly',0),(92,'pregnant women reached',0),(93,'producers/entrepreneurs increased their income',0),(94,'events organised',0),(95,'advocacy events organised',0),(96,'people use improved sanitation facilities',0),(97,'institutions with improved sanitation facilities',0),(98,'people reached with hygiene related communication',0),(99,'NGOs receive capacity assessments',0),(100,'NGOs receive tailor made trainings',0),(101,'staff members trained on WASH financing ',0),(102,'people trained on budget tracking methodologies',0),(103,'staff trained on water resource protection',0),(104,'NGOs trained on Sustainability Assessment',0),(105,'district level WASH programs implemented ',0),(106,'active WASH coordination structures',0),(107,'women active in WASH community group ',0),(108,'marginalized groups active in WASH community group',0),(109,'NGOs using integrated Sustainability Instrument',0),(110,'areas where budget tracking is on meeting agenda',0),(111,'people use improved drinking water',0),(112,'people impacted by ICT-improved org. services',0),(113,'of initiatives to influence water resource policy',0),(114,'students trained',0),(115,'end users',0),(116,'producer organizations access to market info',0),(117,'students use ICT',0),(118,'Persons who receive training/capacity building',0),(119,'communities reached',0),(120,'organisations focus on human rights',0),(121,'organisations strengthened ',0),(122,'people receive training ',0),(123,'School management Committees trained',0),(124,'women empowered',0),(125,'people empowered',0),(126,'women reached',0),(127,'people with access to information',0),(128,'people receive funding',0),(129,'institutions with improved facilities',0),(130,'people with access to improved facilities',0),(132,'households reached',0),(133,'women receive funding',0),(134,'people reached via radio broadcasting',0),(135,'households receive funding',0),(136,'people trained',0),(137,'people trained',0),(138,'youth groups reached',0),(139,'houses built',0),(140,'people with access to health care',0),(141,'households have access to healthcare',0),(142,'institutions trained',0),(143,'farmers groups reached',0),(144,'women groups reached',0),(146,'(Basic) organizations with increased capacity for policy influencing',0),(147,'Action plans supported by government, private sector, other stakeholders',0),(148,'Communities with emergency preparedness plans (incl. early warning)',0),(149,'Disaster affected people provided with basic health (incl. psycho-social care)',0),(150,'Disaster affected people provided with basic need in clean water',0),(151,'Disaster affected people provided with basic need in food',0),(152,'Disaster affected people provided with basic need in non-food items',0),(153,'Disaster affected people provided with basic need in sanitation',0),(154,'Disaster affected people provided with basic need in shelter',0),(155,'Households with restored livelihoods',0),(156,'Households with restored water and sanitation faclities',0),(157,'Households with safe shelter (& other buildings)',0),(158,'Knowledge Development trajectories',0),(159,'Lobby trajectories to influence policy of relevant actors',0),(160,'Local organizations trained in emergency response (by Cordaid)',0),(161,'Local organizations with increased capacity in (CM)DRR',0),(162,'Organizations involved in emergency plan of government/others (e.g. OCHA)',0),(163,'Organized communities that developed their own disaster plans',0),(164,'People reached with preventieve activities in water',0),(165,'People reached with prevention activities in shelter ',0),(166,'People reached with preventive activiities in livelihood',0),(167,'People reached with preventive activities in climate adaptation',0),(168,'People reached with preventive activities in natural resource management',0),(169,'(agri) Products developed for microfinance clients',0),(170,'(branch) Managers supported through capacity building',0),(171,'(branch) Managers that have improved skills and knowledge',0),(172,'Improved/adjusted product(s) for microfinance clients ',0),(173,'Microfinance clients trained on business skills and financial literacy',0),(174,'Organisation(s) with improved access to and overview of information',0),(175,'Organization(s) invested in purchase of computer systems/hardware',0),(176,'Organization(s) receiving capacity building on (agri) product development',0),(177,'Organization(s) receiving capacity building on staff management',0),(178,'Staff members have improved (secondary) working conditions',0),(179,'Centres for the processing of (raw) agricultural products',0),(180,'Cooperatives are self-supporting',0),(181,'Cooperatives created and functional',0),(182,'Cooperatives trained',0),(183,'Fish ponds constructed',0),(184,'Livestock animals distributed to beneficiaries',0),(185,'People trained in business skills',0),(186,'People with access to agricultural inputs & services for better quality products',0),(187,'People with an increased household income',0),(188,'Percent increase in income',0),(189,'Percent increase in production volume',0),(190,'Percent of persons in the committee or cooperative is women',0),(191,'Research(es) conducted',0),(192,'Sites with improved (water) infrastructure',0),(193,'Successful cooperation(s) with relevant stakeholders established',0),(194,'Successful lobby trajectories implemented',0),(195,'Trainings organized, i.e. for target population',0),(196,'Trees on agricultural land rehabilitated',0),(197,'Warehouse facilities constructed and properly managed',0),(198,'Agri microfinance clients provided with loan',0),(199,'Agri Small & Medium Enterprises provided with loan',0),(200,'Completed agri capacity building trajectories with partner',0),(201,'Completed institutional cap. building trajectories with partner',0),(202,'Completed Social Performance Manag. capacity building trajectories with partner',0),(203,'Female microfinance clients provided with loan',0),(204,'Improved/new agri product(s) by MFI(s)',0),(205,'Learning activ. attended on rural/agri issues in sector by MFI(s)',0),(206,'Learning activities attended on SPM issues in sector by MFI(s)',0),(207,'MFI(s) that improved procedures and systems',0),(208,'MFI(s) that introduced/improved SPM',0),(209,'MFI(s) with increased agri loan portfolio',0),(210,'MFI(s) with increased loan portfolio',0),(211,'MFI(s) with increased rural loan portfolio',0),(212,'Microfinance clients provided with loan',0),(213,'Organizations supported that promote better microfinance practices',0),(214,'Percent increase in agri loan portfolio of MFI',0),(215,'Percent increase in agri loan portfolio of MFI fund',0),(216,'Percent increase in agri loan portfolio of SME fund',0),(217,'Percent increase in loan portfolio of MFI',0),(218,'Percent increase in loan portfolio of MFI fund',0),(219,'Percent increase in loan portfolio of SME fund',0),(220,'Percent increase in rural loan portfolio of MFI',0),(221,'Percent increase in rural loan portfolio of MFI fund',0),(222,'Percent increase in rural loan portfolio of SME fund',0),(223,'Rural microfinance clients provided with loan',0),(224,'Rural Small & Medium Enterprises provided with loan',0),(225,'Small & Medium Enterprises provided with loan',0),(226,'Health care institutions apply innovations and offer innovative services',0),(227,'Healthcare staff members trained',0),(228,'Improved policies and laws on national level for health and social protection',0),(229,'Institutes with increased quality services',0),(230,'Institutional deliveries ',0),(231,'Lobby trajectories on national level for health and social protection',0),(232,'Multi stakeholder approaches to strengthen health care and lobby',0),(233,'Organizations with increased capacity to improve economic security ',0),(234,'Organizations with increased organizational capacities',0),(235,'People receiving improved quality care ',0),(236,'People with increased income through innovation',0),(237,'Women receiving reproductive healthcare ',0),(238,'Women with 1-4 pregnancy checks ',0),(239,'Appropriate gender issues in the security plan',0),(240,'Benchmark sessions held between local administrators ',0),(241,'Cases brought to trial in court',0),(242,'Common agendas formulated between a multiple group of stakeholders ',0),(243,'Community groups supported to engage in peacebuilding',0),(244,'Cross border meetings between local security agents',0),(245,'Decisions on joint action in relation to crossborder security',0),(246,'Detailed and validated procedure manual(s) adopted',0),(247,'Initiatives by communities to increase their security and access to justice ',0),(248,'Meetings held between multiple group of stakeholders on security and justice ',0),(249,'Organization(s) trained on use of tools for conflict analysis and peacebuilding',0),(250,'Organization(s) trained to monitor the implementation of laws',0),(251,'Organization(s)/network(s) lobbying at local, national and/or internat. level',0),(252,'People participated in a training',0),(253,'Percent increase in delineation of tasks and responsibilities',0),(254,'Percent increase in effectiveness of collaboration ',0),(255,'Percent increase in level of trust',0),(256,'Percent increase in quality of services provided',0),(257,'Percent increase in understanding of and acknowledging the roles of institutes',0),(258,'Percent increase of access to security services',0),(259,'Percent increase of customer satisfaction of the services provided',0),(260,'Percent increase of effectiveness of women\'s employment in security sector',0),(261,'Percent increase of female staff in management functions',0),(262,'Percent of available performance subsidies disbursed',0),(263,'Percent of available performance subsidies for regulators has been disbursed',0),(264,'Percent of general public that is aware of the existence of security plans',0),(265,'Percent of general public that is satisfied with the security updates',0),(266,'Percent of governement services having specified tariffs for the most vulnerable',0),(267,'Percent of members (of which 50% are women) approve security plans',0),(268,'Percent of members in security committees that are women',0),(269,'Percent of members informed their constituency on the content of security plan',0),(270,'Percent of planned contracts are signed and renewed once a year',0),(271,'Percent of planned contracts with regulation bodies that are signed and renewed',0),(272,'Percent of planned number of verification cycles done',0),(273,'Percent of planned supervision and coaching visits by regulation bodies ',0),(274,'Percent of representation of women in decision making bodies',0),(275,'Percent of security committees convening annually to approve security priorities',0),(276,'Percent of security committees that have a constitution and bylaws',0),(277,'Percent of security plans approved by Security Committees',0),(278,'Percent of security plans differentiated between male and female priorities',0),(279,'Percent of security plans revised after one year',0),(280,'Percent of women treated with respect by government officials',0),(281,'Percent overall increase of female staff at the end of the project',0),(282,'Percent participants in training sessions that passed the final test',0),(283,'Purchasing agencies with adequate capacity established and contracted',0),(284,'Research documents published on security and justice issues ',0),(285,'Restitutions at national level',0),(286,'Security issues defined and adressed in security plan',0),(287,'Security provision services provided',0),(288,'Social auditors that have been identified and contracted ',0),(289,'Trainings on financial and projectcycle management',0),(290,'Trainings on how to influence policy on security and justice',0),(291,'Visits of lawyers that provide legal services at community level',0),(292,'Women and men having received legal advice',0),(293,'Women and men trained as paralegals',0),(294,'Women and men trained on human rights and/or local laws ',0),(295,'Agreements on multi stake holder cooperation (MoU)',0),(296,'Feasibility studies realized',0),(297,'Governance structure(s) in place ',0),(298,'Households reached with new or improved housing ',0),(299,'Households reached with new or improved sanitation facilities',0),(300,'Investors in low income housing',0),(301,'Jobs created in sanitation/wash chain',0),(302,'Jobs created related to public transport',0),(303,'Neighborhood plan(s) realized',0),(304,'Percent of amount given is an investment',0),(305,'Percent of livability of residents increased',0),(306,'Percent of residents with access to public transportation',0),(307,'Percent of support resources by government, private sector or other stakeholders',0),(308,'Stakeholders with increased capacity on housing accessibility/security ',0),(309,'Stakeholders with increased capacity on smart solution sanitation',0),(310,'Violence incidents taking place less than before',0),(311,'Youngsters with increased capacity on entrepreneurship',0),(312,'Youngsters with new jobs or own employment ',0),(313,'Collaborations between women organizations and local and international networks ',0),(314,'Community based peace and security initiatives led by women',0),(315,'Improvements in policies relevant for women\'s role in peace and security',0),(316,'Interventions to increase the security of women and women human right defenders',0),(317,'Learning and/or research trajectories on peace and security',0),(318,'Lobby & advocacy initiatives that support citizens in conflict areas',0),(319,'Women and women human right defenders receiving legal assistance',0),(320,'Women organizations and networks participating in decision making',0),(321,'Women with strengthened leadership skills',0),(322,'Women\'s organizations & networks with increased capacity in participation',0),(323,'Women\'s organizations and networks with increased capacity in influencing policy',0);
/*!40000 ALTER TABLE `rsr_benchmarkname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_budgetitem`
--

DROP TABLE IF EXISTS `rsr_budgetitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_budgetitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `label_id` int(11) NOT NULL DEFAULT '0',
  `other_extra` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rsr_budgetitem_project_id_1e985845_uniq` (`project_id`,`label_id`),
  KEY `rsr_budgetitem_499df97c` (`project_id`),
  KEY `rsr_budgetitem_63868627` (`label_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3860 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_budgetitem`
--

LOCK TABLES `rsr_budgetitem` WRITE;
/*!40000 ALTER TABLE `rsr_budgetitem` DISABLE KEYS */;
INSERT INTO `rsr_budgetitem` VALUES (2382,613,1000.00,5,''),(2383,613,6000.00,7,''),(2384,613,3000.00,4,''),(2385,613,2000.00,8,''),(3174,869,3038000.00,1,'total country budget'),(3711,789,399469.00,13,'');
/*!40000 ALTER TABLE `rsr_budgetitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_budgetitemlabel`
--

DROP TABLE IF EXISTS `rsr_budgetitemlabel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_budgetitemlabel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `label` (`label`),
  KEY `rsr_budgetitemlabel_455cf140` (`label`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_budgetitemlabel`
--

LOCK TABLES `rsr_budgetitemlabel` WRITE;
/*!40000 ALTER TABLE `rsr_budgetitemlabel` DISABLE KEYS */;
INSERT INTO `rsr_budgetitemlabel` VALUES (1,'other 1'),(2,'other 2'),(3,'other 3'),(4,'maintenance'),(5,'employment'),(6,'building material'),(7,'training'),(8,'management'),(9,'equipment'),(10,'transportation'),(11,'overhead'),(12,'PR & marketing'),(13,'total'),(14,'Total budget');
/*!40000 ALTER TABLE `rsr_budgetitemlabel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_category`
--

DROP TABLE IF EXISTS `rsr_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_category_52094d6e` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_category`
--

LOCK TABLES `rsr_category` WRITE;
/*!40000 ALTER TABLE `rsr_category` DISABLE KEYS */;
INSERT INTO `rsr_category` VALUES (1,'Water'),(2,'Sanitation'),(3,'Maintenance'),(4,'Training'),(5,'Education'),(6,'Product development'),(7,'Other'),(9,'Economic development'),(10,'ICT'),(11,'Training'),(12,'Small Business Development'),(13,'Entrepreneurship trainees'),(14,'Social Enterprise Development'),(15,'Raising awareness'),(16,'HIV / AIDS'),(17,'Telemedicine'),(18,'Training'),(19,'Medical training'),(20,'Webbased tools'),(21,'HMIS'),(22,'Agriculture'),(23,'eHealth'),(24,'Education'),(25,'Community Empowerment '),(26,'Training'),(27,'Equipment'),(28,'Health'),(29,'Economic development'),(31,'Archaeological Research'),(32,'Heritage Management'),(33,'Education and Outreach'),(34,'Eye care'),(35,'Vocational Training'),(36,'Mobiles for Development'),(37,'Hygiene'),(38,'Capacity Building'),(39,'Networking'),(40,'Lobby and Advocacy'),(43,'Disaster Recovery'),(44,'Entrepreneurship'),(45,'Food Security'),(46,'Investments'),(47,'Healthcare'),(48,'Security & Justice'),(49,'Urban Matters'),(50,'Women\'s leadership');
/*!40000 ALTER TABLE `rsr_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_category_benchmarknames`
--

DROP TABLE IF EXISTS `rsr_category_benchmarknames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_category_benchmarknames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `benchmarkname_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id` (`category_id`,`benchmarkname_id`),
  KEY `rsr_category_benchmarknames_42dc49bc` (`category_id`),
  KEY `rsr_category_benchmarknames_380bd071` (`benchmarkname_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1142 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_category_benchmarknames`
--

LOCK TABLES `rsr_category_benchmarknames` WRITE;
/*!40000 ALTER TABLE `rsr_category_benchmarknames` DISABLE KEYS */;
INSERT INTO `rsr_category_benchmarknames` VALUES (725,1,87),(724,1,132),(723,1,3),(72,4,4),(571,5,85),(646,2,2),(647,2,3),(648,2,132),(649,2,5),(519,10,49),(27,9,2),(518,10,112),(517,10,15),(516,10,14),(515,10,13),(514,10,12),(19,11,4),(513,10,10),(28,9,3),(84,12,29),(83,12,20),(31,13,17),(32,14,18),(82,12,19),(228,16,44),(61,15,32),(227,16,23),(369,17,49),(368,17,15),(370,17,24),(367,17,36),(366,17,3),(81,12,16),(80,12,4),(62,15,4),(63,15,21),(64,15,31),(79,12,35),(73,18,4),(74,19,4),(113,20,33),(114,20,34),(85,12,30),(512,10,4),(371,17,25),(104,21,34),(105,21,4),(961,22,143),(108,23,38),(793,24,117),(792,24,89),(116,25,42),(117,25,21),(123,26,20),(119,27,43),(226,16,80),(124,26,4),(791,24,86),(790,24,85),(851,28,47),(852,28,48),(853,28,21),(520,10,114),(521,10,50),(962,22,39),(960,29,127),(959,29,126),(789,24,84),(788,24,78),(958,29,125),(957,29,124),(787,24,77),(786,24,76),(785,24,64),(784,24,63),(783,24,62),(782,24,61),(199,31,65),(200,31,66),(201,31,67),(202,31,68),(203,31,69),(204,32,67),(205,32,69),(206,32,70),(207,33,73),(208,33,74),(209,33,75),(210,33,69),(781,24,60),(780,24,57),(779,24,54),(229,16,22),(230,16,79),(231,34,81),(232,34,82),(233,34,83),(778,24,53),(777,24,46),(776,24,45),(259,35,86),(258,35,53),(257,35,84),(256,35,85),(260,35,45),(726,1,111),(406,36,88),(775,24,41),(774,24,40),(854,28,87),(407,36,91),(850,28,141),(956,29,116),(955,29,115),(511,10,3),(645,2,97),(644,2,96),(365,17,2),(372,17,26),(509,37,118),(374,38,99),(375,38,100),(376,38,101),(377,38,102),(378,38,103),(379,38,104),(380,39,105),(381,39,106),(382,39,107),(383,39,108),(533,40,109),(534,40,110),(722,1,2),(522,10,119),(532,40,113),(408,36,21),(510,10,2),(954,29,93),(953,29,56),(773,24,136),(523,10,95),(531,40,120),(535,40,121),(727,1,119),(772,24,4),(570,5,4),(569,5,114),(568,5,84),(952,29,55),(951,29,52),(950,29,51),(949,29,21),(948,29,144),(947,29,15),(946,29,142),(945,29,2),(650,2,6),(944,29,139),(943,29,138),(942,29,136),(855,28,92),(721,1,1),(728,1,122),(941,29,135),(940,29,134),(794,24,123),(939,29,133),(938,29,132),(849,28,140),(856,28,62),(937,29,130),(936,29,129),(935,29,128),(963,43,146),(964,43,147),(965,43,148),(966,43,149),(967,43,150),(968,43,151),(969,43,152),(970,43,153),(971,43,154),(972,43,155),(973,43,156),(974,43,157),(975,43,158),(976,43,159),(977,43,160),(978,43,161),(979,43,162),(980,43,163),(981,43,164),(982,43,165),(983,43,166),(984,43,167),(985,43,168),(986,44,169),(987,44,170),(988,44,171),(989,44,172),(990,44,173),(991,44,174),(992,44,175),(993,44,176),(994,44,177),(995,44,178),(996,45,179),(997,45,180),(998,45,181),(999,45,182),(1000,45,183),(1001,45,184),(1002,45,185),(1003,45,186),(1004,45,187),(1005,45,188),(1006,45,189),(1007,45,190),(1008,45,191),(1009,45,192),(1010,45,193),(1011,45,194),(1012,45,195),(1013,45,196),(1014,45,197),(1015,46,198),(1016,46,199),(1017,46,200),(1018,46,201),(1019,46,202),(1020,46,203),(1021,46,204),(1022,46,205),(1023,46,206),(1024,46,207),(1025,46,208),(1026,46,209),(1027,46,210),(1028,46,211),(1029,46,212),(1030,46,213),(1031,46,214),(1032,46,215),(1033,46,216),(1034,46,217),(1035,46,218),(1036,46,219),(1037,46,220),(1038,46,221),(1039,46,222),(1040,46,223),(1041,46,224),(1042,46,225),(1043,47,226),(1044,47,227),(1045,47,228),(1046,47,229),(1047,47,230),(1048,47,231),(1049,47,232),(1050,47,233),(1051,47,234),(1052,47,235),(1053,47,236),(1054,47,237),(1055,47,238),(1056,48,239),(1057,48,240),(1058,48,241),(1059,48,242),(1060,48,243),(1061,48,244),(1062,48,245),(1063,48,246),(1064,48,247),(1065,48,248),(1066,48,249),(1067,48,250),(1068,48,251),(1069,48,252),(1070,48,253),(1071,48,254),(1072,48,255),(1073,48,256),(1074,48,257),(1075,48,258),(1076,48,259),(1077,48,260),(1078,48,261),(1079,48,262),(1080,48,263),(1081,48,264),(1082,48,265),(1083,48,266),(1084,48,267),(1085,48,268),(1086,48,269),(1087,48,270),(1088,48,271),(1089,48,272),(1090,48,273),(1091,48,274),(1092,48,275),(1093,48,276),(1094,48,277),(1095,48,278),(1096,48,279),(1097,48,280),(1098,48,281),(1099,48,282),(1100,48,66),(1101,48,283),(1102,48,284),(1103,48,285),(1104,48,286),(1105,48,287),(1106,48,288),(1107,48,289),(1108,48,290),(1109,48,291),(1110,48,292),(1111,48,293),(1112,48,294),(1113,49,295),(1114,49,296),(1115,49,297),(1116,49,298),(1117,49,299),(1118,49,300),(1119,49,301),(1120,49,302),(1121,49,303),(1122,49,304),(1123,49,305),(1124,49,306),(1125,49,307),(1126,49,308),(1127,49,309),(1128,49,310),(1129,49,311),(1130,49,312),(1131,50,313),(1132,50,314),(1133,50,315),(1134,50,316),(1135,50,317),(1136,50,318),(1137,50,319),(1138,50,320),(1139,50,321),(1140,50,322),(1141,50,323);
/*!40000 ALTER TABLE `rsr_category_benchmarknames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_category_focus_area`
--

DROP TABLE IF EXISTS `rsr_category_focus_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_category_focus_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `focusarea_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id` (`category_id`,`focusarea_id`),
  KEY `rsr_category_focus_area_42dc49bc` (`category_id`),
  KEY `rsr_category_focus_area_4654c856` (`focusarea_id`)
) ENGINE=MyISAM AUTO_INCREMENT=166 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_category_focus_area`
--

LOCK TABLES `rsr_category_focus_area` WRITE;
/*!40000 ALTER TABLE `rsr_category_focus_area` DISABLE KEYS */;
INSERT INTO `rsr_category_focus_area` VALUES (143,1,2),(137,2,2),(3,3,2),(33,4,2),(131,5,2),(6,6,2),(7,7,2),(13,9,22),(121,10,22),(11,11,22),(38,12,21),(15,13,21),(16,14,21),(30,15,20),(74,16,20),(99,17,22),(98,17,20),(34,18,19),(35,19,20),(50,20,20),(44,21,20),(155,22,21),(46,23,20),(146,24,19),(53,25,20),(57,26,20),(55,27,20),(150,28,20),(154,29,21),(70,31,19),(71,32,21),(72,33,19),(76,34,20),(79,35,19),(110,36,22),(120,37,2),(102,38,2),(104,39,2),(126,40,2),(127,40,20),(158,43,21),(159,44,21),(160,45,20),(161,46,21),(162,47,20),(163,48,21),(164,49,21),(165,50,21);
/*!40000 ALTER TABLE `rsr_category_focus_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_country`
--

DROP TABLE IF EXISTS `rsr_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `iso_code` varchar(2) NOT NULL,
  `continent` varchar(20) NOT NULL,
  `continent_code` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `iso_code` (`iso_code`),
  KEY `rsr_country_5d41016a` (`continent`),
  KEY `rsr_country_4cc7b05e` (`iso_code`),
  KEY `rsr_country_548fab9d` (`continent_code`)
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_country`
--

LOCK TABLES `rsr_country` WRITE;
/*!40000 ALTER TABLE `rsr_country` DISABLE KEYS */;
INSERT INTO `rsr_country` VALUES (1,'Tanzania, United Republic of','tz','Africa','af'),(2,'India','in','Asia','as'),(3,'Netherlands','nl','Europe','eu'),(4,'Bangladesh','bd','Asia','as'),(5,'United States','us','North America','na'),(6,'Madagascar','mg','Africa','af'),(8,'Cameroon','cm','Africa','af'),(9,'Nepal','np','Asia','as'),(10,'Malawi','mw','Africa','af'),(11,'Ghana','gh','Africa','af'),(12,'Ethiopia','et','Africa','af'),(13,'France','fr','Europe','eu'),(14,'Armenia','am','Asia','as'),(15,'Romania','ro','Europe','eu'),(16,'Georgia','ge','Asia','as'),(17,'Ukraine','ua','Europe','eu'),(18,'Sweden','se','Europe','eu'),(19,'Uzbekistan','uz','Asia','as'),(20,'Nigeria','ng','Africa','af'),(21,'Uganda','ug','Africa','af'),(22,'Somalia','so','Africa','af'),(23,'Germany','de','Europe','eu'),(24,'Burkina Faso','bf','Africa','af'),(25,'Zambia','zm','Africa','af'),(26,'Switzerland','ch','Europe','eu'),(27,'Kenya','ke','Africa','af'),(28,'Mali','ml','Africa','af'),(29,'Sudan','sd','Africa','af'),(31,'Mauritania','mr','Africa','af'),(32,'Philippines','ph','Asia','as'),(33,'Thailand','th','Asia','as'),(34,'Cyprus','cy','Asia','as'),(35,'Senegal','sn','Africa','af'),(36,'South Africa','za','Africa','af'),(37,'Rwanda','rw','Africa','af'),(38,'Norway','no','Europe','eu'),(39,'United Kingdom','gb','Europe','eu'),(40,'Liberia','lr','Africa','af'),(41,'Colombia','co','South America','sa'),(42,'Sierra Leone','sl','Africa','af'),(43,'Viet Nam','vn','Asia','as'),(44,'Niger','ne','Africa','af'),(45,'China','cn','Asia','as'),(46,'Zimbabwe','zw','Africa','af'),(47,'Singapore','sg','Asia','as'),(48,'Cambodia','kh','Asia','as'),(49,'Italy','it','Europe','eu'),(50,'Canada','ca','North America','na'),(51,'Mexico','mx','North America','na'),(52,'Guatemala','gt','North America','na'),(53,'Mozambique','mz','Africa','af'),(54,'Guinea-bissau','gw','Africa','af'),(55,'Indonesia','id','Asia','as'),(56,'Honduras','hn','North America','na'),(57,'Australia','au','Oceania','oc'),(58,'Haiti','ht','North America','na'),(59,'Sri Lanka','lk','Asia','as'),(60,'Argentina','ar','South America','sa'),(61,'Brazil','br','South America','sa'),(62,'Egypt','eg','Africa','af'),(63,'Morocco','ma','Africa','af'),(64,'Spain','es','Europe','eu'),(65,'Hong Kong','hk','Asia','as'),(66,'Nicaragua','ni','North America','na'),(67,'Panama','pa','North America','na'),(68,'Ecuador','ec','South America','sa'),(69,'Paraguay','py','South America','sa'),(70,'Myanmar','mm','Asia','as'),(71,'Belgium','be','Europe','eu'),(72,'Congo, The Democratic Republic of the','cd','Africa','af'),(73,'Malta','mt','Europe','eu'),(74,'Palestinian Territory, Occupied','ps','Asia','as'),(75,'Slovakia','sk','Europe','eu'),(76,'Finland','fi','Europe','eu'),(77,'Saudi Arabia','sa','Asia','as'),(78,'Kazakhstan','kz','Asia','as'),(79,'Bolivia, Plurinational State of','bo','South America','sa'),(80,'Peru','pe','South America','sa'),(81,'Benin','bj','Africa','af'),(82,'Côte D\'ivoire','ci','Africa','af'),(83,'Malaysia','my','Asia','as'),(84,'Afghanistan','af','Asia','as'),(85,'Central African Republic','cf','Africa','af'),(86,'Montenegro','me','Europe','eu'),(87,'Namibia','na','Africa','af'),(88,'South Sudan','ss','Africa','af'),(89,'Kyrgyzstan','kg','Asia','as'),(90,'Macedonia, The Former Yugoslav Republic of','mk','Europe','eu'),(91,'Moldova, Republic of','md','Europe','eu'),(92,'Serbia','rs','Europe','eu'),(93,'Belarus','by','Europe','eu'),(94,'Kuwait','kw','Asia','as'),(95,'Russian Federation','ru','Europe','eu'),(96,'Jordan','jo','Asia','as'),(97,'Hungary','hu','Europe','eu'),(98,'Turkmenistan','tm','Asia','as'),(99,'Congo','cg','Africa','af'),(100,'Suriname','sr','South America','sa'),(101,'Czech Republic','cz','Europe','eu'),(102,'Albania','al','Europe','eu'),(103,'Bosnia and Herzegovina','ba','Europe','eu'),(104,'Lebanon','lb','Asia','as'),(105,'Burundi','bi','Africa','af'),(106,'Pakistan','pk','Asia','as'),(107,'Luxembourg','lu','Europe','eu'),(108,'Mongolia','mn','Asia','as'),(109,'El Salvador','sv','North America','na'),(110,'Croatia','hr','Europe','eu'),(111,'Kosovo','xk','Europe','eu'),(112,'Swaziland','sz','Africa','af'),(113,'Angola','ao','Africa','af'),(114,'Israel','il','Asia','as');
/*!40000 ALTER TABLE `rsr_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_focusarea`
--

DROP TABLE IF EXISTS `rsr_focusarea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_focusarea` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(100) NOT NULL,
  `link_to` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_focusarea_56ae2a2a` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_focusarea`
--

LOCK TABLES `rsr_focusarea` WRITE;
/*!40000 ALTER TABLE `rsr_focusarea` DISABLE KEYS */;
INSERT INTO `rsr_focusarea` VALUES (3,'All','all','In Akvo RSR every development project has its own internet page and people involved can share project updates easily online. Here you can filter, view and browse projects on the Akvo system, monitor progress or make a donation.\r\n\r\nWe also have <a href=\"/rsr/maps/projects/all/\">a map of all projects</a>.<br />\r\nFind a particular organisation in our <a href=\"/rsr/organisations/all/\">database</a> or on a <a href=\"/rsr/maps/organisations/all/\">map</a>.','db/focus_area/pratap-nagar-all-focus-500x375.jpg',''),(2,'Water and sanitation','water-and-sanitation','2.6 billion people lack sanitation and 800 million can\'t access safe drinking water. The impact of this is dramatic. A dozen jumbo jet loads of children die every day from related illness and a vast body of people remain unable to contribute to the world’s growth.','db/focus_area/water-santiation-focus.jpg',''),(19,'Education','education','Good primary and secondary education transforms communities and livelihoods. Vocational training helps people get work and start businesses.','db/focus_area/education-focus.jpg',''),(20,'Healthcare','healthcare','Health is one of the fundamental universal human rights. Yet many people live in unhealthy conditions and do not have access to health care, with the poor, women, children and disabled people being particularly vulnerable.','db/focus_area/healthcare-focus.jpg',''),(21,'Economic development','economic-development','Small-scale producers in rural and urban areas can be hit dramatically by international competition, the effects of climate change, and fluctuations in food or energy prices. Many of these entrepreneurs, often farmers, are chronically poor. Yet they can thrive if they have access to wider markets, financial services and development assistance.','db/focus_area/economic-development-focus.jpg',''),(22,'IT and communication','it-and-communication','Many now have access to mobile phones long before they get decent education, water supply, sanitation and many other services. By making the most of mobiles, the web, PCs and more traditional media such as radio, tremendous development is possible in a short space of time.','db/focus_area/ict-focus.jpg','');
/*!40000 ALTER TABLE `rsr_focusarea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_goal`
--

DROP TABLE IF EXISTS `rsr_goal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_goal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `text` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_goal_499df97c` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3764 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_goal`
--

LOCK TABLES `rsr_goal` WRITE;
/*!40000 ALTER TABLE `rsr_goal` DISABLE KEYS */;
INSERT INTO `rsr_goal` VALUES (2161,613,'Number of NAS Training courses run in Vietnam'),(2162,613,'Translate NAS training into Vietnamese '),(3365,789,'Install appropriate water technologies to improve access and wate'),(3368,789,'Provide WASH education to communities and schools'),(3367,789,'Strengthen Aguayuda’s Mobile WASH Support Service Model to ensure sustainability of clean water'),(3366,789,'Pilot and adapt composting latrines for effective use'),(2959,869,'Increased utilization and quality of comprehensive SRH services'),(2960,869,'Increased quality and delivery of Comprehensive Sexuality Education (CSE)'),(2961,869,'Reduction of Sexual and Gender Based Violence (SGBV)'),(2962,869,'Increased acceptance of Sexual Diversity and Gender Identity');
/*!40000 ALTER TABLE `rsr_goal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_internalorganisationid`
--

DROP TABLE IF EXISTS `rsr_internalorganisationid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_internalorganisationid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recording_org_id` int(11) NOT NULL,
  `referenced_org_id` int(11) NOT NULL,
  `identifier` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rsr_internalorganisationid_recording_org_id_6a7aec8b_uniq` (`recording_org_id`,`referenced_org_id`),
  KEY `rsr_internalorganisationid_785d5e0d` (`recording_org_id`),
  KEY `rsr_internalorganisationid_235cbec0` (`referenced_org_id`)
) ENGINE=MyISAM AUTO_INCREMENT=169 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_internalorganisationid`
--

LOCK TABLES `rsr_internalorganisationid` WRITE;
/*!40000 ALTER TABLE `rsr_internalorganisationid` DISABLE KEYS */;
/*!40000 ALTER TABLE `rsr_internalorganisationid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_invoice`
--

DROP TABLE IF EXISTS `rsr_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test` tinyint(1) NOT NULL,
  `engine` varchar(10) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  `amount_received` decimal(10,2) DEFAULT NULL,
  `time` datetime NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `status` smallint(5) unsigned NOT NULL,
  `http_referer` varchar(255) NOT NULL,
  `campaign_code` varchar(15) NOT NULL,
  `is_anonymous` tinyint(1) NOT NULL,
  `ipn` varchar(75) DEFAULT NULL,
  `bank` varchar(4) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_invoice_403f60f` (`user_id`),
  KEY `rsr_invoice_499df97c` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1371 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_invoice`
--

LOCK TABLES `rsr_invoice` WRITE;
/*!40000 ALTER TABLE `rsr_invoice` DISABLE KEYS */;
INSERT INTO `rsr_invoice` VALUES (1100,0,'paypal',NULL,613,25,23.72,'2012-09-21 06:32:40','Roberto ','robjunco@mac.com',3,'http://projects.commonsites.net/en/project/613/','',0,'4BT46936UD816970E','',''),(1104,0,'paypal',NULL,613,50,48.45,'2012-09-21 19:33:57','James P Delgado','james.delgado@noaa.gov',3,'http://projects.commonsites.net/en/project/613/','',0,'39F29428E93220638','',''),(1172,0,'paypal',NULL,613,128,NULL,'2012-11-02 07:55:17','Hiroaki Miyashita','hello@mxp.mesh.ne.jp',4,'http://projects.commonsites.net/en/project/613/','',1,NULL,'',''),(1173,0,'paypal',NULL,613,128,NULL,'2012-11-02 08:02:45','Hiroaki Miyashita','hello@mxp.mesh.ne.jp',4,'http://www.akvo.org/rsr/project/613/funding/','',1,NULL,'',''),(1241,0,'paypal',NULL,613,20,18.91,'2013-01-08 02:38:30','Amer Khan','contactamer@yahoo.com',3,'http://commonsites.akvoapp.org/en/project/613/funding/','',0,'08Y498357M597264F','','');
/*!40000 ALTER TABLE `rsr_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_link`
--

DROP TABLE IF EXISTS `rsr_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` varchar(1) NOT NULL,
  `url` varchar(200) NOT NULL,
  `caption` varchar(50) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_link_499df97c` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1367 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_link`
--

LOCK TABLES `rsr_link` WRITE;
/*!40000 ALTER TABLE `rsr_link` DISABLE KEYS */;
INSERT INTO `rsr_link` VALUES (876,'E','http://www.causes.com/causes/794053-underwater-cultural-heritage-in-vietnam','Causes Page',613),(869,'E','http://www.nauticalarchaeologysociety.org/','Nautical Archaeology Society website',613),(1355,'E','http://www.aguayuda.org/','Aguayuda website',789),(1301,'E','http://www.awazcds.org.pk/','AWAZCDS ',869),(1302,'E','http://www.pidsnpo.org/','PIDS ',869),(1303,'E','http://www.rutgerswpfpak.org/','Rutgers WPF Pakistan',869);
/*!40000 ALTER TABLE `rsr_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_link_copy`
--

DROP TABLE IF EXISTS `rsr_link_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_link_copy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` varchar(1) NOT NULL,
  `url` varchar(200) NOT NULL,
  `caption` varchar(50) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_link_499df97c` (`project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_link_copy`
--

LOCK TABLES `rsr_link_copy` WRITE;
/*!40000 ALTER TABLE `rsr_link_copy` DISABLE KEYS */;
/*!40000 ALTER TABLE `rsr_link_copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_minicms`
--

DROP TABLE IF EXISTS `rsr_minicms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_minicms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL,
  `feature_box` longtext NOT NULL,
  `feature_image` varchar(100) NOT NULL,
  `top_right_box` longtext NOT NULL,
  `lower_height` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_minicms`
--

LOCK TABLES `rsr_minicms` WRITE;
/*!40000 ALTER TABLE `rsr_minicms` DISABLE KEYS */;
INSERT INTO `rsr_minicms` VALUES (13,'Akvo programmes - Spring 2013','<nav>\r\n  <ul>\r\n    <li style=\"position:absolute; display:block; width:160px; height:50px;top:183px; left:167px;\"><a href=\"http://www.openaid.nl/\" style=\" display:block; text-indent:-99999px; cursor:pointer;\">Akvo Openaid</a></li>\r\n    <li style=\"position:absolute; display:block; width:160px; height:50px; top:18px; left:357px;\"><a href=\"http://www.akvo.org/web/introducing-akvo-flow\" style=\" display:block; text-indent:-99999px; cursor:pointer;\">Akvo Flow</a></li>\r\n    <li style=\"position:absolute; display:block; width:160px; height:50px; top:273px; left:337px;\"><a href=\"http://www.akvo.org/web/akvo-rsr\" style=\" display:block; text-indent:-99999px; cursor:pointer;\">Akvo RSR</a></li>\r\n    <li style=\"position:absolute; display:block; width:160px; height:50px;  top:73px; left:157px;\"><a href=\"http://akvopedia.org/\" style=\" display:block; text-indent:-99999px; cursor:pointer;\">Akvopedia</a></li>\r\n  </ul>\r\n\r\n\r\n\r\n</nav>\r\n\r\n\r\n<div class=\"bottom right full\">\r\n<div class=\"text_bg\">\r\n\r\n<h1 style=\"text-align:right\" class=\"serif\"><a href=\"/blog/?p=8753\">Akvo programmes, in Spring 2013.</a> <a href=\"/blog/?p=8753\"></h1>\r\n\r\n<p style=\"text-align:right\" class=\"white\"><a href=\"/blog/?p=4822\">Learn how Akvo helps you achieve more with less.</a> <a href=\"/blog/?p=4822\"><span class=\"link_triangle\">&#x25B6;</span></a></p>\r\n</div>\r\n</div>','db/home_page/metro_map_perspective.jpg','<h1 class=\"serif\">Akvo makes it easy to bring development aid projects online</h1>\r\n\r\n<p>Akvo RSR means Really Simple Reporting. Use it to bring projects to life with photo, text and video updates.  <a href=\"/web/akvo-rsr\">Learn more </a> <a href=\"/web/akvo-rsr\"><span class=\"link_triangle\">&#x25B6;</span></a></p>\r\n\r\n<h2 class=\"serif\">Introducing Akvo FLOW</h2>\r\n\r\n<p>Collect, analyse and display geographic monitoring data, using mobile phones. <a href=\"/web/introducing-akvo-flow\">Learn more </a> <a href=\"/web/introducing-akvo-flow\"><span class=\"link_triangle\">&#x25B6;</span></a></p>',570,1);
/*!40000 ALTER TABLE `rsr_minicms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_molliegateway`
--

DROP TABLE IF EXISTS `rsr_molliegateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_molliegateway` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `currency` varchar(3) NOT NULL,
  `notification_email` varchar(75) NOT NULL,
  `partner_id` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_molliegateway`
--

LOCK TABLES `rsr_molliegateway` WRITE;
/*!40000 ALTER TABLE `rsr_molliegateway` DISABLE KEYS */;
INSERT INTO `rsr_molliegateway` VALUES (1,'Default','Default Akvo Mollie/iDEAL payment gateway','EUR','thomas@akvo.org','325955');
/*!40000 ALTER TABLE `rsr_molliegateway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_organisation`
--

DROP TABLE IF EXISTS `rsr_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_organisation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `long_name` varchar(75) NOT NULL,
  `organisation_type` varchar(1) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `contact_person` varchar(30) NOT NULL,
  `contact_email` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `primary_location_id` int(11) DEFAULT NULL,
  `iati_org_id` varchar(75) DEFAULT NULL,
  `language` varchar(2) NOT NULL,
  `new_organisation_type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rsr_organisation_iati_org_id_f90678c_uniq` (`iati_org_id`),
  KEY `rsr_organisation_25153470` (`primary_location_id`),
  KEY `rsr_organisation_3e4f4851` (`organisation_type`),
  KEY `rsr_organisation_52094d6e` (`name`),
  KEY `rsr_organisation_7de79f50` (`iati_org_id`),
  KEY `rsr_organisation_46f091bc` (`new_organisation_type`)
) ENGINE=MyISAM AUTO_INCREMENT=1439 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_organisation`
--

LOCK TABLES `rsr_organisation` WRITE;
/*!40000 ALTER TABLE `rsr_organisation` DISABLE KEYS */;
INSERT INTO `rsr_organisation` VALUES (360,'CommonSites','CommonSites.net','N','db/org/360/Organisation_360_logo_2011-06-06_11.45.21.jpg','http://www.commonsites.net/','','','','Sjoerd van der Linde','info@commonsites.net','CommonSites is an international initiative that provides a unique web-based platform for the heritage sector. It is designed to unite funding bodies and project partners to benefit local communities. Our web-based platform uses Akvo\'s software, and increases the visibility of heritage projects for all who are involved, whether they be funders, project partners, academic institutions or members of local communities. Partners can use CommonSites to find and share knowledge, raise funds and simplifiy reporting back to donors.    ',138,NULL,'en',22),(841,'Monash University','Monash University','K','db/org/841/Organisation_841_logo_2012-09-18_16.07.06.tiff','http://monash.edu/','613 99020879','61 (0)408 802 198','613 9905 2946','Mark Staniforth','mark.staniforth@monash.edu','Monash is a university of transformation. The desire to make a difference informs everything we do.\r\nWe see a brighter future as more than just possible - it is something for which we are directly responsible; something we can help create.',746,NULL,'en',80),(842,'The Asia Research Centre','The Asia Research Centre','K','db/org/842/Organisation_842_logo_2012-09-18_16.11.52.tiff','http://wwwarc.murdoch.edu.au/','+61(8)93606659','+61(411)518414','+61(8)9360 6381','Dr. Jun Kimura','J.Kimura@murdoch.edu.au','The Asia Research Centre at Murdoch University was first established in 1988. Then in 1991, through a nationally competitive process, it became a Special Research of the Australian Research Council.  \r\n\r\nAs one of only two federally-funded special research centres on Asia in Australia, its brief was to enhance Australia’s understanding of its Asian environments by providing analysis of social, political, cultural, and economic change in East and Southeast Asia. \r\n\r\nThe Asia Research Centre develops several strategies to maintain its role as an internationally recognized leader in research on contemporary Asia. In line with this, key projects in 2000 examined globalization as well as national and local systems of governance, and cross-border policy issues including human impact of animal diseases, environmentally sustainable settlements and reverse migration. \r\n\r\nThe Centre was reconstituted in 2002 as a divisional centre at Murdoch University. Since then its objectives have been to: produce high quality academic research publications for international and domestic audiences; foster the development of high research graduates; and contribute constructively to public policy debate and public understanding on various issues concerning Asia. \r\n',747,NULL,'en',80),(843,'NAS','Nautical Archaeology Society','N','db/org/843/Organisation_843_logo_2012-09-18_16.16.26.png','http://www.nauticalarchaeologysociety.org/','44 (0) 2392 819419','44 (0)7969028678','44 (0) 2392 819419','Mark Beattie-Edwards','mark@nauticalarchaeologysociety.org','The Nautical Archaeology Society (NAS) is a charity registered in England and Wales (Registration number 264209) and registered in Scotland (Registration number SC040130). The Society is a company limited by guarantee, registered in England and Wales (Company number 01039270).\r\n\r\nThe Nautical Archaeology Society was formed to actively involve members of the public, locally, nationally and internationally in preserving and studying their maritime heritage.  The NAS believes that preserving a record of the past is vital, and it is important that this record is as accurate as possible.  For this reason, over the last thirty seven years, the NAS has worked towards advancing education in nautical archaeology at all levels; towards improving and standardising techniques in survey, excavation and reporting; and towards publishing detailed and comprehensive journals, newsletters and guides on maritime heritage.',748,NULL,'en',22),(844,'Institute of Archaeology','Institute of Archaeology','G','','http://www.khaocohoc.gov.vn/','84-04-39333858','0936069292','','Lien Le Thi','lelien_thi@hotmail.com','The Institute of Archaeology (IA) was established in 1968. It belongs to the Vietnamese Academy of Social Sciences. The IA responds to the researches on the fundamental issues of Vietnamese archaeology, to conduct the studies on the formation and development of the Vietnamese people; to provide scientific basis to the determination of policy and strategy, planning and guideline for the reinforcement of the Vietnamese culture. The IA responds also to the advisory and graduated training on archaeology, participating in the conservation and development of cultural heritage of Vietnam.',749,NULL,'en',10),(912,'SRHR Alliance','Sexual and Reproductive Health and Rights Alliance','N','db/org/912/Organisation_912_logo_2013-03-27_14.19.43.jpg','','31 (0)30 2313431','','','Marijke Priesters','m.priester@rutgerswpf.nl','The SRHR Alliance implements the programme Unite for Body Rights in the period 2011 till 2015. Rutgers WPF is the lead agent. The Unite for Body Rights Programme is a substantial programme (44 mln. Euro) financed by the Dutch Ministry of Foreign Affairs. The programme supports partner organisations in Asia (Bangladesh, India, Indonesia and Pakistan) and Africa (Ethiopia, Kenya, Malawi, Uganda and Tanzania) improving the sexual and reproductive health and rights of young people, women and marginalized groups. This Alliance will be able to reach a total of approximately 2.5 million people in Africa and Asia. ',819,NULL,'en',22),(947,'MWA','Milllenium Water Alliance','N','db/org/947/Organisation_947_logo_2012-11-28_11.30.15.png','http://mwawater.org/','(202) 296-1832','','','','','At the 2002 World Summit for Sustainable Development, then-Secretary of State Colin Powell announced the U.S. commitment to the Goals for Sustainable Development. One goal was to “reduce by half, the proportion of people without access to safe and affordable drinking water and sanitation” by the year 2015.\r\n\r\nTo help reach this goal, leading US-based non-governmental organizations working in water and sanitation formed the Millennium Water Alliance (MWA) as a 501(c)(3) organization to offer sustainable solutions through advocacy, shared knowledge, and collaborative programming. Our vision mirrors our belief that no one should die or suffer chronic illness as the result of a water-related disease.\r\n\r\nFrom 2003 on, MWA has created consortium field programs in which member NGOs bring their strengths and share ideas on effective approaches, for maximum efficiency and long-term effectiveness. Our major field programs to date operate in Ethiopia, Kenya, and four countries in Central America',854,NULL,'en',22),(969,'Akvo FLOW','Akvo FLOW','N','db/org/969/Organisation_969_logo_2012-12-13_10.11.55.png','http://www.akvo.org/','0031 20 8200175','','','Jeroen van der Sommen','jeroen@akvo.org','Akvo FLOW is a software tool that collects, manages, analyses and displays geographically referenced monitoring and evaluation data using mobile phones. It lets you create simple or complex surveys on any topic. The diversity is endless - surveys can include photos, videos, barcodes, and audio clips. Users have total flexibility to collect the information that will make an impact on their project.\r\n\r\nPhones can store hundreds of surveys and data can be collected in areas where there is no mobile connection – Akvo FLOW automatically transmits the data once a connection is detected, so the system can be used anywhere in the world. Akvo FLOW has been under development for several years with significant field implementations already under its belt.\r\n\r\nAkvo FLOW brings together three elements:\r\n- Handheld data collection – the Akvo FLOW Field Survey application runs on Android phones with integrated GPS, camera, and custom adaptive surveys.\r\n- A web-based dashboard where users manage and analyse Akvo FLOW surveys and data.\r\n- Visual map-based reporting tools displayed in Google Maps and Google Earth.',873,NULL,'en',22),(1024,'PIDS Pakistan','Participatory Integrated Development Society','N','db/org/1024/Organisation_1024_logo_2013-01-16_09.15.33.jpg','http://www.pidsnpo.org/','+92 812863587- 88','03003841566','+92 812863589','Baber Shak Khan','cepids@hotmail.com','Vision\r\nA Healthy, Educated and Prosperous Society in Balochistan\r\n\r\nMission \r\nPIDS mission is to facilitate the process of sustainable community development through a set of services in:\r\n- Community Physical Infrastructure\r\n- Human Resource Development\r\n- Education\r\n- Information Technology\r\n- Emergency Relief with special focus on women and  children\'s\r\n\r\nObjectives\r\n- To have access to basic community physical infrastructure in order to support poor communities through participatory processes\r\n- To assist people to live in hygienic and healthy atmosphere through launching awareness campaigns, training sessions and sanitation -promotion activities\r\n- To develop and activate human resources in CPI, Education, I.T and Emergency Relief sectors\r\n- To support communities to bring improvements in sectors: CPI, Education and Emergency Relief\r\n- To advocate for generation of more and more resources to continue with support programs\r\n- To improve organizational capacity and efficiency\r\n- To collaborate with other stakeholders on issues of program development\r\n',923,NULL,'en',22),(1026,'Awaz Foundation Pakistan','Awaz Foundation Pakistan: Centre for Development Services','N','db/org/1026/Organisation_1026_logo_2013-01-15_11.03.50.png','http://www.awazcds.org.pk/','+92-61-4784606','+92-300-6301215','+92-61-4584909','Mohammad Zia-ur-Rehman','zia@awazcds.org.pk','Awaz Foundation Pakistan: Centre for Development Services is striving for the Socio-economic development and political empowerment of marginalized communities especially women and young people across Pakistan since 1995. AWAZ follows rights based approaches for sustainable development, poverty alleviation, achieving MDGs and Consultative status of UN-ECOSOC  in 2012 and is also certified from Pakistan Centre of Philanthropy.  \r\n\r\nAwazCDS has been leading Global Call to Action against Poverty (GCAP) coalition in Pakistan and as Regional Coordinator of South Asian since 2011.\r\n\r\nVision\r\nAwazCDS\'s vision is a democratic, prosperous and peaceful society by working together with local, national, regional, international bodies and partners.\r\n\r\nMission\r\nAwazCDS\'s mission is to develop and provide integrated and innovative solutions in cooperation with local, national, regional, and international partners, which foster action and change for securing the future of the marginalised community.\r\n\r\nActivities\r\nCommunity Mobilization, capacity building, livelihood and entrepreneurship, research & policy level advocacy.',925,NULL,'en',22),(1036,'RWPF Pakistan','Rutgers WPF Pakistan','N','db/org/1036/Organisation_1036_logo_2013-01-17_10.42.42.jpg','http://www.rutgerswpfpak.org/','+92 (0)51 211 05 39','','+92 (0)51 211 05 36','Mr. Qadeer Baig','qadeer.baig@rutgerswpfpak.org','Rutgers WPF is a renowned centre of expertise on sexual and reproductive health and rights. Its activities are mainly carried out in the Netherlands, Africa and Asia. Its aim is to improve sexual and reproductive health and rights throughout the world. Rutgers WPF supports partner organizations and professionals in their work, increasing their expertise on sexuality.\r\n\r\nAs of 1st January 2011 World Population Foundation and Rutgers Nisso Groep have merged into Rutgers WPF.',935,NULL,'en',22),(1043,'Rutgers WPF','Rutgers WPF','N','db/org/1043/Organisation_1043_logo_2013-01-25_15.18.37.jpg','http://www.rutgerswpf.nl/','0031 (0)30 231 34 31','','0031 (0)30 231 93 87','','office@rutgerswpf.nl','ENG\r\nRutgers WPF is a renowned centre of expertise on sexual and reproductive health and rights. Its activities are mainly carried out in the Netherlands, Africa and Asia. Its aim is to improve sexual and reproductive health and rights throughout the world. Rutgers WPF supports partner organisations and professionals in their work, increasing their expertise on sexuality.\r\nRutgers WPF envisages a world in which all people are equally able to enjoy sexual and reproductive health and well-being, and exercise their sexual and reproductive rights.\r\n\r\nNL\r\nRutgers WPF is een gerenommeerd kenniscentrum. Al jaren werken wij in Nederland, Afrika en Azië aan de verbetering van seksuele en reproductieve gezondheid en rechten.\r\nRutgers WPF streeft naar een wereld waarin seksuele en reproductieve gezondheid en welzijn voor iedereen ruim baan krijgen en waarin een ieder zijn of haar seksuele en reproductieve rechten kan laten gelden. ',940,NULL,'en',22),(1054,'Aguayuda','Aguayuda','N','db/org/1054/Organisation_1054_logo_2013-05-29_17.54.40.jpg','http://www.aguayuda.org/','+1 (410) 463-1455','','','Sabrina Zimmerman','','Vision\r\nBy 2014, Aguayuda will empower 20,000 people in poor rural communities with the tools and knowledge to improve their quality of life.\r\n\r\nMission\r\nImprove life and health in poor rural communities through clean water and education.\r\n\r\nAguayuda is proud to report that since our inception in 2006, we have installed and repaired windmills, implemented pipelines, installed rain harvesting systems, repaired water storage tanks, built laundry washing stations, maintained a water truck sponsorship program and created four educational manuals on essential health topics. These accomplishments have provided 4,300 people access to clean water on a daily basis. As additional positive results of Aguayuda’s efforts, a local community built nineteen new homes and one of Aguayuda’s water committee members established a non-profit organization that installs, repairs and maintains windmills. Lastly, Aguayuda has non-profit organizations supporting Aguayuda’s mission in Germany and in Colombia.\r\n\r\nThrough these valuable experiences, Aguayuda has developed sustainable and practical solutions. Thanks to the hard work and continued generous support from a diverse group of people and organizations worldwide, Aguayuda continues to improve the health and lives of impoverished people worldwide.',954,NULL,'en',22),(1095,'Improve International','Improve International','N','db/org/1095/Organisation_1095_logo_2013-02-18_22.28.19.png','http://improveinternational.wordpress.com/','(001) 678 984 4926','','','Susan M. Davis','sdavis@improveinternational.org','Improve International was founded in 2011 to find ways to improve the responses to the water & sanitation crisis.  We believe that people deserve to have high quality water and sanitation services, not just for life, but for generations. We believe that independent evaluation of water and sanitation programs in developing countries will identify objectively what’s really working well and what’s not (and why).  By promoting learning and innovation, we hope to help improve the work and coordination of international development organizations so that generations can enjoy safe water and convenient toilets.\r\n\r\nImprove International helps the Millenium Water Alliance to define, develop and execute a learning agenda for the Millennium Water Alliance – Latin America Program (MWA-LAP) that will result in the sharing and transfer of knowledge and best practices among the implementing partners of this program and the production of evidence based advocacy materials that can be shared with the global WASH sector.',993,NULL,'en',22);
/*!40000 ALTER TABLE `rsr_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_organisation_partner_types`
--

DROP TABLE IF EXISTS `rsr_organisation_partner_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_organisation_partner_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation_id` int(11) NOT NULL,
  `partnertype_id` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rsr_organisation_partner__organisation_id_6977993cdb603f60_uniq` (`organisation_id`,`partnertype_id`),
  KEY `rsr_organisation_partner_types_28b1ef86` (`organisation_id`),
  KEY `rsr_organisation_partner_types_c9f578e5` (`partnertype_id`),
  CONSTRAINT `partnertype_id_refs_id_5468fd3e09aafa65` FOREIGN KEY (`partnertype_id`) REFERENCES `rsr_partnertype` (`id`),
  CONSTRAINT `organisation_id_refs_id_44ede9380c116a4` FOREIGN KEY (`organisation_id`) REFERENCES `rsr_organisation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1450 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_organisation_partner_types`
--

LOCK TABLES `rsr_organisation_partner_types` WRITE;
/*!40000 ALTER TABLE `rsr_organisation_partner_types` DISABLE KEYS */;
INSERT INTO `rsr_organisation_partner_types` VALUES (393,360,'sponsor'),(392,360,'support'),(925,841,'support'),(926,842,'support'),(927,843,'field'),(928,843,'funding'),(929,844,'support'),(1000,912,'funding'),(1001,912,'sponsor'),(1032,947,'funding'),(1031,947,'support'),(1055,969,'field'),(1056,969,'sponsor'),(1109,1024,'field'),(1111,1026,'field'),(1123,1036,'field'),(1128,1043,'support'),(1141,1054,'field'),(1142,1054,'funding'),(1178,1095,'field');
/*!40000 ALTER TABLE `rsr_organisation_partner_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_organisationaccount`
--

DROP TABLE IF EXISTS `rsr_organisationaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_organisationaccount` (
  `organisation_id` int(11) NOT NULL,
  `account_level` varchar(12) NOT NULL,
  PRIMARY KEY (`organisation_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_organisationaccount`
--

LOCK TABLES `rsr_organisationaccount` WRITE;
/*!40000 ALTER TABLE `rsr_organisationaccount` DISABLE KEYS */;
INSERT INTO `rsr_organisationaccount` VALUES (360,'premium'),(841,'free'),(842,'free'),(843,'free'),(844,'free'),(912,'free'),(947,'free'),(969,'free'),(1024,'free'),(1026,'free'),(1036,'free'),(1043,'free'),(1054,'free'),(1095,'free');
/*!40000 ALTER TABLE `rsr_organisationaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_organisationlocation`
--

DROP TABLE IF EXISTS `rsr_organisationlocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_organisationlocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `latitude` double NOT NULL DEFAULT '0',
  `longitude` double NOT NULL DEFAULT '0',
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country_id` int(11) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `primary` tinyint(1) NOT NULL DEFAULT '1',
  `location_target_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_organisationlocation_534dd89` (`country_id`),
  KEY `rsr_organisationlocation_301caae0` (`location_target_id`),
  KEY `rsr_organisationlocation_5264a49a` (`primary`),
  KEY `rsr_organisationlocation_761a2bbd` (`longitude`),
  KEY `rsr_organisationlocation_63894e45` (`latitude`)
) ENGINE=MyISAM AUTO_INCREMENT=1134 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_organisationlocation`
--

LOCK TABLES `rsr_organisationlocation` WRITE;
/*!40000 ALTER TABLE `rsr_organisationlocation` DISABLE KEYS */;
INSERT INTO `rsr_organisationlocation` VALUES (138,52.388764,4.87979,'Amsterdam','',3,'Spaarndammerstraat 39-2','','1013 ST',1,360),(746,-37.813611,144.963056,'Melbourne','',57,'School of Geography and Environmental Science','Menzies Building, Monash University, Clayton','3800',1,841),(747,-32.066138,115.835853,'Murdoch','Western Australia',57,'Asia Research Centre, Murdoch University','90 South Street','6150',1,842),(748,50.78884,-1.032265,'Portsmouth','Hampshire',39,'Fort Cumberland, Fort Cumberland Road','Eastney','PO4 9LD',1,843),(749,21.018786,105.855364,'Hanoi','',43,'','','',1,844),(819,52.098134,5.110779,'Utrecht','',3,'P.O. Box 9022','','3506 GA',1,912),(854,38.902868,-77.037675,'Washington','',5,'1627 K St NW','Suite 1000','DC 20006',1,947),(873,52.3723,4.907987,'Amsterdam','',3,'\'s Gravenhekje 1A','','1011 TG',1,969),(923,30.209459,67.018173,'Quetta','Balochsiatn',106,'H # 414 D, Samungli Housing Scheme','','87300',1,1024),(925,30.199162,71.517878,'Multan','Punjab',106,'H # 2240 N/8 A,D Block, Shamsabad Colony','','60000',1,1026),(935,33.68667,72.982228,'Islamabad','',106,'House # 285, Street # 27','Sector F-11/2','44000',1,1036),(940,52.098134,5.110779,'Utrecht','',3,'Oudenoord 176 - 178','','3506 GA',1,1043),(954,38.753734,-76.086083,'Easton','Maryland',5,'7418 Tour Drive','','21601',1,1054),(993,33.798122,-84.369284,'Atlanta','Georgia',5,'1579 Monroe Drive, Suite F-347','','30324',1,1095);
/*!40000 ALTER TABLE `rsr_organisationlocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_partnership`
--

DROP TABLE IF EXISTS `rsr_partnership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_partnership` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `partner_type` varchar(8) NOT NULL,
  `funding_amount` decimal(10,2) DEFAULT NULL,
  `iati_activity_id` varchar(75) DEFAULT NULL,
  `internal_id` varchar(75) DEFAULT NULL,
  `iati_url` varchar(200) NOT NULL,
  `partner_type_extra` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_projectpartner_28b1ef86` (`organisation_id`),
  KEY `rsr_projectpartner_499df97c` (`project_id`),
  KEY `rsr_partnership_2678e2d4` (`iati_activity_id`),
  KEY `rsr_partnership_2f81b70b` (`internal_id`),
  KEY `rsr_partnership_582008b6` (`partner_type`),
  KEY `rsr_partnership_7fab95e1` (`funding_amount`)
) ENGINE=MyISAM AUTO_INCREMENT=5732 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_partnership`
--

LOCK TABLES `rsr_partnership` WRITE;
/*!40000 ALTER TABLE `rsr_partnership` DISABLE KEYS */;
INSERT INTO `rsr_partnership` VALUES (2828,841,613,'support',NULL,'','','',NULL),(2816,360,613,'support',NULL,'','','',NULL),(2829,844,613,'support',NULL,'','','',NULL),(2830,842,613,'support',NULL,'','','',NULL),(2831,843,613,'field',NULL,'','','',NULL),(4960,947,789,'funding',251320.00,'','','',NULL),(4959,1054,789,'funding',148149.00,'','','',NULL),(4018,947,789,'support',NULL,'','','',NULL),(4341,1036,869,'field',NULL,'','','',NULL),(4342,1024,869,'field',NULL,'','','',NULL),(4343,1026,869,'field',NULL,'','','',NULL),(4352,843,613,'funding',1158.00,'','','',NULL),(4462,912,869,'funding',3038000.00,'','','',NULL),(4630,912,869,'sponsor',NULL,'','','',NULL),(4684,1054,789,'field',NULL,'','','',NULL),(4692,969,789,'field',NULL,'','','',NULL),(4693,1095,789,'field',NULL,'','','',NULL),(4856,1043,869,'support',NULL,'','','',NULL);
/*!40000 ALTER TABLE `rsr_partnership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_partnership_copy`
--

DROP TABLE IF EXISTS `rsr_partnership_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_partnership_copy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `partner_type` varchar(8) NOT NULL,
  `funding_amount` decimal(10,2) DEFAULT NULL,
  `iati_activity_id` varchar(75) DEFAULT NULL,
  `internal_id` varchar(75) DEFAULT NULL,
  `iati_url` varchar(200) NOT NULL,
  `partner_type_extra` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_projectpartner_28b1ef86` (`organisation_id`),
  KEY `rsr_projectpartner_499df97c` (`project_id`),
  KEY `rsr_partnership_2678e2d4` (`iati_activity_id`),
  KEY `rsr_partnership_2f81b70b` (`internal_id`),
  KEY `rsr_partnership_582008b6` (`partner_type`),
  KEY `rsr_partnership_7fab95e1` (`funding_amount`)
) ENGINE=MyISAM AUTO_INCREMENT=4745 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_partnership_copy`
--

LOCK TABLES `rsr_partnership_copy` WRITE;
/*!40000 ALTER TABLE `rsr_partnership_copy` DISABLE KEYS */;
INSERT INTO `rsr_partnership_copy` VALUES (1,57,42,'field',NULL,NULL,NULL,'',NULL),(2,57,43,'field',NULL,NULL,NULL,'',NULL),(3,45,38,'field',NULL,NULL,NULL,'',NULL),(4,12,14,'field',NULL,NULL,NULL,'',NULL),(5,14,15,'field',NULL,NULL,NULL,'',NULL),(6,16,16,'field',NULL,NULL,NULL,'',NULL),(7,17,17,'field',NULL,NULL,NULL,'',NULL),(8,14,18,'field',NULL,NULL,NULL,'',NULL),(9,18,19,'field',NULL,NULL,NULL,'',NULL),(10,2,20,'field',NULL,NULL,NULL,'',NULL),(11,37,21,'field',NULL,NULL,NULL,'',NULL),(12,21,23,'field',NULL,NULL,NULL,'',NULL),(13,22,24,'field',NULL,NULL,NULL,'',NULL),(14,7,25,'field',NULL,NULL,NULL,'',NULL),(15,25,26,'field',NULL,NULL,NULL,'',NULL),(16,26,27,'field',NULL,NULL,NULL,'',NULL),(17,27,28,'field',NULL,NULL,NULL,'',NULL),(18,28,29,'field',NULL,NULL,NULL,'',NULL),(19,29,30,'field',NULL,NULL,NULL,'',NULL),(20,39,30,'field',NULL,NULL,NULL,'',NULL),(21,30,31,'field',NULL,NULL,NULL,'',NULL),(22,31,32,'field',NULL,NULL,NULL,'',NULL),(23,32,33,'field',NULL,NULL,NULL,'',NULL),(24,32,34,'field',NULL,NULL,NULL,'',NULL),(25,33,35,'field',NULL,NULL,NULL,'',NULL),(26,19,22,'field',NULL,NULL,NULL,'',NULL),(27,20,22,'field',NULL,NULL,NULL,'',NULL),(28,141,88,'field',NULL,NULL,NULL,'',NULL),(29,57,44,'field',NULL,NULL,NULL,'',NULL),(30,41,37,'field',NULL,NULL,NULL,'',NULL),(31,42,2,'field',NULL,NULL,NULL,'',NULL),(32,48,39,'field',NULL,NULL,NULL,'',NULL),(33,46,40,'field',NULL,NULL,NULL,'',NULL),(34,58,45,'field',NULL,NULL,NULL,'',NULL),(35,59,46,'field',NULL,NULL,NULL,'',NULL),(36,19,47,'field',NULL,NULL,NULL,'',NULL),(37,30,65,'field',NULL,NULL,NULL,'',NULL),(38,64,49,'field',NULL,NULL,NULL,'',NULL),(39,66,50,'field',NULL,NULL,NULL,'',NULL),(40,67,51,'field',NULL,NULL,NULL,'',NULL),(41,69,52,'field',NULL,NULL,NULL,'',NULL),(42,71,53,'field',NULL,NULL,NULL,'',NULL),(43,75,54,'field',NULL,NULL,NULL,'',NULL),(44,77,55,'field',NULL,NULL,NULL,'',NULL),(45,79,56,'field',NULL,NULL,NULL,'',NULL),(46,82,57,'field',NULL,NULL,NULL,'',NULL),(47,86,59,'field',NULL,NULL,NULL,'',NULL),(48,88,60,'field',NULL,NULL,NULL,'',NULL),(49,91,61,'field',NULL,NULL,NULL,'',NULL),(50,94,62,'field',NULL,NULL,NULL,'',NULL),(51,91,63,'support',NULL,NULL,NULL,'',NULL),(52,99,64,'field',NULL,NULL,NULL,'',NULL),(53,104,66,'field',NULL,NULL,NULL,'',NULL),(54,109,72,'field',NULL,NULL,NULL,'',NULL),(55,101,69,'field',NULL,NULL,NULL,'',NULL),(56,108,69,'field',NULL,NULL,NULL,'',NULL),(57,74,54,'field',NULL,NULL,NULL,'',NULL),(58,89,60,'field',NULL,NULL,NULL,'',NULL),(59,110,73,'field',NULL,NULL,NULL,'',NULL),(60,110,74,'field',NULL,NULL,NULL,'',NULL),(61,112,75,'field',NULL,NULL,NULL,'',NULL),(62,105,76,'field',NULL,NULL,NULL,'',NULL),(63,146,80,'field',NULL,NULL,NULL,'',NULL),(64,114,78,'field',NULL,NULL,NULL,'',NULL),(65,16,82,'field',NULL,NULL,NULL,'',NULL),(66,122,81,'field',NULL,NULL,NULL,'',NULL),(67,22,83,'field',NULL,NULL,NULL,'',NULL),(68,124,84,'field',NULL,NULL,NULL,'',NULL),(69,110,85,'field',NULL,NULL,NULL,'',NULL),(70,129,86,'field',NULL,NULL,NULL,'',NULL),(71,130,87,'field',NULL,NULL,NULL,'',NULL),(72,132,88,'field',NULL,NULL,NULL,'',NULL),(73,133,89,'field',NULL,NULL,NULL,'',NULL),(74,142,90,'field',NULL,NULL,NULL,'',NULL),(75,135,91,'field',NULL,NULL,NULL,'',NULL),(76,16,92,'field',NULL,NULL,NULL,'',NULL),(77,136,92,'field',NULL,NULL,NULL,'',NULL),(78,137,93,'field',NULL,NULL,NULL,'',NULL),(79,137,94,'field',NULL,NULL,NULL,'',NULL),(80,112,95,'field',NULL,NULL,NULL,'',NULL),(81,112,96,'field',NULL,NULL,NULL,'',NULL),(82,138,97,'field',NULL,NULL,NULL,'',NULL),(83,57,98,'field',NULL,NULL,NULL,'',NULL),(84,57,99,'field',NULL,NULL,NULL,'',NULL),(85,139,100,'field',NULL,NULL,NULL,'',NULL),(86,140,101,'field',NULL,NULL,NULL,'',NULL),(87,50,41,'field',NULL,NULL,NULL,'',NULL),(88,143,102,'field',NULL,NULL,NULL,'',NULL),(89,145,103,'field',NULL,NULL,NULL,'',NULL),(90,146,104,'field',NULL,NULL,NULL,'',NULL),(91,148,105,'field',NULL,NULL,NULL,'',NULL),(92,149,106,'field',NULL,NULL,NULL,'',NULL),(93,150,107,'field',NULL,NULL,NULL,'',NULL),(94,115,108,'field',NULL,NULL,NULL,'',NULL),(95,151,109,'field',NULL,NULL,NULL,'',NULL),(96,39,110,'field',NULL,NULL,NULL,'',NULL),(97,57,111,'field',NULL,NULL,NULL,'',NULL),(98,153,112,'field',NULL,NULL,NULL,'',NULL),(99,153,113,'field',NULL,NULL,NULL,'',NULL),(100,154,114,'field',NULL,NULL,NULL,'',NULL),(101,155,115,'field',NULL,NULL,NULL,'',NULL),(102,47,39,'field',NULL,NULL,NULL,'',NULL),(103,110,116,'field',NULL,NULL,NULL,'',NULL),(104,110,117,'field',NULL,NULL,NULL,'',NULL),(105,110,118,'field',NULL,NULL,NULL,'',NULL),(106,156,119,'field',NULL,NULL,NULL,'',NULL),(107,124,120,'field',NULL,NULL,NULL,'',NULL),(108,158,121,'field',NULL,NULL,NULL,'',NULL),(109,81,57,'field',NULL,NULL,NULL,'',NULL),(110,188,182,'field',NULL,NULL,NULL,'',NULL),(111,159,122,'field',NULL,NULL,NULL,'',NULL),(112,160,123,'field',NULL,NULL,NULL,'',NULL),(113,161,124,'field',NULL,NULL,NULL,'',NULL),(114,161,125,'field',NULL,NULL,NULL,'',NULL),(115,161,126,'field',NULL,NULL,NULL,'',NULL),(116,161,127,'field',NULL,NULL,NULL,'',NULL),(117,154,128,'field',NULL,NULL,NULL,'',NULL),(118,170,129,'field',NULL,NULL,NULL,'',NULL),(119,94,130,'field',NULL,NULL,NULL,'',NULL),(120,172,131,'field',NULL,NULL,NULL,'',NULL),(121,173,132,'field',NULL,NULL,NULL,'',NULL),(122,115,133,'field',NULL,NULL,NULL,'',NULL),(123,98,50,'field',NULL,NULL,NULL,'',NULL),(124,115,134,'field',NULL,NULL,NULL,'',NULL),(125,176,135,'field',NULL,NULL,NULL,'',NULL),(126,108,135,'field',NULL,NULL,NULL,'',NULL),(127,179,136,'field',NULL,NULL,NULL,'',NULL),(128,179,137,'field',NULL,NULL,NULL,'',NULL),(129,244,138,'field',NULL,NULL,NULL,'',NULL),(130,74,138,'field',NULL,NULL,NULL,'',NULL),(131,121,139,'field',NULL,NULL,NULL,'',NULL),(132,79,140,'field',NULL,NULL,NULL,'',NULL),(133,182,141,'field',NULL,NULL,NULL,'',NULL),(134,59,142,'field',NULL,NULL,NULL,'',NULL),(135,185,143,'field',NULL,NULL,NULL,'',NULL),(136,187,144,'field',NULL,NULL,NULL,'',NULL),(137,81,145,'field',NULL,NULL,NULL,'',NULL),(138,82,145,'field',NULL,NULL,NULL,'',NULL),(139,91,146,'field',NULL,NULL,NULL,'',NULL),(140,188,147,'field',NULL,NULL,NULL,'',NULL),(141,188,148,'field',NULL,NULL,NULL,'',NULL),(142,188,149,'field',NULL,NULL,NULL,'',NULL),(143,188,150,'field',NULL,NULL,NULL,'',NULL),(144,188,151,'field',NULL,NULL,NULL,'',NULL),(145,189,152,'field',NULL,NULL,NULL,'',NULL),(146,192,153,'field',NULL,NULL,NULL,'',NULL),(147,195,154,'field',NULL,NULL,NULL,'',NULL),(148,196,155,'field',NULL,NULL,NULL,'',NULL),(149,199,156,'field',NULL,NULL,NULL,'',NULL),(150,200,157,'field',NULL,NULL,NULL,'',NULL),(151,201,158,'field',NULL,NULL,NULL,'',NULL),(152,202,158,'field',NULL,NULL,NULL,'',NULL),(153,172,159,'field',NULL,NULL,NULL,'',NULL),(154,203,160,'field',NULL,NULL,NULL,'',NULL),(155,204,161,'field',NULL,NULL,NULL,'',NULL),(156,188,183,'field',NULL,NULL,NULL,'',NULL),(157,206,163,'field',NULL,NULL,NULL,'',NULL),(158,207,164,'field',NULL,NULL,NULL,'',NULL),(159,137,165,'field',NULL,NULL,NULL,'',NULL),(160,214,166,'field',NULL,NULL,NULL,'',NULL),(161,206,167,'field',NULL,NULL,NULL,'',NULL),(162,206,168,'field',NULL,NULL,NULL,'',NULL),(163,206,169,'field',NULL,NULL,NULL,'',NULL),(164,206,170,'field',NULL,NULL,NULL,'',NULL),(165,94,171,'field',NULL,NULL,NULL,'',NULL),(166,172,172,'field',NULL,NULL,NULL,'',NULL),(167,197,173,'field',NULL,NULL,NULL,'',NULL),(168,208,174,'field',NULL,NULL,NULL,'',NULL),(169,216,175,'field',NULL,NULL,NULL,'',NULL),(170,220,176,'field',NULL,NULL,NULL,'',NULL),(171,223,177,'field',NULL,NULL,NULL,'',NULL),(172,225,178,'field',NULL,NULL,NULL,'',NULL),(173,71,179,'field',NULL,NULL,NULL,'',NULL),(174,239,180,'field',NULL,NULL,NULL,'',NULL),(175,242,181,'field',NULL,NULL,NULL,'',NULL),(176,248,184,'field',NULL,NULL,NULL,'',NULL),(177,249,185,'field',NULL,NULL,NULL,'',NULL),(178,251,186,'field',NULL,NULL,NULL,'',NULL),(179,50,187,'field',NULL,NULL,NULL,'',NULL),(180,115,188,'field',NULL,NULL,NULL,'',NULL),(181,303,212,'field',NULL,NULL,NULL,'',NULL),(182,294,211,'field',NULL,NULL,NULL,'',NULL),(183,154,190,'field',NULL,NULL,NULL,'',NULL),(184,302,210,'field',NULL,NULL,NULL,'',NULL),(185,267,192,'field',NULL,NULL,NULL,'',NULL),(186,269,193,'field',NULL,NULL,NULL,'',NULL),(187,274,194,'field',NULL,NULL,NULL,'',NULL),(188,277,195,'field',NULL,NULL,NULL,'',NULL),(189,278,195,'field',NULL,NULL,NULL,'',NULL),(190,279,196,'field',NULL,NULL,NULL,'',NULL),(191,280,197,'field',NULL,NULL,NULL,'',NULL),(192,281,197,'field',NULL,NULL,NULL,'',NULL),(193,185,209,'field',NULL,NULL,NULL,'',NULL),(194,15,199,'field',NULL,NULL,NULL,'',NULL),(195,293,200,'field',NULL,NULL,NULL,'',NULL),(196,292,200,'field',NULL,NULL,NULL,'',NULL),(197,295,201,'field',NULL,NULL,NULL,'',NULL),(198,294,202,'field',NULL,NULL,NULL,'',NULL),(199,77,203,'field',NULL,NULL,NULL,'',NULL),(200,74,204,'field',NULL,NULL,NULL,'',NULL),(201,244,204,'field',NULL,NULL,NULL,'',NULL),(202,297,205,'field',NULL,NULL,NULL,'',NULL),(203,298,206,'field',NULL,NULL,NULL,'',NULL),(204,299,207,'field',NULL,NULL,NULL,'',NULL),(205,300,208,'field',NULL,NULL,NULL,'',NULL),(206,305,213,'field',NULL,NULL,NULL,'',NULL),(207,921,214,'field',NULL,'','','',NULL),(208,307,215,'field',NULL,NULL,NULL,'',NULL),(209,308,216,'field',NULL,NULL,NULL,'',NULL),(210,309,217,'field',NULL,NULL,NULL,'',NULL),(211,300,218,'field',NULL,NULL,NULL,'',NULL),(212,310,219,'field',NULL,NULL,NULL,'',NULL),(213,300,219,'field',NULL,NULL,NULL,'',NULL),(214,311,220,'field',NULL,NULL,NULL,'',NULL),(215,312,220,'field',NULL,NULL,NULL,'',NULL),(216,300,221,'field',NULL,NULL,NULL,'',NULL),(217,314,222,'field',NULL,NULL,NULL,'',NULL),(218,313,222,'field',NULL,NULL,NULL,'',NULL),(219,320,223,'field',NULL,NULL,NULL,'',NULL),(220,317,226,'field',NULL,NULL,NULL,'',NULL),(221,21,227,'field',NULL,NULL,NULL,'',NULL),(222,327,228,'field',NULL,NULL,NULL,'',NULL),(223,328,229,'field',NULL,NULL,NULL,'',NULL),(224,321,230,'field',NULL,NULL,NULL,'',NULL),(225,34,231,'field',NULL,NULL,NULL,'',NULL),(226,148,232,'field',NULL,NULL,NULL,'',NULL),(227,34,233,'field',NULL,NULL,NULL,'',NULL),(228,14,234,'field',NULL,NULL,NULL,'',NULL),(229,59,235,'field',NULL,NULL,NULL,'',NULL),(230,71,236,'field',NULL,NULL,NULL,'',NULL),(231,322,237,'field',NULL,NULL,NULL,'',NULL),(232,323,238,'field',NULL,NULL,NULL,'',NULL),(233,189,239,'field',NULL,NULL,NULL,'',NULL),(234,325,238,'field',NULL,NULL,NULL,'',NULL),(235,81,240,'field',NULL,NULL,NULL,'',NULL),(236,336,243,'field',NULL,NULL,NULL,'',NULL),(237,329,242,'field',NULL,NULL,NULL,'',NULL),(238,335,243,'field',NULL,NULL,NULL,'',NULL),(239,340,244,'field',NULL,NULL,NULL,'',NULL),(240,340,245,'field',NULL,NULL,NULL,'',NULL),(241,340,246,'field',NULL,NULL,NULL,'',NULL),(242,340,247,'field',NULL,NULL,NULL,'',NULL),(243,340,248,'field',NULL,NULL,NULL,'',NULL),(244,340,249,'field',NULL,NULL,NULL,'',NULL),(245,340,250,'field',NULL,NULL,NULL,'',NULL),(246,340,251,'field',NULL,NULL,NULL,'',NULL),(247,340,252,'field',NULL,NULL,NULL,'',NULL),(248,340,253,'field',NULL,NULL,NULL,'',NULL),(249,340,254,'field',NULL,NULL,NULL,'',NULL),(250,340,255,'field',NULL,NULL,NULL,'',NULL),(251,340,256,'field',NULL,NULL,NULL,'',NULL),(252,340,257,'field',NULL,NULL,NULL,'',NULL),(253,340,258,'field',NULL,NULL,NULL,'',NULL),(254,340,259,'field',NULL,NULL,NULL,'',NULL),(255,340,260,'field',NULL,NULL,NULL,'',NULL),(256,340,261,'field',NULL,NULL,NULL,'',NULL),(257,340,262,'field',NULL,NULL,NULL,'',NULL),(258,340,263,'field',NULL,NULL,NULL,'',NULL),(259,340,264,'field',NULL,NULL,NULL,'',NULL),(260,59,265,'field',NULL,NULL,NULL,'',NULL),(261,188,266,'field',NULL,NULL,NULL,'',NULL),(262,115,267,'field',NULL,NULL,NULL,'',NULL),(263,57,268,'field',NULL,NULL,NULL,'',NULL),(264,348,269,'field',NULL,NULL,NULL,'',NULL),(265,347,269,'field',NULL,NULL,NULL,'',NULL),(266,352,270,'field',NULL,NULL,NULL,'',NULL),(267,354,271,'field',NULL,NULL,NULL,'',NULL),(268,355,272,'field',NULL,NULL,NULL,'',NULL),(269,59,273,'field',NULL,NULL,NULL,'',NULL),(270,357,274,'field',NULL,NULL,NULL,'',NULL),(271,362,275,'field',NULL,NULL,NULL,'',NULL),(272,364,275,'field',NULL,NULL,NULL,'',NULL),(273,327,277,'field',NULL,NULL,NULL,'',NULL),(274,377,276,'field',NULL,NULL,NULL,'',NULL),(275,368,277,'field',NULL,NULL,NULL,'',NULL),(276,369,277,'field',NULL,NULL,NULL,'',NULL),(277,372,278,'field',NULL,NULL,NULL,'',NULL),(278,373,278,'field',NULL,NULL,NULL,'',NULL),(279,375,279,'field',NULL,NULL,NULL,'',NULL),(280,376,276,'field',NULL,NULL,NULL,'',NULL),(281,384,280,'field',NULL,NULL,NULL,'',NULL),(282,385,281,'field',NULL,NULL,NULL,'',NULL),(283,389,282,'field',NULL,NULL,NULL,'',NULL),(284,390,282,'field',NULL,NULL,NULL,'',NULL),(285,391,283,'field',NULL,NULL,NULL,'',NULL),(286,393,284,'field',NULL,NULL,NULL,'',NULL),(287,110,285,'field',NULL,NULL,NULL,'',NULL),(288,395,286,'field',NULL,NULL,NULL,'',NULL),(289,396,286,'field',NULL,NULL,NULL,'',NULL),(290,397,286,'field',NULL,NULL,NULL,'',NULL),(291,400,287,'field',NULL,NULL,NULL,'',NULL),(292,401,287,'field',NULL,NULL,NULL,'',NULL),(293,402,287,'field',NULL,NULL,NULL,'',NULL),(294,399,287,'field',NULL,NULL,NULL,'',NULL),(295,110,289,'field',NULL,NULL,NULL,'',NULL),(296,110,290,'field',NULL,NULL,NULL,'',NULL),(297,386,291,'field',NULL,NULL,NULL,'',NULL),(298,387,291,'field',NULL,NULL,NULL,'',NULL),(299,406,292,'field',NULL,NULL,NULL,'',NULL),(300,407,292,'field',NULL,NULL,NULL,'',NULL),(301,408,292,'field',NULL,NULL,NULL,'',NULL),(302,409,293,'field',NULL,NULL,NULL,'',NULL),(303,410,293,'field',NULL,NULL,NULL,'',NULL),(304,404,294,'field',NULL,NULL,NULL,'',NULL),(2336,712,551,'field',NULL,NULL,NULL,'',NULL),(2335,714,551,'field',NULL,NULL,NULL,'',NULL),(2334,713,551,'funding',14000000.00,NULL,NULL,'',NULL),(2333,217,506,'funding',22763.12,NULL,NULL,'',NULL),(311,417,296,'field',NULL,NULL,NULL,'',NULL),(312,418,296,'field',NULL,NULL,NULL,'',NULL),(313,419,296,'field',NULL,NULL,NULL,'',NULL),(314,420,296,'field',NULL,NULL,NULL,'',NULL),(315,91,297,'field',NULL,NULL,NULL,'',NULL),(316,91,298,'field',NULL,NULL,NULL,'',NULL),(317,8,299,'field',NULL,NULL,NULL,'',NULL),(318,422,294,'field',NULL,NULL,NULL,'',NULL),(319,423,294,'field',NULL,NULL,NULL,'',NULL),(320,426,294,'field',NULL,NULL,NULL,'',NULL),(321,425,294,'field',NULL,NULL,NULL,'',NULL),(322,424,294,'field',NULL,NULL,NULL,'',NULL),(323,110,300,'field',NULL,NULL,NULL,'',NULL),(324,42,301,'field',NULL,NULL,NULL,'',NULL),(325,305,302,'field',NULL,NULL,NULL,'',NULL),(326,300,303,'field',NULL,NULL,NULL,'',NULL),(327,427,304,'field',NULL,NULL,NULL,'',NULL),(328,428,305,'field',NULL,NULL,NULL,'',NULL),(329,428,306,'field',NULL,NULL,NULL,'',NULL),(330,110,307,'field',NULL,NULL,NULL,'',NULL),(332,440,308,'field',NULL,NULL,NULL,'',NULL),(333,443,309,'field',NULL,NULL,NULL,'',NULL),(334,445,310,'field',NULL,NULL,NULL,'',NULL),(335,457,312,'field',NULL,NULL,NULL,'',NULL),(336,456,313,'field',NULL,NULL,NULL,'',NULL),(4233,540,841,'field',NULL,'','','',NULL),(338,115,315,'field',NULL,NULL,NULL,'',NULL),(339,447,316,'field',NULL,NULL,NULL,'',NULL),(340,455,317,'field',NULL,NULL,NULL,'',NULL),(341,450,318,'field',NULL,NULL,NULL,'',NULL),(342,451,320,'field',NULL,NULL,NULL,'',NULL),(343,454,321,'field',NULL,NULL,NULL,'',NULL),(344,452,322,'field',NULL,NULL,NULL,'',NULL),(345,459,323,'field',NULL,NULL,NULL,'',NULL),(346,463,324,'field',NULL,NULL,NULL,'',NULL),(347,81,325,'field',NULL,NULL,NULL,'',NULL),(348,467,326,'field',NULL,NULL,NULL,'',NULL),(349,458,327,'field',NULL,NULL,NULL,'',NULL),(350,449,328,'field',NULL,NULL,NULL,'',NULL),(351,468,325,'field',NULL,NULL,NULL,'',NULL),(352,251,329,'field',NULL,NULL,NULL,'',NULL),(353,322,330,'field',NULL,NULL,NULL,'',NULL),(354,472,310,'field',NULL,NULL,NULL,'',NULL),(355,471,310,'field',NULL,NULL,NULL,'',NULL),(356,482,331,'field',NULL,NULL,NULL,'',NULL),(357,485,332,'field',NULL,NULL,NULL,'',NULL),(358,110,333,'field',NULL,NULL,NULL,'',NULL),(359,274,336,'field',NULL,NULL,NULL,'',NULL),(360,491,337,'field',NULL,NULL,NULL,'',NULL),(361,189,334,'field',NULL,NULL,NULL,'',NULL),(362,492,338,'field',NULL,NULL,NULL,'',NULL),(363,496,340,'field',NULL,NULL,NULL,'',NULL),(364,498,340,'field',NULL,NULL,NULL,'',NULL),(365,499,341,'field',NULL,NULL,NULL,'',NULL),(366,170,342,'field',NULL,NULL,NULL,'',NULL),(367,428,335,'field',NULL,NULL,NULL,'',NULL),(368,500,343,'field',NULL,NULL,NULL,'',NULL),(369,501,342,'field',NULL,NULL,NULL,'',NULL),(370,508,345,'field',NULL,NULL,NULL,'',NULL),(371,509,348,'field',NULL,NULL,NULL,'',NULL),(372,515,347,'field',NULL,NULL,NULL,'',NULL),(373,512,347,'field',NULL,NULL,NULL,'',NULL),(374,513,347,'field',NULL,NULL,NULL,'',NULL),(375,514,347,'field',NULL,NULL,NULL,'',NULL),(376,417,349,'field',NULL,NULL,NULL,'',NULL),(377,418,349,'field',NULL,NULL,NULL,'',NULL),(378,419,349,'field',NULL,NULL,NULL,'',NULL),(379,420,349,'field',NULL,NULL,NULL,'',NULL),(380,517,346,'field',NULL,NULL,NULL,'',NULL),(381,654,336,'field',NULL,NULL,NULL,'',NULL),(382,522,350,'field',NULL,NULL,NULL,'',NULL),(383,526,351,'field',NULL,NULL,NULL,'',NULL),(384,495,339,'field',NULL,NULL,NULL,'',NULL),(385,367,276,'field',NULL,NULL,NULL,'',NULL),(2332,506,552,'support',NULL,NULL,NULL,'',NULL),(387,511,347,'field',NULL,NULL,NULL,'',NULL),(388,488,328,'field',NULL,NULL,NULL,'',NULL),(389,488,327,'field',NULL,NULL,NULL,'',NULL),(390,488,323,'field',NULL,NULL,NULL,'',NULL),(391,488,322,'field',NULL,NULL,NULL,'',NULL),(392,488,321,'field',NULL,NULL,NULL,'',NULL),(393,488,320,'field',NULL,NULL,NULL,'',NULL),(394,488,318,'field',NULL,NULL,NULL,'',NULL),(395,488,317,'field',NULL,NULL,NULL,'',NULL),(396,488,316,'field',NULL,NULL,NULL,'',NULL),(397,488,314,'field',74979.00,NULL,NULL,'',NULL),(398,488,313,'field',NULL,NULL,NULL,'',NULL),(399,488,312,'field',NULL,NULL,NULL,'',NULL),(400,486,332,'field',NULL,NULL,NULL,'',NULL),(401,537,353,'field',NULL,NULL,NULL,'',NULL),(402,305,353,'field',NULL,NULL,NULL,'',NULL),(403,534,354,'field',NULL,NULL,NULL,'',NULL),(404,532,355,'field',NULL,NULL,NULL,'',NULL),(405,533,356,'field',NULL,NULL,NULL,'',NULL),(406,536,352,'field',NULL,NULL,NULL,'',NULL),(407,535,357,'field',NULL,NULL,NULL,'',NULL),(408,538,358,'field',NULL,NULL,NULL,'',NULL),(409,540,358,'field',NULL,NULL,NULL,'',NULL),(410,542,359,'field',NULL,NULL,NULL,'',NULL),(411,541,359,'field',NULL,NULL,NULL,'',NULL),(412,543,360,'field',NULL,NULL,NULL,'',NULL),(413,546,361,'field',NULL,NULL,NULL,'',NULL),(414,185,362,'field',NULL,NULL,NULL,'',NULL),(415,518,364,'field',NULL,NULL,NULL,'',NULL),(416,544,363,'field',NULL,NULL,NULL,'',NULL),(417,549,365,'field',NULL,NULL,NULL,'',NULL),(418,550,366,'field',NULL,NULL,NULL,'',NULL),(419,25,367,'field',NULL,NULL,NULL,'',NULL),(420,456,368,'field',NULL,NULL,NULL,'',NULL),(421,538,369,'field',NULL,NULL,NULL,'',NULL),(422,540,369,'field',NULL,NULL,NULL,'',NULL),(423,538,370,'field',NULL,NULL,NULL,'',NULL),(424,540,370,'field',NULL,NULL,NULL,'',NULL),(425,538,371,'field',NULL,NULL,NULL,'',NULL),(426,540,371,'field',NULL,NULL,NULL,'',NULL),(427,538,372,'field',NULL,NULL,NULL,'',NULL),(428,540,372,'field',NULL,NULL,NULL,'',NULL),(429,538,373,'field',NULL,NULL,NULL,'',NULL),(430,540,373,'field',NULL,NULL,NULL,'',NULL),(431,538,374,'field',NULL,NULL,NULL,'',NULL),(432,540,374,'field',NULL,NULL,NULL,'',NULL),(433,538,375,'field',NULL,NULL,NULL,'',NULL),(434,540,375,'field',NULL,NULL,NULL,'',NULL),(435,538,376,'field',NULL,NULL,NULL,'',NULL),(436,540,376,'field',NULL,NULL,NULL,'',NULL),(437,538,377,'field',NULL,NULL,NULL,'',NULL),(438,540,377,'field',NULL,NULL,NULL,'',NULL),(439,538,378,'field',NULL,NULL,NULL,'',NULL),(440,540,378,'field',NULL,NULL,NULL,'',NULL),(441,538,379,'field',NULL,NULL,NULL,'',NULL),(442,540,379,'field',NULL,NULL,NULL,'',NULL),(443,538,380,'field',NULL,NULL,NULL,'',NULL),(444,540,380,'field',NULL,NULL,NULL,'',NULL),(445,538,381,'field',NULL,NULL,NULL,'',NULL),(446,540,381,'field',NULL,NULL,NULL,'',NULL),(447,538,382,'field',NULL,NULL,NULL,'',NULL),(448,540,382,'field',NULL,NULL,NULL,'',NULL),(449,554,368,'field',NULL,NULL,NULL,'',NULL),(450,551,383,'field',NULL,NULL,NULL,'',NULL),(451,421,384,'field',NULL,NULL,NULL,'',NULL),(452,555,385,'field',NULL,NULL,NULL,'',NULL),(1682,273,406,'support',NULL,'','106282','',NULL),(454,557,387,'field',NULL,NULL,NULL,'',NULL),(455,527,388,'field',NULL,NULL,NULL,'',NULL),(456,559,389,'field',NULL,NULL,NULL,'',NULL),(457,558,389,'field',NULL,NULL,NULL,'',NULL),(458,320,390,'field',NULL,NULL,NULL,'',NULL),(459,564,391,'field',NULL,NULL,NULL,'',NULL),(460,530,392,'field',NULL,NULL,NULL,'',NULL),(461,528,393,'field',NULL,NULL,NULL,'',NULL),(462,530,394,'field',NULL,NULL,NULL,'',NULL),(463,207,395,'field',NULL,'','','',NULL),(464,567,396,'field',NULL,NULL,NULL,'',NULL),(465,569,397,'field',NULL,NULL,NULL,'',NULL),(466,730,398,'field',NULL,NULL,NULL,'',NULL),(467,730,392,'field',NULL,NULL,NULL,'',NULL),(468,570,399,'field',NULL,NULL,NULL,'',NULL),(469,113,55,'sponsor',NULL,NULL,NULL,'',NULL),(470,113,54,'sponsor',NULL,NULL,NULL,'',NULL),(471,113,53,'sponsor',NULL,NULL,NULL,'',NULL),(472,113,56,'sponsor',NULL,NULL,NULL,'',NULL),(473,113,57,'sponsor',NULL,NULL,NULL,'',NULL),(474,113,58,'sponsor',NULL,NULL,NULL,'',NULL),(475,147,84,'sponsor',NULL,NULL,NULL,'',NULL),(476,147,86,'sponsor',NULL,NULL,NULL,'',NULL),(477,147,87,'sponsor',NULL,NULL,NULL,'',NULL),(478,147,88,'sponsor',NULL,NULL,NULL,'',NULL),(479,147,89,'sponsor',NULL,NULL,NULL,'',NULL),(480,147,90,'sponsor',NULL,NULL,NULL,'',NULL),(481,147,91,'sponsor',NULL,NULL,NULL,'',NULL),(482,147,92,'sponsor',NULL,NULL,NULL,'',NULL),(483,147,103,'sponsor',NULL,NULL,NULL,'',NULL),(484,147,108,'sponsor',NULL,NULL,NULL,'',NULL),(485,184,168,'sponsor',NULL,NULL,NULL,'',NULL),(486,147,109,'sponsor',NULL,NULL,NULL,'',NULL),(487,113,186,'sponsor',NULL,NULL,NULL,'',NULL),(488,113,183,'sponsor',NULL,NULL,NULL,'',NULL),(489,147,120,'sponsor',NULL,NULL,NULL,'',NULL),(490,147,112,'sponsor',NULL,NULL,NULL,'',NULL),(491,113,138,'sponsor',NULL,NULL,NULL,'',NULL),(492,113,142,'sponsor',NULL,NULL,NULL,'',NULL),(493,113,129,'sponsor',NULL,NULL,NULL,'',NULL),(494,168,143,'funding',20406.00,'','','',NULL),(495,147,144,'sponsor',NULL,NULL,NULL,'',NULL),(496,113,145,'sponsor',NULL,NULL,NULL,'',NULL),(497,113,147,'sponsor',NULL,NULL,NULL,'',NULL),(498,113,148,'sponsor',NULL,NULL,NULL,'',NULL),(499,113,182,'sponsor',NULL,NULL,NULL,'',NULL),(500,113,150,'sponsor',NULL,NULL,NULL,'',NULL),(501,113,151,'sponsor',NULL,NULL,NULL,'',NULL),(502,113,152,'sponsor',NULL,NULL,NULL,'',NULL),(503,113,134,'sponsor',NULL,NULL,NULL,'',NULL),(504,344,131,'sponsor',NULL,NULL,NULL,'',NULL),(505,113,154,'sponsor',NULL,NULL,NULL,'',NULL),(506,113,155,'sponsor',NULL,NULL,NULL,'',NULL),(507,147,156,'sponsor',NULL,NULL,NULL,'',NULL),(508,113,157,'sponsor',NULL,NULL,NULL,'',NULL),(509,113,62,'sponsor',NULL,NULL,NULL,'',NULL),(510,184,167,'sponsor',NULL,NULL,NULL,'',NULL),(511,147,160,'sponsor',NULL,NULL,NULL,'',NULL),(512,113,161,'sponsor',NULL,NULL,NULL,'',NULL),(513,113,203,'sponsor',NULL,NULL,NULL,'',NULL),(514,113,164,'sponsor',NULL,NULL,NULL,'',NULL),(515,147,158,'sponsor',NULL,NULL,NULL,'',NULL),(516,184,169,'sponsor',NULL,NULL,NULL,'',NULL),(517,184,170,'sponsor',NULL,NULL,NULL,'',NULL),(518,113,171,'sponsor',NULL,NULL,NULL,'',NULL),(519,113,172,'sponsor',NULL,NULL,NULL,'',NULL),(520,147,173,'sponsor',NULL,NULL,NULL,'',NULL),(521,184,59,'sponsor',NULL,NULL,NULL,'',NULL),(522,184,163,'sponsor',NULL,NULL,NULL,'',NULL),(523,147,176,'sponsor',NULL,NULL,NULL,'',NULL),(524,147,111,'sponsor',NULL,NULL,NULL,'',NULL),(525,184,136,'sponsor',NULL,NULL,NULL,'',NULL),(526,184,137,'sponsor',NULL,NULL,NULL,'',NULL),(527,113,179,'sponsor',NULL,NULL,NULL,'',NULL),(528,275,350,'sponsor',NULL,NULL,NULL,'',NULL),(529,275,351,'sponsor',NULL,NULL,NULL,'',NULL),(530,113,180,'sponsor',NULL,NULL,NULL,'',NULL),(531,113,188,'sponsor',NULL,NULL,NULL,'',NULL),(532,113,205,'sponsor',NULL,NULL,NULL,'',NULL),(533,113,207,'sponsor',NULL,NULL,NULL,'',NULL),(534,113,209,'sponsor',NULL,NULL,NULL,'',NULL),(535,113,210,'sponsor',NULL,NULL,NULL,'',NULL),(536,113,235,'sponsor',NULL,NULL,NULL,'',NULL),(537,113,236,'sponsor',NULL,NULL,NULL,'',NULL),(538,113,237,'sponsor',NULL,NULL,NULL,'',NULL),(539,113,239,'sponsor',NULL,NULL,NULL,'',NULL),(540,113,240,'sponsor',NULL,NULL,NULL,'',NULL),(2664,430,218,'support',NULL,NULL,NULL,'',NULL),(2056,659,472,'field',NULL,NULL,NULL,'',NULL),(543,344,307,'sponsor',NULL,NULL,NULL,'',NULL),(544,272,304,'sponsor',NULL,NULL,NULL,'',NULL),(545,344,108,'sponsor',NULL,NULL,NULL,'',NULL),(546,344,268,'sponsor',NULL,NULL,NULL,'',NULL),(547,272,277,'sponsor',NULL,NULL,NULL,'',NULL),(548,272,290,'sponsor',NULL,NULL,NULL,'',NULL),(549,272,294,'sponsor',NULL,NULL,NULL,'',NULL),(2331,506,552,'funding',7000.00,NULL,NULL,'',NULL),(551,272,296,'sponsor',NULL,NULL,NULL,'',NULL),(1875,392,303,'funding',20000.00,NULL,NULL,'',NULL),(1876,227,75,'sponsor',NULL,NULL,NULL,'',NULL),(554,272,312,'sponsor',NULL,NULL,NULL,'',NULL),(555,272,313,'sponsor',NULL,NULL,NULL,'',NULL),(556,405,314,'support',NULL,NULL,NULL,'',NULL),(557,444,315,'sponsor',NULL,NULL,NULL,'',NULL),(558,272,316,'sponsor',NULL,NULL,NULL,'',NULL),(559,272,317,'sponsor',NULL,NULL,NULL,'',NULL),(560,272,318,'sponsor',NULL,NULL,NULL,'',NULL),(561,272,320,'sponsor',NULL,NULL,NULL,'',NULL),(562,272,321,'sponsor',NULL,NULL,NULL,'',NULL),(563,272,322,'sponsor',NULL,NULL,NULL,'',NULL),(564,272,323,'sponsor',NULL,NULL,NULL,'',NULL),(565,272,327,'sponsor',NULL,NULL,NULL,'',NULL),(566,272,328,'sponsor',NULL,NULL,NULL,'',NULL),(567,272,331,'sponsor',NULL,NULL,NULL,'',NULL),(568,272,390,'sponsor',NULL,NULL,NULL,'',NULL),(2420,731,547,'funding',33555405.00,NULL,NULL,'',NULL),(2844,829,588,'sponsor',NULL,'','','',NULL),(2417,294,570,'field',NULL,NULL,NULL,'',NULL),(572,444,334,'sponsor',NULL,NULL,NULL,'',NULL),(2754,180,332,'funding',6000.00,NULL,NULL,'',NULL),(574,444,330,'sponsor',NULL,NULL,NULL,'',NULL),(575,444,329,'sponsor',NULL,NULL,NULL,'',NULL),(576,444,326,'sponsor',NULL,NULL,NULL,'',NULL),(577,444,325,'sponsor',NULL,NULL,NULL,'',NULL),(2174,687,310,'field',NULL,NULL,NULL,'',NULL),(579,444,273,'sponsor',NULL,NULL,NULL,'',NULL),(580,444,203,'funding',3000.00,NULL,NULL,'',NULL),(581,444,186,'sponsor',NULL,NULL,NULL,'',NULL),(582,444,134,'sponsor',NULL,NULL,NULL,'',NULL),(583,490,153,'sponsor',NULL,NULL,NULL,'',NULL),(584,490,143,'sponsor',NULL,NULL,NULL,'',NULL),(585,490,54,'sponsor',NULL,NULL,NULL,'',NULL),(586,490,268,'sponsor',NULL,NULL,NULL,'',NULL),(4645,252,329,'funding',7672.00,'','','',NULL),(588,272,336,'sponsor',NULL,NULL,NULL,'',NULL),(589,272,337,'sponsor',NULL,NULL,NULL,'',NULL),(590,272,216,'sponsor',NULL,NULL,NULL,'',NULL),(2055,272,472,'sponsor',NULL,NULL,NULL,'',NULL),(592,490,329,'sponsor',NULL,NULL,NULL,'',NULL),(593,490,141,'sponsor',NULL,NULL,NULL,'',NULL),(594,490,135,'sponsor',NULL,NULL,NULL,'',NULL),(595,490,66,'sponsor',NULL,NULL,NULL,'',NULL),(2175,654,385,'field',NULL,NULL,NULL,'',NULL),(597,360,284,'support',NULL,'','','',NULL),(598,360,275,'support',NULL,'','','',NULL),(599,444,340,'sponsor',NULL,NULL,NULL,'',NULL),(600,487,340,'sponsor',NULL,NULL,NULL,'',NULL),(601,490,340,'sponsor',NULL,NULL,NULL,'',NULL),(602,272,341,'sponsor',NULL,NULL,NULL,'',NULL),(603,444,342,'sponsor',NULL,NULL,NULL,'',NULL),(604,272,343,'sponsor',NULL,NULL,NULL,'',NULL),(605,272,348,'sponsor',NULL,NULL,NULL,'',NULL),(606,272,349,'sponsor',NULL,NULL,NULL,'',NULL),(607,272,339,'sponsor',NULL,NULL,NULL,'',NULL),(608,272,352,'sponsor',NULL,NULL,NULL,'',NULL),(609,272,353,'sponsor',NULL,NULL,NULL,'',NULL),(610,272,354,'sponsor',NULL,NULL,NULL,'',NULL),(611,272,355,'sponsor',NULL,NULL,NULL,'',NULL),(612,272,356,'sponsor',NULL,NULL,NULL,'',NULL),(613,272,357,'sponsor',NULL,NULL,NULL,'',NULL),(614,272,213,'sponsor',NULL,NULL,NULL,'',NULL),(615,539,358,'sponsor',NULL,NULL,NULL,'',NULL),(616,275,360,'sponsor',NULL,NULL,NULL,'',NULL),(617,275,361,'sponsor',NULL,NULL,NULL,'',NULL),(1788,588,420,'field',NULL,NULL,NULL,'',NULL),(619,444,362,'sponsor',NULL,NULL,NULL,'',NULL),(620,272,363,'sponsor',NULL,NULL,NULL,'',NULL),(621,545,276,'sponsor',NULL,NULL,NULL,'',NULL),(622,275,364,'sponsor',NULL,NULL,NULL,'',NULL),(623,272,365,'sponsor',NULL,NULL,NULL,'',NULL),(624,275,366,'sponsor',NULL,NULL,NULL,'',NULL),(625,275,367,'sponsor',NULL,NULL,NULL,'',NULL),(626,539,369,'support',NULL,'','','',NULL),(627,539,370,'support',NULL,'','','',NULL),(628,539,371,'support',NULL,'','','',NULL),(629,539,372,'support',NULL,'','','',NULL),(630,539,373,'support',NULL,'','','',NULL),(631,539,374,'funding',3.00,'','','',NULL),(632,539,375,'support',NULL,'','','',NULL),(633,539,376,'support',NULL,'','','',NULL),(634,539,377,'support',NULL,'','','',NULL),(635,539,378,'support',NULL,'','','',NULL),(636,539,379,'support',NULL,'','','',NULL),(637,539,380,'support',NULL,'','','',NULL),(638,539,381,'support',NULL,'','','',NULL),(639,539,382,'support',NULL,'','','',NULL),(640,273,385,'funding',118381.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(641,275,387,'sponsor',NULL,NULL,NULL,'',NULL),(642,275,389,'sponsor',NULL,NULL,NULL,'',NULL),(643,275,388,'sponsor',NULL,NULL,NULL,'',NULL),(644,444,391,'sponsor',NULL,NULL,NULL,'',NULL),(645,444,395,'sponsor',NULL,NULL,NULL,'',NULL),(646,272,396,'sponsor',NULL,NULL,NULL,'',NULL),(647,275,397,'sponsor',NULL,NULL,NULL,'',NULL),(648,272,399,'sponsor',NULL,NULL,NULL,'',NULL),(649,275,392,'sponsor',NULL,NULL,NULL,'',NULL),(650,275,393,'sponsor',NULL,NULL,NULL,'',NULL),(651,275,394,'sponsor',NULL,NULL,NULL,'',NULL),(652,275,398,'sponsor',NULL,NULL,NULL,'',NULL),(653,56,43,'support',NULL,NULL,NULL,'',NULL),(654,56,42,'support',NULL,NULL,NULL,'',NULL),(655,8,14,'support',NULL,NULL,NULL,'',NULL),(656,15,16,'support',NULL,NULL,NULL,'',NULL),(657,15,17,'support',NULL,NULL,NULL,'',NULL),(658,13,18,'support',NULL,NULL,NULL,'',NULL),(659,15,19,'support',NULL,NULL,NULL,'',NULL),(660,13,20,'support',NULL,NULL,NULL,'',NULL),(661,13,15,'support',NULL,NULL,NULL,'',NULL),(662,15,21,'support',NULL,NULL,NULL,'',NULL),(663,13,22,'support',NULL,NULL,NULL,'',NULL),(664,34,23,'support',NULL,NULL,NULL,'',NULL),(665,15,24,'support',NULL,NULL,NULL,'',NULL),(666,8,25,'support',NULL,NULL,NULL,'',NULL),(667,8,26,'support',NULL,NULL,NULL,'',NULL),(668,8,27,'support',NULL,NULL,NULL,'',NULL),(669,8,28,'support',NULL,NULL,NULL,'',NULL),(670,35,29,'support',NULL,NULL,NULL,'',NULL),(671,15,30,'support',NULL,NULL,NULL,'',NULL),(2813,188,612,'field',NULL,NULL,NULL,'',NULL),(677,43,41,'support',NULL,NULL,NULL,'',NULL),(678,43,38,'support',NULL,NULL,NULL,'',NULL),(680,8,20,'support',NULL,NULL,NULL,'',NULL),(681,42,2,'support',NULL,NULL,NULL,'',NULL),(682,43,39,'support',NULL,NULL,NULL,'',NULL),(683,43,40,'support',NULL,NULL,NULL,'',NULL),(684,106,72,'support',NULL,NULL,NULL,'',NULL),(685,56,44,'support',NULL,NULL,NULL,'',NULL),(686,15,45,'support',NULL,NULL,NULL,'',NULL),(687,106,76,'support',NULL,NULL,NULL,'',NULL),(688,43,46,'support',NULL,NULL,NULL,'',NULL),(689,13,47,'support',NULL,NULL,NULL,'',NULL),(2757,815,325,'sponsor',NULL,NULL,NULL,'',NULL),(691,65,49,'support',NULL,NULL,NULL,'',NULL),(692,65,50,'support',NULL,NULL,NULL,'',NULL),(693,65,51,'support',NULL,NULL,NULL,'',NULL),(694,65,52,'support',NULL,NULL,NULL,'',NULL),(695,43,53,'support',NULL,NULL,NULL,'',NULL),(696,36,65,'support',NULL,NULL,NULL,'',NULL),(697,43,54,'support',NULL,NULL,NULL,'',NULL),(698,56,75,'support',NULL,NULL,NULL,'',NULL),(699,43,55,'support',NULL,NULL,NULL,'',NULL),(700,43,56,'support',NULL,NULL,NULL,'',NULL),(701,100,64,'support',NULL,NULL,NULL,'',NULL),(702,43,57,'support',NULL,NULL,NULL,'',NULL),(703,43,58,'support',NULL,NULL,NULL,'',NULL),(704,60,59,'support',NULL,NULL,NULL,'',NULL),(705,65,60,'support',NULL,NULL,NULL,'',NULL),(706,110,73,'support',NULL,NULL,NULL,'',NULL),(3313,113,310,'sponsor',NULL,'','','',NULL),(708,95,62,'support',NULL,NULL,NULL,'',NULL),(709,110,116,'support',NULL,NULL,NULL,'',NULL),(2002,13,464,'funding',66332.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(711,43,69,'support',NULL,NULL,NULL,'',NULL),(712,110,74,'support',NULL,NULL,NULL,'',NULL),(713,43,78,'support',NULL,NULL,NULL,'',NULL),(714,100,80,'support',NULL,NULL,NULL,'',NULL),(715,15,81,'support',NULL,NULL,NULL,'',NULL),(716,15,82,'support',NULL,NULL,NULL,'',NULL),(717,15,83,'support',NULL,NULL,NULL,'',NULL),(718,123,84,'support',NULL,NULL,NULL,'',NULL),(719,110,85,'support',NULL,NULL,NULL,'',NULL),(2775,540,604,'field',NULL,NULL,NULL,'',NULL),(2774,43,603,'support',NULL,NULL,NULL,'',NULL),(727,56,93,'support',NULL,NULL,NULL,'',NULL),(728,56,94,'support',NULL,NULL,NULL,'',NULL),(729,56,95,'support',NULL,NULL,NULL,'',NULL),(730,56,96,'support',NULL,NULL,NULL,'',NULL),(731,56,97,'support',NULL,NULL,NULL,'',NULL),(732,56,98,'support',NULL,NULL,NULL,'',NULL),(733,56,99,'support',NULL,NULL,NULL,'',NULL),(734,65,100,'support',NULL,NULL,NULL,'',NULL),(735,65,101,'support',NULL,NULL,NULL,'',NULL),(736,65,102,'support',NULL,NULL,NULL,'',NULL),(2812,43,612,'support',NULL,NULL,NULL,'',NULL),(738,100,104,'support',NULL,NULL,NULL,'',NULL),(739,34,105,'support',NULL,NULL,NULL,'',NULL),(3312,113,325,'sponsor',NULL,'','','',NULL),(741,35,107,'support',NULL,NULL,NULL,'',NULL),(742,43,108,'support',NULL,NULL,NULL,'',NULL),(744,15,110,'support',NULL,NULL,NULL,'',NULL),(745,15,111,'support',NULL,NULL,NULL,'',NULL),(746,35,112,'support',NULL,NULL,NULL,'',NULL),(747,35,113,'support',NULL,NULL,NULL,'',NULL),(748,35,114,'support',NULL,NULL,NULL,'',NULL),(749,35,115,'support',NULL,NULL,NULL,'',NULL),(750,110,117,'support',NULL,NULL,NULL,'',NULL),(751,110,118,'support',NULL,NULL,NULL,'',NULL),(752,13,119,'support',NULL,NULL,NULL,'',NULL),(753,123,120,'support',NULL,NULL,NULL,'',NULL),(754,157,121,'support',NULL,NULL,NULL,'',NULL),(755,35,122,'support',NULL,NULL,NULL,'',NULL),(756,35,123,'support',NULL,NULL,NULL,'',NULL),(757,35,124,'support',NULL,NULL,NULL,'',NULL),(758,35,125,'support',NULL,NULL,NULL,'',NULL),(759,35,126,'support',NULL,NULL,NULL,'',NULL),(760,35,127,'support',NULL,NULL,NULL,'',NULL),(761,35,128,'support',NULL,NULL,NULL,'',NULL),(762,43,129,'support',NULL,NULL,NULL,'',NULL),(763,95,130,'support',NULL,NULL,NULL,'',NULL),(764,95,131,'support',NULL,NULL,NULL,'',NULL),(765,13,132,'support',NULL,NULL,NULL,'',NULL),(766,43,133,'support',NULL,NULL,NULL,'',NULL),(767,43,134,'support',NULL,NULL,NULL,'',NULL),(768,106,135,'support',NULL,NULL,NULL,'',NULL),(769,180,136,'support',NULL,NULL,NULL,'',NULL),(770,180,137,'support',NULL,NULL,NULL,'',NULL),(771,43,138,'support',NULL,NULL,NULL,'',NULL),(2778,539,604,'funding',1.00,'','','',NULL),(773,43,140,'support',NULL,NULL,NULL,'',NULL),(774,43,141,'support',NULL,NULL,NULL,'',NULL),(775,43,142,'support',NULL,NULL,NULL,'',NULL),(776,43,143,'support',NULL,NULL,NULL,'',NULL),(778,43,145,'support',NULL,NULL,NULL,'',NULL),(2780,538,605,'field',NULL,NULL,NULL,'',NULL),(780,43,147,'support',NULL,NULL,NULL,'',NULL),(781,43,148,'support',NULL,NULL,NULL,'',NULL),(782,43,149,'support',NULL,NULL,NULL,'',NULL),(783,43,150,'support',NULL,NULL,NULL,'',NULL),(784,43,151,'support',NULL,NULL,NULL,'',NULL),(785,43,152,'support',NULL,NULL,NULL,'',NULL),(786,43,153,'support',NULL,NULL,NULL,'',NULL),(787,43,154,'support',NULL,NULL,NULL,'',NULL),(788,43,155,'support',NULL,NULL,NULL,'',NULL),(790,43,157,'support',NULL,NULL,NULL,'',NULL),(791,35,158,'support',NULL,NULL,NULL,'',NULL),(794,8,161,'support',NULL,NULL,NULL,'',NULL),(795,289,131,'support',NULL,NULL,NULL,'',NULL),(796,60,163,'support',NULL,NULL,NULL,'',NULL),(797,207,164,'support',NULL,NULL,NULL,'',NULL),(798,56,165,'support',NULL,NULL,NULL,'',NULL),(799,106,166,'support',NULL,NULL,NULL,'',NULL),(800,60,167,'support',NULL,NULL,NULL,'',NULL),(801,60,168,'support',NULL,NULL,NULL,'',NULL),(802,60,169,'support',NULL,NULL,NULL,'',NULL),(803,60,170,'support',NULL,NULL,NULL,'',NULL),(804,95,171,'support',NULL,NULL,NULL,'',NULL),(805,95,172,'support',NULL,NULL,NULL,'',NULL),(2776,538,604,'field',NULL,NULL,NULL,'',NULL),(807,106,174,'support',NULL,NULL,NULL,'',NULL),(808,43,175,'support',NULL,NULL,NULL,'',NULL),(810,222,177,'support',NULL,NULL,NULL,'',NULL),(811,43,178,'support',NULL,NULL,NULL,'',NULL),(812,43,179,'support',NULL,NULL,NULL,'',NULL),(813,43,180,'support',NULL,NULL,NULL,'',NULL),(814,243,181,'support',NULL,NULL,NULL,'',NULL),(815,43,182,'support',NULL,NULL,NULL,'',NULL),(816,43,183,'support',NULL,NULL,NULL,'',NULL),(817,106,185,'support',NULL,NULL,NULL,'',NULL),(818,106,184,'support',NULL,NULL,NULL,'',NULL),(819,43,187,'support',NULL,NULL,NULL,'',NULL),(4644,106,186,'support',NULL,'','','',NULL),(821,43,188,'support',NULL,NULL,NULL,'',NULL),(822,207,210,'support',NULL,NULL,NULL,'',NULL),(823,260,189,'support',NULL,NULL,NULL,'',NULL),(824,374,280,'support',NULL,NULL,NULL,'',NULL),(825,260,190,'support',NULL,NULL,NULL,'',NULL),(826,34,212,'support',NULL,NULL,NULL,'',NULL),(827,260,191,'support',NULL,NULL,NULL,'',NULL),(828,34,192,'support',NULL,NULL,NULL,'',NULL),(829,34,193,'support',NULL,NULL,NULL,'',NULL),(830,34,194,'support',NULL,NULL,NULL,'',NULL),(831,276,195,'support',NULL,NULL,NULL,'',NULL),(832,276,196,'support',NULL,NULL,NULL,'',NULL),(833,276,197,'support',NULL,NULL,NULL,'',NULL),(834,260,198,'support',NULL,NULL,NULL,'',NULL),(835,34,213,'support',NULL,NULL,NULL,'',NULL),(836,294,211,'support',NULL,NULL,NULL,'',NULL),(837,43,209,'support',NULL,NULL,NULL,'',NULL),(838,180,245,'support',NULL,NULL,NULL,'',NULL),(839,15,200,'support',NULL,NULL,NULL,'',NULL),(840,106,274,'support',NULL,NULL,NULL,'',NULL),(841,366,276,'support',NULL,NULL,NULL,'',NULL),(842,15,199,'support',NULL,NULL,NULL,'',NULL),(843,34,277,'support',NULL,NULL,NULL,'',NULL),(844,106,201,'support',NULL,NULL,NULL,'',NULL),(845,294,202,'support',NULL,NULL,NULL,'',NULL),(846,43,203,'support',NULL,NULL,NULL,'',NULL),(847,43,340,'support',NULL,NULL,NULL,'',NULL),(848,43,204,'support',NULL,NULL,NULL,'',NULL),(849,43,205,'support',NULL,NULL,NULL,'',NULL),(850,361,275,'support',NULL,NULL,NULL,'',NULL),(851,42,276,'support',NULL,NULL,NULL,'',NULL),(852,34,206,'support',NULL,NULL,NULL,'',NULL),(853,8,207,'support',NULL,NULL,NULL,'',NULL),(854,13,366,'support',NULL,NULL,NULL,'',NULL),(2663,430,208,'support',NULL,NULL,NULL,'',NULL),(856,34,214,'support',NULL,NULL,NULL,'',NULL),(857,34,215,'support',NULL,NULL,NULL,'',NULL),(858,34,216,'support',NULL,NULL,NULL,'',NULL),(859,34,217,'support',NULL,NULL,NULL,'',NULL),(860,34,218,'support',NULL,NULL,NULL,'',NULL),(861,34,219,'support',NULL,NULL,NULL,'',NULL),(862,34,220,'support',NULL,NULL,NULL,'',NULL),(863,34,221,'support',NULL,NULL,NULL,'',NULL),(864,43,222,'support',NULL,NULL,NULL,'',NULL),(865,106,223,'support',NULL,NULL,NULL,'',NULL),(866,34,226,'support',NULL,NULL,NULL,'',NULL),(867,34,227,'support',NULL,NULL,NULL,'',NULL),(868,34,228,'support',NULL,NULL,NULL,'',NULL),(869,34,229,'support',NULL,NULL,NULL,'',NULL),(870,34,230,'support',NULL,NULL,NULL,'',NULL),(871,34,231,'support',NULL,NULL,NULL,'',NULL),(872,34,232,'support',NULL,NULL,NULL,'',NULL),(873,34,233,'support',NULL,NULL,NULL,'',NULL),(874,13,234,'support',NULL,NULL,NULL,'',NULL),(875,43,235,'support',NULL,NULL,NULL,'',NULL),(876,106,243,'support',NULL,NULL,NULL,'',NULL),(877,43,236,'support',NULL,NULL,NULL,'',NULL),(878,289,236,'support',NULL,NULL,NULL,'',NULL),(879,43,237,'support',NULL,NULL,NULL,'',NULL),(880,289,237,'support',NULL,NULL,NULL,'',NULL),(881,43,238,'support',NULL,NULL,NULL,'',NULL),(882,34,278,'support',NULL,NULL,NULL,'',NULL),(883,180,246,'support',NULL,NULL,NULL,'',NULL),(884,43,239,'support',NULL,NULL,NULL,'',NULL),(885,382,276,'support',NULL,NULL,NULL,'',NULL),(886,289,222,'support',NULL,NULL,NULL,'',NULL),(887,43,342,'support',NULL,NULL,NULL,'',NULL),(888,209,164,'sponsor',NULL,'','','',NULL),(889,273,216,'support',NULL,'','104880','',NULL),(890,43,240,'support',NULL,NULL,NULL,'',NULL),(891,289,240,'support',NULL,NULL,NULL,'',NULL),(892,157,270,'support',NULL,NULL,NULL,'',NULL),(893,34,242,'support',NULL,NULL,NULL,'',NULL),(894,180,247,'support',NULL,NULL,NULL,'',NULL),(895,180,244,'support',NULL,NULL,NULL,'',NULL),(896,180,248,'support',NULL,NULL,NULL,'',NULL),(897,180,249,'support',NULL,NULL,NULL,'',NULL),(898,180,250,'support',NULL,NULL,NULL,'',NULL),(899,180,251,'support',NULL,NULL,NULL,'',NULL),(900,180,252,'support',NULL,NULL,NULL,'',NULL),(901,180,253,'support',NULL,NULL,NULL,'',NULL),(902,180,254,'support',NULL,NULL,NULL,'',NULL),(903,180,255,'support',NULL,NULL,NULL,'',NULL),(904,180,256,'support',NULL,NULL,NULL,'',NULL),(905,180,257,'support',NULL,NULL,NULL,'',NULL),(906,180,258,'support',NULL,NULL,NULL,'',NULL),(907,180,259,'support',NULL,NULL,NULL,'',NULL),(908,180,260,'support',NULL,NULL,NULL,'',NULL),(909,180,261,'support',NULL,NULL,NULL,'',NULL),(910,180,262,'support',NULL,NULL,NULL,'',NULL),(911,180,263,'support',NULL,NULL,NULL,'',NULL),(912,180,264,'support',NULL,NULL,NULL,'',NULL),(913,43,265,'support',NULL,NULL,NULL,'',NULL),(914,374,279,'support',NULL,NULL,NULL,'',NULL),(915,341,264,'support',NULL,NULL,NULL,'',NULL),(916,341,263,'support',NULL,NULL,NULL,'',NULL),(917,341,262,'support',NULL,NULL,NULL,'',NULL),(918,341,261,'support',NULL,NULL,NULL,'',NULL),(919,341,260,'support',NULL,NULL,NULL,'',NULL),(920,341,259,'support',NULL,NULL,NULL,'',NULL),(921,341,258,'support',NULL,NULL,NULL,'',NULL),(922,341,257,'support',NULL,NULL,NULL,'',NULL),(923,341,256,'support',NULL,NULL,NULL,'',NULL),(924,341,255,'support',NULL,NULL,NULL,'',NULL),(925,341,254,'support',NULL,NULL,NULL,'',NULL),(926,341,253,'support',NULL,NULL,NULL,'',NULL),(927,341,252,'support',NULL,NULL,NULL,'',NULL),(928,341,251,'support',NULL,NULL,NULL,'',NULL),(929,341,250,'support',NULL,NULL,NULL,'',NULL),(930,341,249,'support',NULL,NULL,NULL,'',NULL),(931,341,248,'support',NULL,NULL,NULL,'',NULL),(932,341,247,'support',NULL,NULL,NULL,'',NULL),(933,341,246,'support',NULL,NULL,NULL,'',NULL),(934,341,245,'support',NULL,NULL,NULL,'',NULL),(935,341,244,'support',NULL,NULL,NULL,'',NULL),(936,43,266,'support',NULL,NULL,NULL,'',NULL),(937,34,368,'support',NULL,NULL,NULL,'',NULL),(938,43,267,'support',NULL,NULL,NULL,'',NULL),(939,56,268,'support',NULL,NULL,NULL,'',NULL),(940,43,268,'support',NULL,NULL,NULL,'',NULL),(941,106,269,'support',NULL,NULL,NULL,'',NULL),(942,65,272,'support',NULL,NULL,NULL,'',NULL),(943,43,273,'support',NULL,NULL,NULL,'',NULL),(944,56,271,'support',NULL,NULL,NULL,'',NULL),(945,374,281,'support',NULL,NULL,NULL,'',NULL),(946,60,282,'support',NULL,NULL,NULL,'',NULL),(947,110,285,'support',NULL,NULL,NULL,'',NULL),(948,43,330,'support',NULL,NULL,NULL,'',NULL),(949,222,283,'support',NULL,NULL,NULL,'',NULL),(951,56,340,'support',NULL,NULL,NULL,'',NULL),(952,361,284,'support',NULL,NULL,NULL,'',NULL),(953,106,286,'support',NULL,NULL,NULL,'',NULL),(954,106,287,'support',NULL,NULL,NULL,'',NULL),(2114,20,481,'field',NULL,NULL,NULL,'',NULL),(956,110,289,'support',NULL,NULL,NULL,'',NULL),(957,110,290,'support',NULL,NULL,NULL,'',NULL),(958,106,291,'support',NULL,NULL,NULL,'',NULL),(959,106,292,'support',NULL,NULL,NULL,'',NULL),(960,106,293,'support',NULL,NULL,NULL,'',NULL),(961,34,294,'support',NULL,NULL,NULL,'',NULL),(962,405,294,'support',NULL,NULL,NULL,'',NULL),(963,13,367,'support',NULL,NULL,NULL,'',NULL),(2330,506,552,'field',NULL,NULL,NULL,'',NULL),(2329,360,552,'support',NULL,'','','',NULL),(2328,428,551,'support',NULL,NULL,NULL,'',NULL),(2327,428,551,'funding',560000.00,NULL,NULL,'',NULL),(2326,273,550,'funding',475266.00,NULL,NULL,'',NULL),(969,34,296,'support',NULL,NULL,NULL,'',NULL),(970,319,296,'support',NULL,NULL,NULL,'',NULL),(971,91,297,'support',NULL,NULL,NULL,'',NULL),(2023,91,298,'support',NULL,NULL,NULL,'',NULL),(973,8,299,'support',NULL,NULL,NULL,'',NULL),(974,110,300,'support',NULL,NULL,NULL,'',NULL),(975,42,301,'support',NULL,NULL,NULL,'',NULL),(976,34,302,'support',NULL,NULL,NULL,'',NULL),(977,34,303,'support',NULL,NULL,NULL,'',NULL),(978,34,304,'support',NULL,NULL,NULL,'',NULL),(979,319,304,'support',NULL,NULL,NULL,'',NULL),(980,428,305,'support',NULL,NULL,NULL,'',NULL),(981,428,306,'support',NULL,NULL,NULL,'',NULL),(982,110,307,'support',NULL,NULL,NULL,'',NULL),(984,34,336,'support',NULL,NULL,NULL,'',NULL),(985,43,310,'support',NULL,NULL,NULL,'',NULL),(986,273,336,'support',NULL,'','103825','',NULL),(1826,405,429,'funding',NULL,NULL,NULL,'',NULL),(988,65,311,'support',NULL,NULL,NULL,'',NULL),(989,273,337,'support',NULL,'','106634','',NULL),(990,405,312,'support',NULL,NULL,NULL,'',NULL),(991,405,313,'support',NULL,NULL,NULL,'',NULL),(992,34,312,'support',NULL,NULL,NULL,'',NULL),(993,34,313,'support',NULL,NULL,NULL,'',NULL),(994,654,314,'field',NULL,NULL,NULL,'',NULL),(995,34,314,'support',NULL,NULL,NULL,'',NULL),(996,43,315,'support',NULL,NULL,NULL,'',NULL),(1827,34,429,'support',NULL,NULL,NULL,'',NULL),(998,319,316,'support',NULL,NULL,NULL,'',NULL),(999,34,316,'support',NULL,NULL,NULL,'',NULL),(1000,319,317,'support',NULL,NULL,NULL,'',NULL),(1001,34,317,'support',NULL,NULL,NULL,'',NULL),(1002,405,318,'support',NULL,NULL,NULL,'',NULL),(1003,34,318,'support',NULL,NULL,NULL,'',NULL),(1004,34,320,'support',NULL,NULL,NULL,'',NULL),(1005,319,320,'support',NULL,NULL,NULL,'',NULL),(1006,319,321,'support',NULL,NULL,NULL,'',NULL),(1007,34,321,'support',NULL,NULL,NULL,'',NULL),(1008,319,322,'support',NULL,NULL,NULL,'',NULL),(1009,34,322,'support',NULL,NULL,NULL,'',NULL),(1010,319,323,'support',NULL,NULL,NULL,'',NULL),(1011,34,323,'support',NULL,NULL,NULL,'',NULL),(1012,43,325,'support',NULL,NULL,NULL,'',NULL),(1013,34,353,'support',NULL,NULL,NULL,'',NULL),(1014,43,326,'support',NULL,NULL,NULL,'',NULL),(1015,273,341,'support',NULL,'','106498','',NULL),(3293,907,657,'field',NULL,'','','',NULL),(1017,405,327,'support',NULL,NULL,NULL,'',NULL),(1018,34,327,'support',NULL,NULL,NULL,'',NULL),(1019,405,328,'support',NULL,NULL,NULL,'',NULL),(1020,34,328,'support',NULL,NULL,NULL,'',NULL),(1021,43,329,'support',NULL,NULL,NULL,'',NULL),(1022,34,341,'support',NULL,NULL,NULL,'',NULL),(1023,8,361,'support',NULL,NULL,NULL,'',NULL),(1024,106,338,'support',NULL,NULL,NULL,'',NULL),(1025,34,365,'support',NULL,NULL,NULL,'',NULL),(1026,273,331,'support',NULL,'','106211','',NULL),(1027,34,331,'support',NULL,NULL,NULL,'',NULL),(1028,654,331,'support',NULL,NULL,NULL,'',NULL),(1029,34,363,'support',NULL,NULL,NULL,'',NULL),(1030,405,363,'support',NULL,NULL,NULL,'',NULL),(1031,43,332,'support',NULL,NULL,NULL,'',NULL),(1032,273,343,'support',NULL,'','104370','',NULL),(1033,110,333,'support',NULL,NULL,NULL,'',NULL),(1034,405,352,'support',NULL,NULL,NULL,'',NULL),(1035,8,360,'support',NULL,NULL,NULL,'',NULL),(1036,180,358,'support',NULL,NULL,NULL,'',NULL),(1037,319,357,'support',NULL,NULL,NULL,'',NULL),(1038,34,357,'support',NULL,NULL,NULL,'',NULL),(1039,34,356,'support',NULL,NULL,NULL,'',NULL),(1040,319,356,'support',NULL,NULL,NULL,'',NULL),(1041,319,355,'support',NULL,NULL,NULL,'',NULL),(1042,34,355,'support',NULL,NULL,NULL,'',NULL),(1043,34,354,'support',NULL,NULL,NULL,'',NULL),(1044,319,354,'support',NULL,NULL,NULL,'',NULL),(1045,319,353,'support',NULL,NULL,NULL,'',NULL),(1046,43,334,'support',NULL,NULL,NULL,'',NULL),(1047,503,344,'support',NULL,NULL,NULL,'',NULL),(1048,525,345,'support',NULL,NULL,NULL,'',NULL),(1049,43,347,'support',NULL,NULL,NULL,'',NULL),(1050,13,350,'support',NULL,NULL,NULL,'',NULL),(1051,273,348,'support',NULL,'','106501','',NULL),(1052,34,337,'support',NULL,NULL,NULL,'',NULL),(1053,43,362,'support',NULL,NULL,NULL,'',NULL),(1054,34,349,'support',NULL,NULL,NULL,'',NULL),(1055,319,349,'support',NULL,NULL,NULL,'',NULL),(1056,106,359,'support',NULL,NULL,NULL,'',NULL),(1057,34,348,'support',NULL,NULL,NULL,'',NULL),(1058,525,346,'support',NULL,NULL,NULL,'',NULL),(2726,43,595,'support',NULL,NULL,NULL,'',NULL),(1060,273,365,'support',NULL,'','106296','',NULL),(1061,34,208,'support',NULL,NULL,NULL,'',NULL),(1062,405,351,'support',NULL,NULL,NULL,'',NULL),(1063,319,339,'support',NULL,NULL,NULL,'',NULL),(1064,34,339,'support',NULL,NULL,NULL,'',NULL),(3298,113,674,'sponsor',NULL,'','','',NULL),(3299,815,674,'sponsor',NULL,'','','',NULL),(3300,35,674,'field',0.00,'','','',NULL),(3302,910,674,'funding',0.00,'','','',NULL),(3303,911,668,'field',NULL,'','','',NULL),(3305,113,615,'sponsor',NULL,'','','',NULL),(3306,113,600,'sponsor',NULL,'','','',NULL),(3307,113,588,'sponsor',NULL,'','','',NULL),(3308,113,577,'sponsor',NULL,'','','',NULL),(1078,525,383,'support',NULL,NULL,NULL,'',NULL),(1079,525,384,'support',NULL,NULL,NULL,'',NULL),(2192,654,317,'field',NULL,NULL,NULL,'',NULL),(1081,8,387,'support',NULL,NULL,NULL,'',NULL),(1082,8,389,'support',NULL,NULL,NULL,'',NULL),(1083,319,390,'support',NULL,NULL,NULL,'',NULL),(1084,95,388,'support',NULL,NULL,NULL,'',NULL),(1085,94,386,'field',NULL,NULL,NULL,'',NULL),(1086,43,391,'support',NULL,NULL,NULL,'',NULL),(1087,35,392,'support',NULL,NULL,NULL,'',NULL),(1088,35,393,'support',NULL,NULL,NULL,'',NULL),(1089,35,394,'support',NULL,NULL,NULL,'',NULL),(1090,207,395,'support',NULL,NULL,NULL,'',NULL),(1091,43,395,'support',NULL,NULL,NULL,'',NULL),(1092,405,396,'support',NULL,NULL,NULL,'',NULL),(1093,34,396,'support',NULL,NULL,NULL,'',NULL),(1094,13,392,'support',NULL,NULL,NULL,'',NULL),(1095,405,397,'support',NULL,NULL,NULL,'',NULL),(1096,35,398,'support',NULL,NULL,NULL,'',NULL),(1097,405,399,'support',NULL,NULL,NULL,'',NULL),(1098,43,26,'funding',7444.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1099,42,2,'funding',1.00,NULL,NULL,'',NULL),(1100,55,41,'funding',2350.00,NULL,NULL,'',NULL),(1101,43,41,'funding',8800.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1102,8,14,'funding',6290.00,NULL,NULL,'',NULL),(1103,13,15,'funding',8000.00,NULL,NULL,'',NULL),(1104,1,18,'funding',18000.00,NULL,NULL,'',NULL),(1105,1,20,'funding',14921.00,NULL,NULL,'',NULL),(1106,8,25,'funding',13752.00,NULL,NULL,'',NULL),(1107,8,26,'funding',7444.00,NULL,NULL,'',NULL),(1108,8,27,'funding',8290.00,NULL,NULL,'',NULL),(1109,8,28,'funding',10231.00,NULL,NULL,'',NULL),(1110,1,22,'funding',16000.00,NULL,NULL,'',NULL),(1111,44,38,'funding',10995.00,NULL,NULL,'',NULL),(2810,41,37,'funding',11200.00,NULL,NULL,'',NULL),(1113,43,38,'funding',11000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1114,43,39,'funding',6433.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1115,43,40,'funding',4250.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1116,46,40,'funding',4250.00,NULL,NULL,'',NULL),(1117,52,24,'funding',10298.00,NULL,NULL,'',NULL),(1118,53,24,'funding',10298.00,NULL,NULL,'',NULL),(1119,43,27,'funding',8290.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1120,55,29,'funding',6270.00,NULL,NULL,'',NULL),(1121,47,39,'funding',6432.00,NULL,NULL,'',NULL),(1122,34,23,'funding',9223.00,NULL,NULL,'',NULL),(1123,162,43,'funding',2939.50,NULL,NULL,'',NULL),(1124,29,30,'funding',10411.00,NULL,NULL,'',NULL),(1125,43,30,'funding',10411.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1126,43,16,'funding',10427.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1127,16,16,'funding',10427.00,NULL,NULL,'',NULL),(1128,17,17,'funding',5234.00,NULL,NULL,'',NULL),(1129,43,17,'funding',5235.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1130,42,47,'funding',8000.00,NULL,NULL,'',NULL),(1131,68,51,'funding',4500.00,NULL,NULL,'',NULL),(1132,103,66,'funding',60000.00,NULL,NULL,'',NULL),(1133,80,53,'funding',29644.00,NULL,NULL,'',NULL),(1134,164,54,'funding',8409.00,NULL,NULL,'',NULL),(1135,80,55,'funding',10550.00,NULL,NULL,'',NULL),(1136,80,56,'funding',2550.00,NULL,NULL,'',NULL),(1137,80,58,'funding',15700.00,NULL,NULL,'',NULL),(1138,60,59,'funding',40000.00,NULL,NULL,'',NULL),(1139,87,59,'funding',162200.00,NULL,NULL,'',NULL),(1140,43,60,'funding',39658.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1141,89,60,'funding',4400.00,NULL,NULL,'',NULL),(1142,90,60,'funding',4400.00,NULL,NULL,'',NULL),(1143,65,60,'funding',1616.00,NULL,NULL,'',NULL),(1144,88,60,'funding',500.00,NULL,NULL,'',NULL),(2811,30,31,'funding',8960.00,NULL,NULL,'',NULL),(1146,93,31,'funding',3840.00,NULL,NULL,'',NULL),(1147,104,66,'funding',15000.00,NULL,NULL,'',NULL),(1148,80,62,'funding',12971.00,NULL,NULL,'',NULL),(1149,80,57,'funding',13610.00,NULL,NULL,'',NULL),(1150,67,51,'funding',382.00,NULL,NULL,'',NULL),(1151,234,49,'funding',1151.00,NULL,NULL,'',NULL),(1152,169,50,'funding',1211.00,NULL,NULL,'',NULL),(1153,118,50,'funding',830.00,NULL,NULL,'',NULL),(1154,52,61,'funding',2225.00,NULL,NULL,'',NULL),(1155,52,41,'funding',2350.00,NULL,NULL,'',NULL),(1156,52,50,'funding',375.00,NULL,NULL,'',NULL),(1157,64,49,'funding',100.00,NULL,NULL,'',NULL),(1158,101,69,'funding',3493.00,NULL,NULL,'',NULL),(1159,53,61,'funding',2227.00,NULL,NULL,'',NULL),(1160,52,29,'funding',6269.00,NULL,NULL,'',NULL),(1161,53,42,'funding',5326.00,NULL,NULL,'',NULL),(1162,43,54,'funding',13097.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1163,43,56,'funding',8765.50,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1164,52,46,'funding',1153.00,NULL,NULL,'',NULL),(1165,106,72,'funding',3790.00,NULL,NULL,'',NULL),(1166,111,73,'funding',5806.00,NULL,NULL,'',NULL),(1167,43,69,'funding',11823.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1168,43,78,'funding',7750.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1169,66,50,'funding',2028.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1170,13,350,'funding',62006.78,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1171,123,84,'funding',21379.00,NULL,NULL,'',NULL),(1172,126,63,'funding',100.00,NULL,NULL,'',NULL),(1173,126,64,'funding',100.00,NULL,NULL,'',NULL),(1174,126,69,'funding',100.00,NULL,NULL,'',NULL),(1175,126,76,'funding',100.00,NULL,NULL,'',NULL),(1176,131,88,'funding',17000.00,NULL,NULL,'',NULL),(1177,165,75,'funding',1500.00,NULL,NULL,'',NULL),(1178,139,100,'funding',8690.00,NULL,NULL,'',NULL),(1179,166,101,'funding',2010.00,NULL,NULL,'',NULL),(1180,140,101,'funding',17000.00,NULL,NULL,'',NULL),(1181,143,102,'funding',1700.00,NULL,NULL,'',NULL),(1182,144,103,'funding',500.00,NULL,NULL,'',NULL),(1183,34,105,'funding',35000.00,NULL,NULL,'',NULL),(1184,106,107,'funding',2002.00,'','','',NULL),(1185,126,104,'funding',100.00,NULL,NULL,'',NULL),(1186,230,108,'funding',647.60,NULL,NULL,'',NULL),(1187,52,42,'funding',5326.00,NULL,NULL,'',NULL),(1188,153,113,'funding',29031.00,NULL,NULL,'',NULL),(2436,734,574,'sponsor',NULL,NULL,NULL,'',NULL),(1190,154,114,'funding',4735.10,NULL,NULL,'',NULL),(1191,155,115,'funding',14930.50,NULL,NULL,'',NULL),(1192,102,66,'funding',19871.00,NULL,NULL,'',NULL),(1193,157,121,'funding',39265.00,'','','',NULL),(1194,114,78,'funding',3000.00,NULL,NULL,'',NULL),(1195,79,56,'funding',6215.50,NULL,NULL,'',NULL),(1196,159,122,'funding',2050.30,NULL,NULL,'',NULL),(1197,160,123,'funding',5558.50,NULL,NULL,'',NULL),(1198,161,124,'funding',3102.30,NULL,NULL,'',NULL),(1199,161,125,'funding',3102.30,NULL,NULL,'',NULL),(1200,161,126,'funding',3102.30,NULL,NULL,'',NULL),(1201,161,127,'funding',3102.30,NULL,NULL,'',NULL),(1202,43,43,'funding',2939.50,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1203,56,43,'funding',5500.00,NULL,NULL,'',NULL),(1204,43,49,'funding',3500.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1205,80,54,'funding',3328.00,NULL,NULL,'',NULL),(1206,43,75,'funding',19251.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1207,43,101,'funding',59487.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1208,126,108,'funding',100.00,NULL,NULL,'',NULL),(1209,43,50,'funding',5333.00,NULL,NULL,'',NULL),(1210,98,50,'funding',847.00,NULL,NULL,'',NULL),(1211,154,128,'funding',3308.00,NULL,NULL,'',NULL),(1212,289,204,'funding',1492.03,NULL,NULL,'',NULL),(1213,168,129,'funding',2845.00,NULL,NULL,'',NULL),(1214,95,131,'funding',50116.00,NULL,NULL,'',NULL),(1215,53,135,'funding',4551.00,NULL,NULL,'',NULL),(1216,181,135,'funding',250.00,NULL,NULL,'',NULL),(1217,233,135,'funding',1000.00,NULL,NULL,'',NULL),(1218,177,135,'funding',2500.00,NULL,NULL,'',NULL),(1219,176,135,'funding',7000.00,NULL,NULL,'',NULL),(1220,238,144,'funding',1721.08,NULL,NULL,'',NULL),(1221,186,144,'funding',130000.00,NULL,NULL,'',NULL),(1222,210,132,'funding',22891.00,NULL,NULL,'',NULL),(1223,209,152,'funding',8411.08,NULL,NULL,'',NULL),(1224,190,152,'funding',2803.69,NULL,NULL,'',NULL),(1225,191,152,'funding',2803.69,NULL,NULL,'',NULL),(1226,209,153,'funding',47126.00,NULL,NULL,'',NULL),(1227,193,153,'funding',5000.00,NULL,NULL,'',NULL),(1228,80,153,'funding',12718.00,NULL,NULL,'',NULL),(1229,164,143,'funding',10913.00,NULL,NULL,'',NULL),(1230,164,129,'funding',9405.00,NULL,NULL,'',NULL),(1231,207,164,'funding',210670.00,NULL,NULL,'',NULL),(1232,43,164,'funding',226730.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1233,165,152,'funding',2803.69,NULL,NULL,'',NULL),(1234,173,132,'funding',4257.00,NULL,NULL,'',NULL),(1235,209,134,'funding',10955.00,NULL,NULL,'',NULL),(1236,212,134,'funding',19000.00,NULL,NULL,'',NULL),(1237,168,108,'funding',100.00,NULL,NULL,'',NULL),(1238,214,166,'funding',10000.00,NULL,NULL,'',NULL),(1239,43,129,'funding',12250.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1240,106,166,'funding',10000.00,NULL,NULL,'',NULL),(1241,60,167,'funding',14933.00,NULL,NULL,'',NULL),(1242,60,168,'funding',14933.00,NULL,NULL,'',NULL),(1243,60,169,'funding',14933.00,NULL,NULL,'',NULL),(1244,60,170,'funding',14933.00,NULL,NULL,'',NULL),(1245,215,173,'funding',10342.00,NULL,NULL,'',NULL),(1246,209,157,'funding',8974.00,NULL,NULL,'',NULL),(1247,216,175,'funding',17066.00,NULL,NULL,'',NULL),(1248,217,175,'funding',9450.00,NULL,NULL,'',NULL),(1249,96,175,'funding',6370.00,NULL,NULL,'',NULL),(1250,43,175,'funding',3673.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1251,43,94,'funding',20000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1252,221,50,'funding',400.00,NULL,NULL,'',NULL),(1253,106,135,'funding',8500.00,NULL,NULL,'',NULL),(1254,43,152,'funding',15178.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1255,53,178,'funding',6000.00,NULL,NULL,'',NULL),(1256,43,141,'funding',6653.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1257,226,141,'funding',5000.00,NULL,NULL,'',NULL),(1258,229,86,'funding',7948.00,NULL,NULL,'',NULL),(1259,209,145,'funding',5180.50,NULL,NULL,'',NULL),(1260,43,145,'funding',5180.50,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1261,43,153,'funding',17718.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1262,209,155,'funding',1400.00,NULL,NULL,'',NULL),(1263,250,142,'funding',2277.00,NULL,NULL,'',NULL),(1264,209,154,'funding',2551.00,NULL,NULL,'',NULL),(1265,96,134,'funding',36000.00,NULL,NULL,'',NULL),(1266,168,49,'funding',1680.00,NULL,NULL,'',NULL),(1267,235,89,'funding',11029.00,NULL,NULL,'',NULL),(1268,374,279,'funding',32950.00,NULL,NULL,'',NULL),(1269,237,120,'funding',3306.34,NULL,NULL,'',NULL),(1270,174,144,'funding',100000.00,NULL,NULL,'',NULL),(1271,209,180,'funding',7138.00,NULL,NULL,'',NULL),(1272,43,180,'funding',11162.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1273,209,138,'funding',4280.00,NULL,NULL,'',NULL),(1274,75,138,'funding',9500.00,NULL,NULL,'',NULL),(1275,209,179,'funding',2481.17,NULL,NULL,'',NULL),(1276,43,179,'funding',16303.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1277,43,155,'funding',1400.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1278,43,157,'funding',5526.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1279,43,154,'funding',1665.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1280,209,142,'funding',2429.00,NULL,NULL,'',NULL),(1281,241,176,'funding',15914.00,NULL,NULL,'',NULL),(1282,219,176,'funding',30236.00,NULL,NULL,'',NULL),(1283,53,72,'funding',3790.00,NULL,NULL,'',NULL),(1284,43,138,'funding',12248.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1285,15,200,'funding',1000.00,NULL,NULL,'',NULL),(1286,209,171,'funding',29478.24,NULL,NULL,'',NULL),(1287,43,171,'funding',56354.91,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1288,209,147,'funding',943.00,NULL,NULL,'',NULL),(1289,43,147,'funding',943.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1290,209,148,'funding',1880.00,NULL,NULL,'',NULL),(1291,43,148,'funding',1880.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1292,43,182,'funding',2176.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1293,209,182,'funding',2176.00,NULL,NULL,'',NULL),(1294,209,150,'funding',2730.00,NULL,NULL,'',NULL),(1295,43,150,'funding',2730.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1296,209,151,'funding',1815.00,NULL,NULL,'',NULL),(1297,43,151,'funding',1815.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1298,245,143,'funding',7500.00,NULL,NULL,'',NULL),(1299,209,143,'funding',736.70,NULL,NULL,'',NULL),(1300,43,143,'funding',40441.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1301,246,163,'funding',1070.00,NULL,NULL,'',NULL),(1302,209,183,'funding',1260.00,NULL,NULL,'',NULL),(1303,43,183,'funding',1260.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1304,247,156,'funding',5600.00,NULL,NULL,'',NULL),(1305,106,184,'funding',8263.00,NULL,NULL,'',NULL),(1306,106,185,'funding',2300.00,NULL,NULL,'',NULL),(1307,248,184,'funding',7500.00,NULL,NULL,'',NULL),(1308,43,161,'funding',88747.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1309,209,161,'funding',88373.00,NULL,NULL,'',NULL),(1310,43,178,'funding',6000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1311,43,142,'funding',4706.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1312,252,186,'funding',15910.00,'','','',NULL),(1313,106,186,'funding',16000.00,NULL,NULL,'',NULL),(1315,152,133,'funding',3000.00,NULL,NULL,'',NULL),(1316,255,187,'funding',4800.00,NULL,NULL,'',NULL),(1317,254,187,'funding',10000.00,NULL,NULL,'',NULL),(1318,43,187,'funding',40000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1319,209,188,'funding',7955.00,NULL,NULL,'',NULL),(1320,256,188,'funding',11607.00,NULL,NULL,'',NULL),(1321,115,188,'funding',20924.00,NULL,NULL,'',NULL),(1322,43,188,'funding',19562.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1323,273,212,'funding',30720.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1324,207,210,'funding',69251.00,'','','',NULL),(1325,43,210,'funding',84000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1326,266,191,'funding',22150.00,NULL,NULL,'',NULL),(1327,34,192,'funding',186920.00,NULL,NULL,'',NULL),(1328,268,187,'funding',13000.00,NULL,NULL,'',NULL),(1329,106,223,'funding',13742.00,NULL,NULL,'',NULL),(1330,34,194,'funding',80000.00,NULL,NULL,'',NULL),(1331,273,194,'funding',149765.00,NULL,NULL,'',NULL),(1332,271,194,'funding',161460.00,NULL,NULL,'',NULL),(1333,277,195,'funding',1000.00,NULL,NULL,'',NULL),(1334,278,195,'funding',6000.00,NULL,NULL,'',NULL),(1335,279,196,'funding',6880.00,NULL,NULL,'',NULL),(1336,281,197,'funding',15000.00,NULL,NULL,'',NULL),(1337,280,197,'funding',10000.00,NULL,NULL,'',NULL),(1338,282,197,'funding',10000.00,NULL,NULL,'',NULL),(1339,283,184,'funding',2531.24,NULL,NULL,'',NULL),(1340,284,184,'funding',2468.76,NULL,NULL,'',NULL),(1341,305,213,'funding',18203.00,'','','',NULL),(1342,34,213,'funding',35117.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1343,294,211,'funding',3951.00,NULL,NULL,'',NULL),(1344,301,134,'funding',500.00,NULL,NULL,'',NULL),(1345,134,198,'funding',30187.50,NULL,NULL,'',NULL),(1346,15,199,'funding',1000.00,NULL,NULL,'',NULL),(1347,209,131,'funding',26877.00,NULL,NULL,'',NULL),(1348,290,187,'funding',28800.00,NULL,NULL,'',NULL),(1349,291,75,'funding',400.00,NULL,NULL,'',NULL),(1350,106,201,'funding',3750.00,NULL,NULL,'',NULL),(1351,296,202,'funding',9000.00,NULL,NULL,'',NULL),(1352,294,202,'funding',1200.00,NULL,NULL,'',NULL),(1353,52,165,'funding',8000.00,NULL,NULL,'',NULL),(1354,34,206,'funding',21000.00,NULL,NULL,'',NULL),(1355,299,207,'funding',254739.00,NULL,NULL,'',NULL),(1356,273,208,'funding',45000.00,NULL,NULL,'',NULL),(1357,494,94,'funding',331.00,NULL,NULL,'',NULL),(1358,304,213,'funding',47500.00,'','','',NULL),(1359,34,214,'funding',66724.00,NULL,NULL,'',NULL),(1360,273,215,'funding',450781.00,NULL,NULL,'',NULL),(1361,34,215,'funding',49552.00,NULL,NULL,'',NULL),(1362,273,216,'funding',75000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1363,34,216,'funding',75000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1364,34,217,'funding',319776.00,NULL,NULL,'',NULL),(1365,273,218,'funding',100000.00,NULL,NULL,'',NULL),(1366,34,218,'funding',17000.00,NULL,NULL,'',NULL),(1367,34,219,'funding',160000.00,NULL,NULL,'',NULL),(1368,34,220,'funding',131000.00,NULL,NULL,'',NULL),(1369,273,221,'funding',115000.00,NULL,NULL,'',NULL),(1370,315,222,'funding',2500.00,NULL,NULL,'',NULL),(1371,316,69,'funding',1372.00,NULL,NULL,'',NULL),(1372,316,146,'funding',4500.00,NULL,NULL,'',NULL),(1373,316,270,'funding',1000.00,NULL,NULL,'',NULL),(1374,405,351,'funding',100000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1375,318,226,'funding',56000.00,NULL,NULL,'',NULL),(1376,34,226,'funding',65500.00,NULL,NULL,'',NULL),(1377,34,227,'funding',101500.00,NULL,NULL,'',NULL),(1378,34,228,'funding',135564.00,NULL,NULL,'',NULL),(1379,34,229,'funding',111600.00,NULL,NULL,'',NULL),(1380,34,230,'funding',123500.00,NULL,NULL,'',NULL),(1381,321,230,'funding',339100.00,NULL,NULL,'',NULL),(1382,34,231,'funding',166482.00,NULL,NULL,'',NULL),(1383,34,232,'funding',22500.00,NULL,NULL,'',NULL),(1384,148,232,'funding',106194.00,NULL,NULL,'',NULL),(1385,34,233,'funding',144235.00,NULL,NULL,'',NULL),(1386,1,234,'funding',12000.00,NULL,NULL,'',NULL),(1387,325,238,'funding',5410.00,NULL,NULL,'',NULL),(1388,250,235,'funding',2327.00,NULL,NULL,'',NULL),(1389,324,222,'funding',250.00,NULL,NULL,'',NULL),(1390,313,222,'funding',11292.79,NULL,NULL,'',NULL),(1391,34,242,'funding',82000.00,NULL,NULL,'',NULL),(1392,331,228,'funding',39624.00,NULL,NULL,'',NULL),(1393,332,228,'funding',61451.00,NULL,NULL,'',NULL),(1394,330,242,'funding',59500.00,NULL,NULL,'',NULL),(1395,333,242,'funding',20000.00,NULL,NULL,'',NULL),(1396,332,229,'funding',43692.00,NULL,NULL,'',NULL),(1397,318,193,'funding',126500.00,NULL,NULL,'',NULL),(1398,71,179,'funding',13821.58,NULL,NULL,'',NULL),(1399,209,235,'funding',2429.00,NULL,NULL,'',NULL),(1400,43,235,'funding',4706.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1401,59,235,'funding',438.00,NULL,NULL,'',NULL),(1402,106,243,'funding',19710.00,NULL,NULL,'',NULL),(1403,335,243,'funding',19710.00,NULL,NULL,'',NULL),(1404,336,243,'funding',24215.00,NULL,NULL,'',NULL),(1405,338,209,'funding',1469.83,NULL,NULL,'',NULL),(1406,249,185,'funding',2258.00,NULL,NULL,'',NULL),(1407,8,185,'funding',2258.00,NULL,NULL,'',NULL),(1408,339,243,'funding',8400.00,NULL,NULL,'',NULL),(1409,334,141,'funding',338.00,NULL,NULL,'',NULL),(1410,342,209,'funding',5000.00,NULL,NULL,'',NULL),(1411,343,209,'funding',3000.00,NULL,NULL,'',NULL),(1412,168,209,'funding',16312.00,'','','',NULL),(1413,43,268,'funding',50000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1414,164,268,'funding',20000.00,NULL,NULL,'',NULL),(1415,345,268,'funding',70000.00,NULL,NULL,'',NULL),(1416,127,267,'funding',2500.00,NULL,NULL,'',NULL),(1417,341,253,'funding',1.00,NULL,NULL,'',NULL),(1418,341,264,'funding',1.00,NULL,NULL,'',NULL),(1419,341,247,'funding',1.00,NULL,NULL,'',NULL),(1420,341,248,'funding',1.00,NULL,NULL,'',NULL),(1421,341,257,'funding',1.00,NULL,NULL,'',NULL),(1422,106,269,'funding',5000.00,NULL,NULL,'',NULL),(1423,350,269,'funding',5000.00,NULL,NULL,'',NULL),(1424,349,269,'funding',5000.00,NULL,NULL,'',NULL),(1425,289,134,'funding',24000.00,NULL,NULL,'',NULL),(1426,289,265,'funding',3058.00,NULL,NULL,'',NULL),(1427,351,108,'funding',244.00,NULL,NULL,'',NULL),(1428,341,263,'funding',1.00,NULL,NULL,'',NULL),(1429,341,262,'funding',2.00,NULL,NULL,'',NULL),(1430,168,246,'funding',100.00,NULL,NULL,'',NULL),(1431,289,238,'funding',2284.39,NULL,NULL,'',NULL),(1432,341,246,'funding',2.00,NULL,NULL,'',NULL),(1433,289,153,'funding',6438.00,'','','',NULL),(1434,352,270,'funding',4896.00,NULL,NULL,'',NULL),(1435,493,107,'funding',10000.00,NULL,NULL,'',NULL),(1436,353,131,'funding',988.42,NULL,NULL,'',NULL),(1437,354,271,'funding',12850.00,NULL,NULL,'',NULL),(1438,341,245,'funding',340.00,NULL,NULL,'',NULL),(1439,341,244,'funding',212.00,NULL,NULL,'',NULL),(1440,341,249,'funding',278.00,NULL,NULL,'',NULL),(1441,341,250,'funding',373.00,NULL,NULL,'',NULL),(1442,341,251,'funding',447.00,NULL,NULL,'',NULL),(1443,341,252,'funding',601.00,NULL,NULL,'',NULL),(1444,341,254,'funding',661.00,NULL,NULL,'',NULL),(1445,341,255,'funding',231.00,NULL,NULL,'',NULL),(1446,341,256,'funding',612.00,NULL,NULL,'',NULL),(1447,168,258,'funding',554.00,NULL,NULL,'',NULL),(1448,341,259,'funding',397.00,NULL,NULL,'',NULL),(1449,341,260,'funding',462.00,NULL,NULL,'',NULL),(1450,341,261,'funding',249.00,NULL,NULL,'',NULL),(1451,289,209,'funding',3333.00,NULL,NULL,'',NULL),(1452,65,272,'funding',12502.00,NULL,NULL,'',NULL),(1453,106,274,'funding',12219.00,NULL,NULL,'',NULL),(1454,356,274,'funding',17537.00,NULL,NULL,'',NULL),(1455,289,186,'funding',17590.00,'','','',NULL),(1456,289,203,'funding',4202.00,NULL,NULL,'',NULL),(2058,319,472,'support',NULL,NULL,NULL,'',NULL),(4037,1056,697,'field',NULL,'','','',NULL),(1459,289,180,'funding',1700.00,NULL,NULL,'',NULL),(1460,359,209,'funding',5500.00,NULL,NULL,'',NULL),(1461,43,209,'funding',37500.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1462,363,275,'funding',10000.00,NULL,NULL,'',NULL),(1463,361,275,'funding',5000.00,'','','',NULL),(1464,379,276,'funding',25000.00,NULL,NULL,'',NULL),(1465,289,149,'funding',1901.00,NULL,NULL,'',NULL),(1466,289,266,'funding',3340.00,NULL,NULL,'',NULL),(1467,34,277,'funding',3500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1468,368,277,'funding',3500.00,'','','',NULL),(1469,383,116,'funding',2756.50,NULL,NULL,'',NULL),(1470,378,108,'funding',406.39,NULL,NULL,'',NULL),(1471,227,141,'funding',2226.00,NULL,NULL,'',NULL),(1472,227,270,'funding',1452.47,NULL,NULL,'',NULL),(1473,289,239,'funding',11541.60,NULL,NULL,'',NULL),(1474,380,276,'funding',17200.00,NULL,NULL,'',NULL),(1475,381,276,'funding',32000.00,NULL,NULL,'',NULL),(1476,382,276,'funding',13000.00,NULL,NULL,'',NULL),(1477,365,276,'funding',222600.00,NULL,NULL,'',NULL),(1478,52,74,'funding',500.00,NULL,NULL,'',NULL),(1479,371,74,'funding',4027.00,NULL,NULL,'',NULL),(1480,388,274,'funding',6600.00,NULL,NULL,'',NULL),(1481,127,268,'funding',6981.00,NULL,NULL,'',NULL),(1482,217,283,'funding',5000.00,NULL,NULL,'',NULL),(1483,391,283,'funding',5000.00,NULL,NULL,'',NULL),(1484,392,213,'funding',10000.00,'','','',NULL),(1485,392,232,'funding',10000.00,NULL,NULL,'',NULL),(1486,361,284,'funding',2500.00,NULL,NULL,'',NULL),(1487,106,286,'funding',50000.00,NULL,NULL,'',NULL),(1488,395,286,'funding',100000.00,NULL,NULL,'',NULL),(1489,398,286,'funding',40000.00,NULL,NULL,'',NULL),(1490,106,287,'funding',40000.00,NULL,NULL,'',NULL),(1491,403,287,'funding',30000.00,NULL,NULL,'',NULL),(1492,399,287,'funding',5000.00,NULL,NULL,'',NULL),(1493,353,290,'funding',1.00,NULL,NULL,'',NULL),(1494,53,278,'funding',8000.00,'','','',NULL),(1495,53,277,'funding',6083.00,'','','',NULL),(1496,106,291,'funding',24800.00,NULL,NULL,'',NULL),(1497,106,292,'funding',26300.00,NULL,NULL,'',NULL),(1498,106,293,'funding',15000.00,NULL,NULL,'',NULL),(1499,409,293,'funding',5000.00,NULL,NULL,'',NULL),(1500,411,293,'funding',2800.00,NULL,NULL,'',NULL),(1501,53,108,'funding',1142.00,NULL,NULL,'',NULL),(1502,405,294,'funding',261480.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2325,273,550,'support',NULL,'','104438','',NULL),(2324,711,550,'field',NULL,NULL,NULL,'',NULL),(2323,711,549,'field',NULL,NULL,NULL,'',NULL),(2322,273,549,'funding',228202.00,NULL,NULL,'',NULL),(2321,273,549,'support',NULL,'','102861','',NULL),(1508,52,116,'funding',2756.50,NULL,NULL,'',NULL),(1509,346,171,'funding',800.00,NULL,NULL,'',NULL),(1510,346,203,'funding',750.00,NULL,NULL,'',NULL),(1511,319,296,'funding',160000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1512,8,299,'funding',100000.00,NULL,NULL,'',NULL),(1513,52,184,'funding',695.00,NULL,NULL,'',NULL),(1514,228,270,'funding',519.90,NULL,NULL,'',NULL),(1515,42,301,'funding',1.00,NULL,NULL,'',NULL),(1516,392,302,'funding',5000.00,NULL,NULL,'',NULL),(1517,430,305,'funding',6200000.00,NULL,NULL,'',NULL),(1518,431,305,'funding',25000.00,NULL,NULL,'',NULL),(1519,428,305,'funding',137700.00,NULL,NULL,'',NULL),(1520,435,305,'funding',53400.00,NULL,NULL,'',NULL),(1521,428,306,'funding',861800.00,NULL,NULL,'',NULL),(1522,353,307,'funding',100.00,NULL,NULL,'',NULL),(1523,289,207,'funding',170000.00,NULL,NULL,'',NULL),(1524,8,207,'funding',170000.00,NULL,NULL,'',NULL),(1525,442,308,'funding',268963.00,NULL,NULL,'',NULL),(1526,442,309,'funding',248000.00,NULL,NULL,'',NULL),(1527,289,237,'funding',29000.00,NULL,NULL,'',NULL),(1528,446,285,'funding',32672.00,NULL,NULL,'',NULL),(1529,405,312,'funding',18132.50,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1530,457,312,'funding',3153.10,NULL,NULL,'',NULL),(1531,456,313,'funding',3485.00,NULL,NULL,'',NULL),(1532,460,312,'funding',981.11,NULL,NULL,'',NULL),(2305,405,314,'funding',74979.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1534,209,315,'funding',10955.00,NULL,NULL,'',NULL),(1535,212,315,'funding',19000.00,NULL,NULL,'',NULL),(1536,96,315,'funding',36000.00,NULL,NULL,'',NULL),(1537,301,315,'funding',500.00,NULL,NULL,'',NULL),(1538,289,315,'funding',24000.00,NULL,NULL,'',NULL),(1539,461,316,'funding',90588.00,NULL,NULL,'',NULL),(1540,319,317,'funding',137500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1541,319,320,'funding',101737.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1542,319,321,'funding',122593.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1543,405,313,'funding',14248.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1544,319,316,'funding',26109.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1545,319,322,'funding',19368.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1546,319,323,'funding',99141.96,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1547,466,324,'funding',74000.00,NULL,NULL,'',NULL),(1548,464,324,'funding',80000.00,NULL,NULL,'',NULL),(1549,405,327,'funding',122300.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1550,458,327,'funding',35501.00,NULL,NULL,'',NULL),(1551,405,328,'funding',71742.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1552,449,328,'funding',19500.00,NULL,NULL,'',NULL),(1553,405,318,'funding',60000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1554,301,210,'funding',500.00,NULL,NULL,'',NULL),(1555,289,210,'funding',70500.00,'','','',NULL),(2177,688,75,'funding',386.00,NULL,NULL,'',NULL),(1557,273,331,'funding',55000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(4097,489,647,'funding',5202.00,'','','',NULL),(1559,485,332,'funding',6450.00,NULL,NULL,'',NULL),(1560,428,335,'funding',1000300.00,NULL,NULL,'',NULL),(1561,120,272,'funding',135.00,NULL,NULL,'',NULL),(1562,273,336,'funding',50000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1563,273,337,'funding',74000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1564,106,338,'funding',35400.00,NULL,NULL,'',NULL),(2178,641,492,'support',NULL,NULL,NULL,'',NULL),(1566,502,342,'funding',0.00,NULL,NULL,'',NULL),(1567,505,344,'funding',15300.00,NULL,NULL,'',NULL),(1568,503,344,'funding',7700.00,NULL,NULL,'',NULL),(1569,504,344,'funding',15000.00,NULL,NULL,'',NULL),(1570,168,293,'funding',15000.00,NULL,NULL,'',NULL),(1571,525,345,'funding',235000.00,NULL,NULL,'',NULL),(1572,525,346,'funding',192700.00,NULL,NULL,'',NULL),(1573,168,346,'funding',51233.00,NULL,NULL,'',NULL),(1574,43,347,'funding',86724.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1575,398,347,'funding',108408.00,NULL,NULL,'',NULL),(1576,168,347,'funding',21600.00,NULL,NULL,'',NULL),(1577,273,343,'funding',32500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1578,492,338,'funding',16493.15,'','','',NULL),(1579,273,348,'funding',139036.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1580,510,332,'funding',300.00,NULL,NULL,'',NULL),(1581,319,349,'funding',160000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1582,316,272,'funding',1000.00,NULL,NULL,'',NULL),(1583,319,339,'funding',22000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1584,34,339,'funding',20000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1585,389,282,'funding',1.00,NULL,NULL,'',NULL),(1586,462,324,'funding',0.00,NULL,NULL,'',NULL),(2179,43,492,'support',NULL,NULL,NULL,'',NULL),(2176,405,413,'funding',12355.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2665,810,452,'field',NULL,NULL,NULL,'',NULL),(1590,164,340,'funding',16220.64,'','','',NULL),(1591,289,268,'funding',0.00,NULL,NULL,'',NULL),(1592,405,352,'funding',164500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1593,319,353,'funding',30000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1594,319,354,'funding',19567.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1595,319,355,'funding',20000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1596,319,356,'funding',20603.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1597,319,357,'funding',30669.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1598,539,358,'funding',0.00,NULL,NULL,'',NULL),(1599,106,359,'funding',11000.00,NULL,NULL,'',NULL),(1600,8,360,'funding',38851.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1601,8,361,'funding',66139.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1789,272,420,'sponsor',NULL,NULL,NULL,'',NULL),(1603,405,363,'funding',100500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1604,8,364,'funding',450000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1605,273,365,'funding',32500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1606,13,366,'funding',231375.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1607,13,367,'funding',208490.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(3294,641,653,'support',NULL,'','','',NULL),(3295,428,673,'funding',276800.00,'','','',NULL),(3297,43,674,'support',NULL,'','','',NULL),(1612,539,373,'funding',4.00,NULL,NULL,'',NULL),(3309,113,427,'funding',500000.00,'','','',NULL),(1614,539,375,'funding',1.00,'','','',NULL),(1615,539,376,'funding',2.00,NULL,NULL,'',NULL),(1616,539,377,'funding',1.00,NULL,NULL,'',NULL),(1617,539,378,'funding',2.00,NULL,NULL,'',NULL),(1618,539,379,'funding',3.00,NULL,NULL,'',NULL),(1619,539,380,'funding',1.00,NULL,NULL,'',NULL),(1620,539,381,'funding',1.00,NULL,NULL,'',NULL),(1621,539,382,'funding',2.00,NULL,NULL,'',NULL),(1622,525,383,'funding',158079.00,NULL,NULL,'',NULL),(1623,168,383,'funding',82102.00,NULL,NULL,'',NULL),(1624,525,384,'funding',250000.00,NULL,NULL,'',NULL),(1625,273,385,'support',118381.00,'','107778','',NULL),(1626,301,204,'funding',4249.00,NULL,NULL,'',NULL),(1627,301,94,'funding',1544.00,NULL,NULL,'',NULL),(1628,301,272,'funding',617.00,NULL,NULL,'',NULL),(1681,273,406,'funding',50000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1630,8,387,'funding',109207.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1631,95,388,'funding',1245000.00,NULL,NULL,'',NULL),(1632,8,389,'funding',536128.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1633,95,386,'funding',950000.00,NULL,NULL,'',NULL),(1680,275,386,'sponsor',NULL,NULL,NULL,'',NULL),(1635,319,390,'funding',28666.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(4173,1061,827,'sponsor',NULL,'','','',NULL),(1637,562,391,'funding',0.00,NULL,NULL,'',NULL),(4172,444,325,'funding',3000.00,'','','',NULL),(1639,35,392,'funding',40660.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1640,405,399,'funding',137737.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1641,35,398,'funding',55201.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1642,35,393,'funding',37746.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1643,569,397,'funding',1665.00,NULL,NULL,'',NULL),(1644,405,397,'funding',7975.64,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1645,35,394,'funding',40660.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(4376,444,391,'funding',15000.00,'','','',NULL),(1647,405,396,'funding',95410.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1648,34,399,'support',NULL,NULL,NULL,'',NULL),(1649,405,400,'funding',97000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1650,405,400,'support',NULL,NULL,NULL,'',NULL),(1651,572,400,'field',17088.00,NULL,NULL,'',NULL),(1943,275,451,'sponsor',NULL,NULL,NULL,'',NULL),(1653,272,400,'sponsor',NULL,NULL,NULL,'',NULL),(1654,572,400,'funding',17088.00,NULL,NULL,'',NULL),(1655,168,400,'funding',12097.00,NULL,NULL,'',NULL),(2418,729,566,'field',NULL,'','','',NULL),(1657,275,401,'sponsor',NULL,NULL,NULL,'',NULL),(1658,405,401,'support',NULL,NULL,NULL,'',NULL),(1659,34,402,'support',NULL,NULL,NULL,'',NULL),(1660,319,402,'support',NULL,NULL,NULL,'',NULL),(1661,576,402,'field',NULL,NULL,NULL,'',NULL),(1662,319,402,'funding',60904.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1663,272,402,'sponsor',NULL,NULL,NULL,'',NULL),(1664,275,403,'sponsor',NULL,NULL,NULL,'',NULL),(1665,35,403,'funding',24996.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1666,415,403,'field',NULL,NULL,NULL,'',NULL),(1667,275,404,'sponsor',NULL,NULL,NULL,'',NULL),(1668,35,404,'support',NULL,NULL,NULL,'',NULL),(1669,35,404,'funding',20000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1670,414,404,'field',NULL,NULL,NULL,'',NULL),(1671,579,405,'field',NULL,NULL,NULL,'',NULL),(1672,580,405,'field',NULL,NULL,NULL,'',NULL),(1673,581,405,'field',NULL,NULL,NULL,'',NULL),(1674,582,405,'field',NULL,NULL,NULL,'',NULL),(1675,272,405,'sponsor',NULL,NULL,NULL,'',NULL),(1676,405,405,'support',NULL,NULL,NULL,'',NULL),(1677,578,405,'field',NULL,NULL,NULL,'',NULL),(1678,578,405,'funding',1864.00,NULL,NULL,'',NULL),(1679,405,405,'funding',59636.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1825,575,429,'field',NULL,NULL,NULL,'',NULL),(1683,654,406,'field',NULL,NULL,NULL,'',NULL),(1685,272,406,'sponsor',NULL,NULL,NULL,'',NULL),(1806,34,423,'support',NULL,NULL,NULL,'',NULL),(1805,405,423,'support',NULL,NULL,NULL,'',NULL),(1804,604,423,'field',NULL,NULL,NULL,'',NULL),(4490,1061,882,'sponsor',NULL,'','','',NULL),(1691,584,408,'field',NULL,NULL,NULL,'',NULL),(4489,1064,882,'funding',1600.00,'','','',NULL),(4488,1064,882,'field',NULL,'','','',NULL),(1694,405,408,'funding',104500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(4717,1165,917,'funding',10200000.00,'','','',NULL),(1695,168,408,'support',209899.00,'','','',NULL),(4491,1064,883,'field',NULL,'','','',NULL),(1697,405,409,'support',NULL,NULL,NULL,'',NULL),(1698,272,409,'sponsor',NULL,NULL,NULL,'',NULL),(1699,571,409,'field',NULL,NULL,NULL,'',NULL),(1700,405,409,'funding',116008.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1701,654,399,'field',NULL,NULL,NULL,'',NULL),(1702,654,363,'field',NULL,NULL,NULL,'',NULL),(1703,654,341,'field',NULL,NULL,NULL,'',NULL),(1704,654,365,'field',NULL,NULL,NULL,'',NULL),(1705,654,343,'field',NULL,NULL,NULL,'',NULL),(1706,654,337,'field',NULL,NULL,NULL,'',NULL),(1707,654,328,'field',NULL,NULL,NULL,'',NULL),(1708,654,323,'field',NULL,NULL,NULL,'',NULL),(1709,654,322,'field',NULL,NULL,NULL,'',NULL),(1710,654,321,'field',NULL,NULL,NULL,'',NULL),(1711,654,320,'field',NULL,NULL,NULL,'',NULL),(1712,654,318,'field',NULL,NULL,NULL,'',NULL),(1713,654,316,'field',NULL,NULL,NULL,'',NULL),(1714,654,294,'field',NULL,NULL,NULL,'',NULL),(1715,654,216,'field',NULL,NULL,NULL,'',NULL),(1716,428,335,'support',NULL,NULL,NULL,'',NULL),(1717,654,312,'field',NULL,NULL,NULL,'',NULL),(1718,34,390,'support',NULL,NULL,NULL,'',NULL),(1719,34,343,'support',NULL,NULL,NULL,'',NULL),(1720,590,273,'funding',1500.00,NULL,NULL,'',NULL),(1721,34,409,'support',NULL,NULL,NULL,'',NULL),(1722,34,406,'support',NULL,NULL,NULL,'',NULL),(1723,583,406,'field',NULL,NULL,NULL,'',NULL),(1724,34,405,'support',NULL,NULL,NULL,'',NULL),(1725,34,400,'support',NULL,NULL,NULL,'',NULL),(1726,319,410,'support',NULL,NULL,NULL,'',NULL),(1727,34,410,'support',NULL,NULL,NULL,'',NULL),(1728,272,410,'sponsor',NULL,NULL,NULL,'',NULL),(1729,591,410,'field',NULL,NULL,NULL,'',NULL),(1730,319,410,'funding',75000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1731,415,403,'funding',10399.00,NULL,NULL,'',NULL),(1732,35,403,'support',NULL,NULL,NULL,'',NULL),(1734,273,341,'funding',32500.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1735,34,352,'support',NULL,NULL,NULL,'',NULL),(1736,586,411,'field',NULL,NULL,NULL,'',NULL),(1737,34,411,'support',NULL,NULL,NULL,'',NULL),(1738,319,411,'support',NULL,NULL,NULL,'',NULL),(1739,272,411,'sponsor',NULL,NULL,NULL,'',NULL),(1740,319,411,'funding',5000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1741,272,278,'sponsor',NULL,NULL,NULL,'',NULL),(1742,592,412,'field',NULL,NULL,NULL,'',NULL),(1743,405,412,'support',NULL,NULL,NULL,'',NULL),(1744,34,412,'support',NULL,NULL,NULL,'',NULL),(1745,272,412,'sponsor',NULL,NULL,NULL,'',NULL),(1746,405,412,'funding',115477.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1747,592,412,'funding',11023.00,NULL,NULL,'',NULL),(1748,275,413,'sponsor',NULL,NULL,NULL,'',NULL),(1749,405,413,'support',NULL,NULL,NULL,'',NULL),(1750,569,413,'field',NULL,NULL,NULL,'',NULL),(1751,34,414,'support',NULL,NULL,NULL,'',NULL),(1752,319,414,'support',NULL,NULL,NULL,'',NULL),(1753,594,414,'field',NULL,NULL,NULL,'',NULL),(1754,595,414,'field',NULL,NULL,NULL,'',NULL),(1755,593,414,'field',NULL,NULL,NULL,'',NULL),(1756,319,414,'funding',20000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(4660,596,415,'funding',212000.00,'','','',NULL),(1758,43,415,'support',NULL,NULL,NULL,'',NULL),(1759,444,415,'sponsor',NULL,NULL,NULL,'',NULL),(1760,596,415,'field',NULL,NULL,NULL,'',NULL),(1761,243,415,'funding',60000.00,'','','',NULL),(1762,585,414,'field',NULL,NULL,NULL,'',NULL),(1763,597,401,'field',NULL,NULL,NULL,'',NULL),(1764,319,416,'support',NULL,NULL,NULL,'',NULL),(1765,34,416,'support',NULL,NULL,NULL,'',NULL),(1766,319,416,'funding',125570.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1767,332,416,'funding',15000.00,NULL,NULL,'',NULL),(1768,34,416,'funding',NULL,NULL,NULL,'',NULL),(1769,321,416,'field',NULL,NULL,NULL,'',NULL),(1770,598,416,'field',NULL,NULL,NULL,'',NULL),(1771,574,417,'field',NULL,NULL,NULL,'',NULL),(1772,34,417,'support',NULL,NULL,NULL,'',NULL),(1773,319,417,'support',NULL,NULL,NULL,'',NULL),(1774,272,417,'sponsor',NULL,NULL,NULL,'',NULL),(1775,272,416,'sponsor',NULL,NULL,NULL,'',NULL),(1776,34,418,'support',NULL,NULL,NULL,'',NULL),(1777,272,418,'sponsor',NULL,NULL,NULL,'',NULL),(1778,319,418,'support',NULL,NULL,NULL,'',NULL),(1779,148,418,'field',NULL,NULL,NULL,'',NULL),(1780,319,418,'funding',25000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1781,34,419,'support',NULL,NULL,NULL,'',NULL),(1782,319,419,'support',NULL,NULL,NULL,'',NULL),(1783,272,419,'sponsor',NULL,NULL,NULL,'',NULL),(1784,599,419,'field',NULL,NULL,NULL,'',NULL),(1785,319,419,'funding',15371.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1786,654,418,'field',NULL,NULL,NULL,'',NULL),(1787,654,410,'field',NULL,NULL,NULL,'',NULL),(1790,34,420,'support',15000.00,NULL,NULL,'',NULL),(1791,319,420,'support',NULL,NULL,NULL,'',NULL),(1792,441,418,'field',NULL,NULL,NULL,'',NULL),(1793,601,421,'field',NULL,NULL,NULL,'',NULL),(1794,602,421,'field',NULL,NULL,NULL,'',NULL),(1795,43,421,'support',NULL,NULL,NULL,'',NULL),(1796,43,421,'funding',22122.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(1797,600,421,'funding',27653.00,NULL,NULL,'',NULL),(1798,34,422,'support',NULL,NULL,NULL,'',NULL),(1799,319,422,'support',NULL,NULL,NULL,'',NULL),(1800,587,422,'field',NULL,NULL,NULL,'',NULL),(1801,319,422,'funding',10000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1802,272,422,'sponsor',NULL,NULL,NULL,'',NULL),(1803,603,416,'field',NULL,NULL,NULL,'',NULL),(1807,405,423,'funding',105000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1808,272,423,'sponsor',NULL,NULL,NULL,'',NULL),(1809,405,401,'funding',23000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1810,34,420,'funding',15000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1811,503,425,'support',NULL,NULL,NULL,'',NULL),(1812,606,425,'field',NULL,NULL,NULL,'',NULL),(1813,605,425,'field',NULL,NULL,NULL,'',NULL),(1814,607,426,'field',NULL,NULL,NULL,'',NULL),(1815,503,426,'support',NULL,NULL,NULL,'',NULL),(1816,272,414,'sponsor',NULL,NULL,NULL,'',NULL),(1817,95,427,'support',NULL,NULL,NULL,'',NULL),(1818,43,427,'funding',600000.00,'','','',NULL),(1819,94,427,'field',NULL,NULL,NULL,'',NULL),(1820,608,427,'funding',400000.00,NULL,NULL,'',NULL),(1821,444,427,'sponsor',NULL,NULL,NULL,'',NULL),(1822,609,428,'field',NULL,NULL,NULL,'',NULL),(1823,503,428,'support',NULL,NULL,NULL,'',NULL),(1824,60,163,'funding',11656.00,NULL,NULL,'',NULL),(1828,405,430,'funding',104500.00,NULL,NULL,'',NULL),(1829,584,430,'field',NULL,NULL,NULL,'',NULL),(1830,34,430,'support',NULL,NULL,NULL,'',NULL),(1832,538,431,'field',NULL,NULL,NULL,'',NULL),(1833,540,431,'field',NULL,NULL,NULL,'',NULL),(3929,969,773,'sponsor',NULL,'','','',NULL),(1835,539,431,'support',NULL,'','','',NULL),(3953,846,431,'field',NULL,'','','',NULL),(1877,227,121,'sponsor',NULL,NULL,NULL,'',NULL),(1838,272,432,'sponsor',55369.00,NULL,NULL,'',NULL),(1839,328,432,'funding',8140.24,NULL,NULL,'',NULL),(1840,615,432,'field',NULL,NULL,NULL,'',NULL),(1841,616,432,'field',NULL,NULL,NULL,'',NULL),(1842,617,432,'field',NULL,NULL,NULL,'',NULL),(1843,405,432,'funding',55366.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1844,405,432,'support',NULL,NULL,NULL,'',NULL),(1845,34,432,'support',NULL,NULL,NULL,'',NULL),(1846,34,433,'support',NULL,NULL,NULL,'',NULL),(1847,272,433,'sponsor',NULL,NULL,NULL,'',NULL),(1848,34,433,'funding',12604.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1868,34,436,'support',NULL,NULL,NULL,'',NULL),(1851,327,433,'field',NULL,NULL,NULL,'',NULL),(1852,34,434,'support',NULL,NULL,NULL,'',NULL),(1853,272,434,'sponsor',NULL,NULL,NULL,'',NULL),(1854,405,434,'funding',91000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1855,405,434,'support',NULL,NULL,NULL,'',NULL),(1856,619,434,'funding',9043.00,NULL,NULL,'',NULL),(1857,619,434,'field',NULL,NULL,NULL,'',NULL),(1858,34,435,'support',NULL,NULL,NULL,'',NULL),(1859,272,435,'sponsor',NULL,NULL,NULL,'',NULL),(1860,34,435,'funding',22451.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1862,618,435,'funding',2744.00,NULL,NULL,'',NULL),(1863,369,435,'field',NULL,NULL,NULL,'',NULL),(1864,618,435,'field',NULL,NULL,NULL,'',NULL),(1944,95,451,'support',NULL,NULL,NULL,'',NULL),(1866,494,277,'funding',1600.00,'','','',NULL),(1867,494,300,'funding',1600.00,'','','',NULL),(1869,272,436,'sponsor',NULL,NULL,NULL,'',NULL),(1870,405,436,'support',NULL,NULL,NULL,'',NULL),(1871,405,436,'funding',48809.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1872,612,436,'field',NULL,NULL,NULL,'',NULL),(1873,621,436,'funding',17948.00,NULL,NULL,'',NULL),(1874,334,270,'funding',100.00,NULL,NULL,'',NULL),(1878,625,437,'funding',29546.00,NULL,NULL,'',NULL),(1879,275,437,'sponsor',NULL,NULL,NULL,'',NULL),(1880,625,437,'field',NULL,NULL,NULL,'',NULL),(1881,405,438,'support',NULL,NULL,NULL,'',NULL),(1882,34,438,'support',NULL,NULL,NULL,'',NULL),(1883,272,438,'sponsor',NULL,NULL,NULL,'',NULL),(1884,626,438,'field',NULL,NULL,NULL,'',NULL),(1885,405,438,'funding',82858.33,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1887,318,438,'funding',60369.81,NULL,NULL,'',NULL),(1888,275,439,'sponsor',NULL,NULL,NULL,'',NULL),(1889,35,439,'support',NULL,NULL,NULL,'',NULL),(1890,35,439,'funding',10271.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1891,474,439,'support',NULL,NULL,NULL,'',NULL),(1892,474,439,'funding',10271.00,NULL,NULL,'',NULL),(1893,559,439,'field',NULL,NULL,NULL,'',NULL),(1894,275,440,'sponsor',NULL,NULL,NULL,'',NULL),(1895,35,440,'support',NULL,NULL,NULL,'',NULL),(1896,628,440,'field',NULL,NULL,NULL,'',NULL),(1897,35,440,'funding',14232.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1898,275,441,'sponsor',NULL,NULL,NULL,'',NULL),(1899,35,441,'support',NULL,NULL,NULL,'',NULL),(1900,35,441,'funding',31461.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1901,573,441,'field',NULL,NULL,NULL,'',NULL),(1902,275,442,'sponsor',NULL,NULL,NULL,'',NULL),(1903,35,442,'support',NULL,NULL,NULL,'',NULL),(1904,35,442,'funding',18753.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1905,629,442,'field',NULL,NULL,NULL,'',NULL),(1906,275,443,'sponsor',NULL,NULL,NULL,'',NULL),(1907,35,443,'support',NULL,NULL,NULL,'',NULL),(1908,35,443,'funding',20317.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1909,630,443,'field',NULL,NULL,NULL,'',NULL),(1910,275,444,'sponsor',NULL,NULL,NULL,'',NULL),(1911,35,444,'support',NULL,NULL,NULL,'',NULL),(1912,35,444,'funding',33950.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1913,631,444,'field',NULL,NULL,NULL,'',NULL),(1914,275,445,'sponsor',NULL,NULL,NULL,'',NULL),(1915,35,445,'support',NULL,NULL,NULL,'',NULL),(1916,35,445,'funding',87192.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1917,632,445,'field',NULL,NULL,NULL,'',NULL),(1918,631,445,'field',NULL,NULL,NULL,'',NULL),(1919,275,446,'sponsor',NULL,NULL,NULL,'',NULL),(1920,35,446,'support',NULL,NULL,NULL,'',NULL),(1921,35,446,'funding',20000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1922,633,446,'field',NULL,NULL,NULL,'',NULL),(1923,275,447,'sponsor',NULL,NULL,NULL,'',NULL),(1924,35,447,'support',NULL,NULL,NULL,'',NULL),(1925,35,447,'funding',33624.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1926,634,447,'field',NULL,NULL,NULL,'',NULL),(1927,272,448,'sponsor',NULL,NULL,NULL,'',NULL),(1928,34,448,'support',NULL,NULL,NULL,'',NULL),(1929,319,448,'funding',23960.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1930,636,448,'field',NULL,NULL,NULL,'',NULL),(1931,34,448,'funding',21980.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1932,319,448,'support',NULL,NULL,NULL,'',NULL),(1933,635,449,'field',NULL,NULL,NULL,'',NULL),(1934,272,449,'sponsor',NULL,NULL,NULL,'',NULL),(1935,319,449,'funding',24000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1936,34,449,'funding',22000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(1937,635,449,'funding',37085.00,NULL,NULL,'',NULL),(1938,34,449,'support',NULL,NULL,NULL,'',NULL),(1939,319,449,'support',NULL,NULL,NULL,'',NULL),(1940,34,450,'support',NULL,NULL,NULL,'',NULL),(1941,272,450,'sponsor',NULL,NULL,NULL,'',NULL),(1942,669,450,'field',NULL,NULL,NULL,'',NULL),(1945,95,451,'funding',1323000.00,NULL,NULL,'',NULL),(1946,638,451,'field',NULL,NULL,NULL,'',NULL),(1947,43,452,'funding',21937.00,NULL,NULL,'',NULL),(1948,43,452,'support',NULL,NULL,NULL,'',NULL),(1949,639,452,'funding',24422.00,NULL,NULL,'',NULL),(1950,639,452,'field',NULL,NULL,NULL,'',NULL),(1951,168,338,'funding',38719.00,'','','',NULL),(3479,273,704,'support',NULL,'','104835','',NULL),(1953,641,453,'support',NULL,NULL,NULL,'',NULL),(1954,640,453,'field',NULL,NULL,NULL,'',NULL),(1955,42,454,'support',NULL,NULL,NULL,'',NULL),(1956,106,455,'support',NULL,NULL,NULL,'',NULL),(1957,106,455,'funding',41420.00,NULL,NULL,'',NULL),(3351,42,684,'support',NULL,'','','',NULL),(1959,643,455,'field',NULL,NULL,NULL,'',NULL),(1960,275,456,'sponsor',NULL,NULL,NULL,'',NULL),(1961,8,456,'support',NULL,NULL,NULL,'',NULL),(1962,8,456,'funding',24027.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1963,405,456,'support',NULL,NULL,NULL,'',NULL),(1964,405,456,'funding',3771.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1965,523,456,'field',NULL,NULL,NULL,'',NULL),(1966,353,63,'funding',780.00,NULL,NULL,'',NULL),(1967,34,385,'support',NULL,NULL,NULL,'',NULL),(1968,91,458,'support',NULL,NULL,NULL,'',NULL),(1970,275,459,'sponsor',NULL,NULL,NULL,'',NULL),(1971,8,459,'support',NULL,NULL,NULL,'',NULL),(1972,405,459,'support',NULL,NULL,NULL,'',NULL),(1973,8,459,'funding',30456.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1974,405,459,'funding',7293.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1975,521,459,'field',NULL,NULL,NULL,'',NULL),(1976,95,386,'support',NULL,NULL,NULL,'',NULL),(1977,43,457,'support',NULL,NULL,NULL,'',NULL),(1978,644,457,'funding',25000.00,NULL,NULL,'',NULL),(1979,645,356,'field',NULL,NULL,NULL,'',NULL),(1980,168,458,'funding',2193.00,NULL,NULL,'',NULL),(1982,623,460,'field',NULL,NULL,NULL,'',NULL),(1983,360,460,'support',NULL,'','','',NULL),(1984,682,460,'funding',10000.00,NULL,NULL,'',NULL),(2129,34,485,'support',NULL,NULL,NULL,'',NULL),(1986,148,461,'field',NULL,NULL,NULL,'',NULL),(1987,34,461,'support',NULL,NULL,NULL,'',NULL),(1988,319,461,'support',NULL,NULL,NULL,'',NULL),(1989,8,462,'funding',583332.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1990,405,462,'funding',21000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(1991,275,462,'sponsor',NULL,NULL,NULL,'',NULL),(1992,8,462,'support',NULL,NULL,NULL,'',NULL),(1993,405,462,'support',NULL,NULL,NULL,'',NULL),(1994,556,462,'field',NULL,NULL,NULL,'',NULL),(1995,27,462,'field',NULL,NULL,NULL,'',NULL),(1996,523,462,'field',NULL,NULL,NULL,'',NULL),(1997,520,462,'field',NULL,NULL,NULL,'',NULL),(1998,521,462,'field',NULL,NULL,NULL,'',NULL),(1999,654,313,'field',NULL,NULL,NULL,'',NULL),(2000,43,463,'funding',17866.00,NULL,NULL,'',NULL),(2001,646,463,'field',NULL,NULL,NULL,'',NULL),(2003,405,464,'funding',21309.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2004,730,464,'field',NULL,NULL,NULL,'',NULL),(2011,506,465,'support',NULL,NULL,NULL,'',NULL),(2007,13,464,'support',NULL,NULL,NULL,'',NULL),(2008,405,464,'support',NULL,NULL,NULL,'',NULL),(2009,275,464,'sponsor',NULL,NULL,NULL,'',NULL),(2319,428,548,'funding',750000.00,NULL,NULL,'',NULL),(2012,506,465,'funding',4000.00,NULL,NULL,'',NULL),(2013,360,465,'support',NULL,'','','',NULL),(2015,647,464,'funding',5500.00,NULL,NULL,'',NULL),(2016,53,63,'funding',2832.00,NULL,NULL,'',NULL),(2019,53,461,'funding',2613.70,'','','',NULL),(2018,53,453,'funding',2613.70,'','','',NULL),(2020,34,466,'support',NULL,NULL,NULL,'',NULL),(2021,53,466,'funding',2613.70,'','','',NULL),(2022,321,466,'field',NULL,NULL,NULL,'',NULL),(2061,405,430,'support',NULL,NULL,NULL,'',NULL),(2062,476,454,'field',NULL,NULL,NULL,'',NULL),(2063,477,454,'field',NULL,NULL,NULL,'',NULL),(2064,478,454,'field',NULL,NULL,NULL,'',NULL),(2065,480,454,'field',NULL,NULL,NULL,'',NULL),(2066,479,454,'field',NULL,NULL,NULL,'',NULL),(2067,20,454,'field',NULL,NULL,NULL,'',NULL),(2060,43,463,'support',NULL,NULL,NULL,'',NULL),(2057,34,472,'support',NULL,NULL,NULL,'',NULL),(2038,651,467,'field',NULL,NULL,NULL,'',NULL),(2039,43,467,'support',NULL,NULL,NULL,'',NULL),(2052,358,458,'funding',750.00,NULL,NULL,'',NULL),(2041,557,468,'field',NULL,NULL,NULL,'',NULL),(2042,275,468,'sponsor',NULL,NULL,NULL,'',NULL),(2043,405,468,'support',NULL,NULL,NULL,'',NULL),(2045,8,469,'support',NULL,NULL,NULL,'',NULL),(2046,275,469,'sponsor',NULL,NULL,NULL,'',NULL),(2047,439,469,'field',NULL,NULL,NULL,'',NULL),(2048,8,469,'funding',56459.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2049,275,471,'sponsor',NULL,NULL,NULL,'',NULL),(2050,652,471,'field',NULL,NULL,NULL,'',NULL),(2051,652,471,'funding',52066.66,NULL,NULL,'',NULL),(2068,481,454,'field',NULL,NULL,NULL,'',NULL),(2069,19,454,'field',NULL,NULL,NULL,'',NULL),(2070,662,466,'field',NULL,NULL,NULL,'',NULL),(2071,275,470,'sponsor',NULL,NULL,NULL,'',NULL),(2072,661,470,'field',NULL,NULL,NULL,'',NULL),(2073,661,470,'funding',1700.00,NULL,NULL,'',NULL),(2074,663,473,'field',NULL,NULL,NULL,'',NULL),(2075,664,473,'field',NULL,NULL,NULL,'',NULL),(2159,663,473,'funding',7000.00,NULL,NULL,'',NULL),(2077,653,326,'funding',1500.00,NULL,NULL,'',NULL),(2078,275,474,'sponsor',NULL,NULL,NULL,'',NULL),(2079,8,474,'support',NULL,NULL,NULL,'',NULL),(2080,480,474,'field',NULL,NULL,NULL,'',NULL),(2081,8,474,'funding',272997.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2082,115,474,'funding',150000.00,NULL,NULL,'',NULL),(2083,168,474,'funding',75000.00,NULL,NULL,'',NULL),(2084,275,475,'sponsor',NULL,NULL,NULL,'',NULL),(2085,479,475,'field',NULL,NULL,NULL,'',NULL),(2086,8,475,'support',NULL,NULL,NULL,'',NULL),(2087,8,475,'funding',111591.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2088,275,476,'sponsor',NULL,NULL,NULL,'',NULL),(2089,8,476,'support',NULL,NULL,NULL,'',NULL),(2090,476,476,'field',NULL,NULL,NULL,'',NULL),(2091,477,476,'field',NULL,NULL,NULL,'',NULL),(2092,478,476,'field',NULL,NULL,NULL,'',NULL),(2093,8,476,'funding',588246.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2094,275,477,'sponsor',NULL,NULL,NULL,'',NULL),(2095,8,477,'support',NULL,NULL,NULL,'',NULL),(2096,481,477,'field',NULL,NULL,NULL,'',NULL),(2097,8,477,'funding',230717.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2098,8,222,'funding',19203.00,NULL,NULL,'',NULL),(2099,272,212,'sponsor',NULL,NULL,NULL,'',NULL),(2100,525,478,'funding',124868.00,NULL,NULL,'',NULL),(2101,668,478,'field',NULL,NULL,NULL,'',NULL),(2102,525,478,'support',NULL,NULL,NULL,'',NULL),(2103,43,457,'funding',20000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2104,670,479,'field',NULL,NULL,NULL,'',NULL),(2105,670,479,'funding',22035.00,NULL,NULL,'',NULL),(2106,275,479,'sponsor',NULL,NULL,NULL,'',NULL),(2107,666,338,'funding',1561.00,NULL,NULL,'',NULL),(2108,667,338,'funding',1561.00,NULL,NULL,'',NULL),(2109,273,480,'funding',50000.00,NULL,NULL,'',NULL),(2110,273,480,'support',NULL,'','106549','',NULL),(2111,813,480,'field',NULL,NULL,NULL,'',NULL),(2112,671,219,'field',NULL,NULL,NULL,'',NULL),(2113,332,448,'funding',54910.00,NULL,NULL,'',NULL),(2115,19,481,'field',NULL,NULL,NULL,'',NULL),(2116,20,482,'field',NULL,NULL,NULL,'',NULL),(2117,19,482,'field',NULL,NULL,NULL,'',NULL),(2118,275,482,'sponsor',NULL,NULL,NULL,'',NULL),(2119,665,482,'field',NULL,NULL,NULL,'',NULL),(2120,34,483,'support',NULL,NULL,NULL,'',NULL),(2121,319,483,'support',NULL,NULL,NULL,'',NULL),(2122,272,483,'sponsor',NULL,NULL,NULL,'',NULL),(2123,42,482,'support',NULL,NULL,NULL,'',NULL),(2124,672,484,'field',NULL,NULL,NULL,'',NULL),(2125,34,484,'support',NULL,NULL,NULL,'',NULL),(2126,34,484,'funding',87100.00,NULL,NULL,'',NULL),(2127,676,467,'funding',0.00,NULL,NULL,'',NULL),(2128,654,327,'field',NULL,NULL,NULL,'',NULL),(2166,622,460,'support',NULL,NULL,NULL,'',NULL),(2130,319,485,'support',NULL,NULL,NULL,'',NULL),(2131,298,485,'field',NULL,NULL,NULL,'',NULL),(2132,319,485,'funding',44860.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2133,272,485,'sponsor',NULL,NULL,NULL,'',NULL),(2134,675,486,'field',NULL,NULL,NULL,'',NULL),(2135,273,486,'support',NULL,'','106292','',NULL),(2136,273,486,'funding',307050.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2137,272,486,'sponsor',NULL,NULL,NULL,'',NULL),(2138,34,486,'support',NULL,NULL,NULL,'',NULL),(2139,275,487,'sponsor',NULL,NULL,NULL,'',NULL),(2140,405,487,'support',NULL,NULL,NULL,'',NULL),(2141,559,487,'field',NULL,NULL,NULL,'',NULL),(2142,558,487,'field',NULL,NULL,NULL,'',NULL),(2143,638,487,'field',NULL,NULL,NULL,'',NULL),(2144,680,487,'field',NULL,NULL,NULL,'',NULL),(2145,405,487,'funding',90000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2146,275,488,'sponsor',NULL,NULL,NULL,'',NULL),(2147,519,488,'field',NULL,NULL,NULL,'',NULL),(2148,405,488,'support',NULL,NULL,NULL,'',NULL),(2149,405,488,'funding',61000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2150,679,489,'funding',0.00,NULL,NULL,'',NULL),(2151,678,489,'field',NULL,NULL,NULL,'',NULL),(2152,681,489,'sponsor',NULL,NULL,NULL,'',NULL),(2153,405,468,'funding',136227.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2154,677,483,'field',NULL,NULL,NULL,'',NULL),(2155,319,483,'funding',80000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2156,34,483,'funding',87303.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2157,43,473,'support',NULL,NULL,NULL,'',NULL),(2158,273,473,'funding',19000.00,NULL,NULL,'',NULL),(2160,275,490,'sponsor',NULL,NULL,NULL,'',NULL),(2161,405,490,'support',NULL,NULL,NULL,'',NULL),(2162,13,490,'support',NULL,NULL,NULL,'',NULL),(2163,683,490,'field',NULL,NULL,NULL,'',NULL),(2164,405,490,'funding',90000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2165,13,490,'funding',25000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2167,506,465,'field',NULL,NULL,NULL,'',NULL),(2168,525,491,'support',NULL,NULL,NULL,'',NULL),(2169,525,491,'funding',624661.00,NULL,NULL,'',NULL),(2170,684,491,'field',NULL,NULL,NULL,'',NULL),(2171,684,491,'funding',189001.00,NULL,NULL,'',NULL),(2172,686,491,'funding',49771.00,NULL,NULL,'',NULL),(2173,685,342,'funding',320.00,'','','',NULL),(2180,689,492,'support',NULL,NULL,NULL,'',NULL),(2181,42,492,'support',NULL,NULL,NULL,'',NULL),(2182,678,492,'support',NULL,NULL,NULL,'',NULL),(2183,8,492,'support',NULL,NULL,NULL,'',NULL),(2184,168,317,'funding',483600.00,NULL,NULL,'',NULL),(2185,273,493,'support',NULL,'','105122','',NULL),(2186,273,493,'funding',779743.00,NULL,NULL,'',NULL),(2187,690,489,'support',NULL,NULL,NULL,'',NULL),(2188,691,489,'support',NULL,NULL,NULL,'',NULL),(2189,43,326,'funding',16450.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2190,444,326,'funding',10473.00,NULL,NULL,'',NULL),(2191,273,493,'field',NULL,NULL,NULL,'',NULL),(2193,692,457,'field',NULL,NULL,NULL,'',NULL),(2194,275,494,'sponsor',NULL,NULL,NULL,'',NULL),(2195,13,494,'support',NULL,NULL,NULL,'',NULL),(2196,413,494,'field',NULL,NULL,NULL,'',NULL),(2197,15,494,'support',NULL,NULL,NULL,'',NULL),(2198,405,494,'support',NULL,NULL,NULL,'',NULL),(2199,13,494,'funding',49395.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2200,405,494,'funding',29605.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2201,275,495,'sponsor',NULL,NULL,NULL,'',NULL),(2202,13,495,'support',NULL,NULL,NULL,'',NULL),(2203,20,495,'field',NULL,NULL,NULL,'',NULL),(2204,665,495,'field',NULL,NULL,NULL,'',NULL),(2205,19,495,'field',NULL,NULL,NULL,'',NULL),(2206,13,495,'funding',226893.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2208,273,496,'support',NULL,'','104619','',NULL),(2209,273,496,'funding',717646.00,NULL,NULL,'',NULL),(2210,693,496,'field',NULL,NULL,NULL,'',NULL),(2211,693,496,'funding',172148.00,NULL,NULL,'',NULL),(2212,275,497,'sponsor',NULL,NULL,NULL,'',NULL),(2213,405,497,'support',NULL,NULL,NULL,'',NULL),(2214,405,497,'funding',16000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2215,428,498,'funding',70000.00,NULL,NULL,'',NULL),(2216,272,385,'sponsor',NULL,NULL,NULL,'',NULL),(2217,294,499,'field',NULL,NULL,NULL,'',NULL),(2352,709,557,'funding',35000000.00,NULL,NULL,'',NULL),(2219,294,500,'field',NULL,NULL,NULL,'',NULL),(2220,273,500,'funding',21242.32,'','','',NULL),(2221,294,501,'field',NULL,NULL,NULL,'',NULL),(2222,294,502,'field',NULL,NULL,NULL,'',NULL),(2223,814,503,'field',NULL,NULL,NULL,'',NULL),(2224,294,504,'field',NULL,NULL,NULL,'',NULL),(2225,294,505,'field',NULL,NULL,NULL,'',NULL),(2226,42,505,'field',NULL,NULL,NULL,'',NULL),(2227,294,506,'field',NULL,NULL,NULL,'',NULL),(2228,294,507,'field',NULL,NULL,NULL,'',NULL),(2229,294,508,'field',NULL,NULL,NULL,'',NULL),(2230,781,508,'field',NULL,NULL,NULL,'',NULL),(2231,294,509,'field',NULL,NULL,NULL,'',NULL),(2337,294,553,'field',NULL,NULL,NULL,'',NULL),(2233,294,510,'field',NULL,NULL,NULL,'',NULL),(2234,273,510,'funding',NULL,NULL,NULL,'',NULL),(2235,294,511,'field',NULL,NULL,NULL,'',NULL),(2236,294,512,'field',NULL,NULL,NULL,'',NULL),(2237,294,513,'field',NULL,NULL,NULL,'',NULL),(2238,294,514,'field',NULL,NULL,NULL,'',NULL),(2239,294,515,'field',NULL,NULL,NULL,'',NULL),(2240,294,516,'field',NULL,NULL,NULL,'',NULL),(2241,294,517,'field',NULL,NULL,NULL,'',NULL),(2242,294,518,'field',NULL,NULL,NULL,'',NULL),(2243,294,519,'field',NULL,NULL,NULL,'',NULL),(2244,294,520,'field',NULL,NULL,NULL,'',NULL),(2245,294,521,'field',NULL,NULL,NULL,'',NULL),(2246,681,489,'funding',25.00,NULL,NULL,'',NULL),(2247,52,522,'funding',5000.00,NULL,NULL,'',NULL),(2248,124,522,'field',NULL,NULL,NULL,'',NULL),(2249,123,522,'support',NULL,NULL,NULL,'',NULL),(2250,124,523,'field',NULL,NULL,NULL,'',NULL),(2251,123,523,'support',NULL,NULL,NULL,'',NULL),(2255,124,524,'field',NULL,NULL,NULL,'',NULL),(2253,52,523,'funding',5000.00,NULL,NULL,'',NULL),(2256,123,524,'support',NULL,NULL,NULL,'',NULL),(2257,52,524,'funding',25000.00,NULL,NULL,'',NULL),(2258,720,525,'field',NULL,NULL,NULL,'',NULL),(2259,695,526,'field',NULL,NULL,NULL,'',NULL),(2260,272,526,'sponsor',NULL,NULL,NULL,'',NULL),(2261,34,526,'support',NULL,NULL,NULL,'',NULL),(2262,319,526,'support',NULL,NULL,NULL,'',NULL),(2263,319,526,'funding',57737.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2264,695,526,'funding',900.00,NULL,NULL,'',NULL),(2265,319,472,'funding',65930.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2266,42,527,'support',NULL,NULL,NULL,'',NULL),(2267,136,527,'funding',NULL,NULL,NULL,'',NULL),(2268,428,528,'funding',950500.00,NULL,NULL,'',NULL),(2269,694,497,'field',NULL,NULL,NULL,'',NULL),(2270,275,529,'sponsor',NULL,NULL,NULL,'',NULL),(2271,531,529,'field',NULL,NULL,NULL,'',NULL),(2272,405,529,'funding',36000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2273,405,529,'support',NULL,NULL,NULL,'',NULL),(2312,34,546,'support',NULL,NULL,NULL,'',NULL),(2311,710,546,'field',NULL,NULL,NULL,'',NULL),(2276,294,530,'field',NULL,NULL,NULL,'',NULL),(2277,294,531,'field',NULL,NULL,NULL,'',NULL),(2278,294,532,'field',NULL,NULL,NULL,'',NULL),(2279,275,533,'sponsor',NULL,NULL,NULL,'',NULL),(2280,614,533,'field',NULL,'','','',NULL),(2281,275,534,'sponsor',NULL,NULL,NULL,'',NULL),(2282,649,534,'field',NULL,NULL,NULL,'',NULL),(2283,294,535,'field',NULL,NULL,NULL,'',NULL),(2306,272,314,'sponsor',NULL,NULL,NULL,'',NULL),(4232,448,314,'field',NULL,'','','',NULL),(2286,294,536,'field',NULL,NULL,NULL,'',NULL),(2287,809,536,'funding',5271.68,NULL,NULL,'',NULL),(2288,294,537,'field',NULL,NULL,NULL,'',NULL),(2289,696,498,'funding',720000.00,NULL,NULL,'',NULL),(2290,294,538,'field',NULL,NULL,NULL,'',NULL),(2291,696,498,'field',NULL,NULL,NULL,'',NULL),(2292,294,539,'field',NULL,NULL,NULL,'',NULL),(2293,294,540,'field',NULL,NULL,NULL,'',NULL),(2294,294,541,'field',NULL,NULL,NULL,'',NULL),(2295,294,542,'field',NULL,NULL,NULL,'',NULL),(2296,697,543,'funding',0.00,NULL,NULL,'',NULL),(2299,699,543,'funding',0.00,NULL,NULL,'',NULL),(2298,700,543,'field',NULL,NULL,NULL,'',NULL),(2300,275,544,'sponsor',NULL,NULL,NULL,'',NULL),(2301,655,544,'field',NULL,NULL,NULL,'',NULL),(2302,405,544,'support',NULL,NULL,NULL,'',NULL),(2303,405,544,'funding',18950.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2304,577,544,'field',NULL,NULL,NULL,'',NULL),(2307,275,545,'sponsor',NULL,NULL,NULL,'',NULL),(2308,153,545,'field',NULL,NULL,NULL,'',NULL),(2309,35,545,'support',NULL,NULL,NULL,'',NULL),(2310,35,545,'funding',84816.93,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2313,319,546,'support',NULL,NULL,NULL,'',NULL),(2314,319,546,'funding',32000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2315,272,546,'sponsor',NULL,NULL,NULL,'',NULL),(2316,428,547,'funding',2740000.00,NULL,NULL,'',NULL),(2317,428,547,'field',NULL,NULL,NULL,'',NULL),(2318,405,534,'funding',94205.00,'NL-1-PPR-22168	','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2320,428,548,'support',NULL,NULL,NULL,'',NULL),(2338,294,554,'field',NULL,NULL,NULL,'',NULL),(2339,275,555,'sponsor',NULL,NULL,NULL,'',NULL),(2340,8,555,'support',NULL,NULL,NULL,'',NULL),(2341,529,555,'field',NULL,NULL,NULL,'',NULL),(2342,8,555,'funding',150000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2343,529,555,'funding',15125.00,NULL,NULL,'',NULL),(2344,43,556,'support',NULL,NULL,NULL,'',NULL),(2345,471,556,'field',NULL,NULL,NULL,'',NULL),(2346,472,556,'field',NULL,NULL,NULL,'',NULL),(2347,687,556,'field',NULL,NULL,NULL,'',NULL),(2348,445,556,'field',NULL,NULL,NULL,'',NULL),(2349,445,556,'funding',6000.00,NULL,NULL,'',NULL),(2666,273,584,'support',NULL,'','105732','',NULL),(2351,411,504,'field',NULL,NULL,NULL,'',NULL),(2353,702,557,'support',NULL,NULL,NULL,'',NULL),(2354,705,557,'support',NULL,NULL,NULL,'',NULL),(2355,703,557,'support',NULL,NULL,NULL,'',NULL),(2356,704,557,'support',NULL,NULL,NULL,'',NULL),(2357,706,557,'support',NULL,NULL,NULL,'',NULL),(2358,707,557,'support',NULL,NULL,NULL,'',NULL),(2359,708,557,'support',NULL,NULL,NULL,'',NULL),(2360,701,557,'support',NULL,NULL,NULL,'',NULL),(2370,707,557,'funding',1462579.00,NULL,NULL,'',NULL),(2363,702,557,'funding',1462579.00,NULL,NULL,'',NULL),(2364,705,557,'funding',1462579.00,NULL,NULL,'',NULL),(2365,706,557,'funding',1462579.00,NULL,NULL,'',NULL),(2366,704,557,'funding',1462579.00,NULL,NULL,'',NULL),(2367,708,557,'funding',1462579.00,NULL,NULL,'',NULL),(2368,701,557,'funding',1462579.00,NULL,NULL,'',NULL),(2369,703,557,'funding',1462581.00,NULL,NULL,'',NULL),(2371,275,558,'sponsor',NULL,NULL,NULL,'',NULL),(2372,565,558,'field',NULL,NULL,NULL,'',NULL),(2373,405,558,'support',NULL,NULL,NULL,'',NULL),(2374,405,558,'funding',56058.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2375,275,559,'sponsor',NULL,NULL,NULL,'',NULL),(2376,412,559,'field',NULL,NULL,NULL,'',NULL),(2377,405,559,'support',NULL,NULL,NULL,'',NULL),(2378,8,559,'support',NULL,NULL,NULL,'',NULL),(2379,405,559,'funding',25000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2380,8,559,'funding',10000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2459,43,560,'funding',10341.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2382,43,560,'support',NULL,NULL,NULL,'',NULL),(2458,8,560,'funding',5000.00,NULL,NULL,'',NULL),(2460,741,560,'field',NULL,NULL,NULL,'',NULL),(2437,734,574,'funding',146371.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(2387,294,561,'field',NULL,NULL,NULL,'',NULL),(2388,294,562,'field',NULL,NULL,NULL,'',NULL),(2389,42,504,'field',NULL,NULL,NULL,'',NULL),(2390,679,489,'funding',81975.00,NULL,NULL,'',NULL),(2391,294,563,'field',NULL,NULL,NULL,'',NULL),(2392,294,564,'field',NULL,NULL,NULL,'',NULL),(2393,294,565,'field',NULL,NULL,NULL,'',NULL),(2394,725,548,'field',NULL,NULL,NULL,'',NULL),(2395,428,566,'funding',776800.00,NULL,NULL,'',NULL),(2396,833,566,'funding',NULL,'','','',NULL),(2842,744,616,'funding',1000.00,'','','',NULL),(2398,273,567,'support',NULL,'','101208','',NULL),(2399,273,567,'funding',350061.00,NULL,NULL,'',NULL),(2400,555,567,'field',NULL,NULL,NULL,'',NULL),(2401,319,450,'support',NULL,NULL,NULL,'',NULL),(2402,319,450,'funding',62012.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2403,715,525,'field',NULL,NULL,NULL,'',NULL),(2404,428,525,'support',3840449.82,NULL,NULL,'',NULL),(2405,728,525,'funding',3840449.82,NULL,NULL,'',NULL),(2406,721,525,'field',3840449.82,NULL,NULL,'',NULL),(2407,718,525,'field',NULL,NULL,NULL,'',NULL),(2408,717,525,'field',NULL,NULL,NULL,'',NULL),(2409,716,525,'field',NULL,NULL,NULL,'',NULL),(2410,719,525,'field',NULL,NULL,NULL,'',NULL),(4374,113,326,'sponsor',NULL,'','','',NULL),(4375,113,315,'sponsor',NULL,'','','',NULL),(2413,724,548,'field',NULL,NULL,NULL,'',NULL),(2419,723,548,'field',NULL,NULL,NULL,'',NULL),(2415,722,548,'field',NULL,NULL,NULL,'',NULL),(2416,294,569,'field',NULL,NULL,NULL,'',NULL),(2421,366,571,'support',NULL,NULL,NULL,'',NULL),(2422,732,571,'field',NULL,NULL,NULL,'',NULL),(2423,733,571,'field',NULL,NULL,NULL,'',NULL),(2424,366,571,'funding',3150.00,NULL,NULL,'',NULL),(2425,381,571,'funding',3850.00,NULL,NULL,'',NULL),(2426,43,571,'funding',5500.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2427,275,572,'sponsor',NULL,NULL,NULL,'',NULL),(2428,414,572,'field',NULL,NULL,NULL,'',NULL),(2429,530,572,'field',NULL,NULL,NULL,'',NULL),(2430,35,572,'support',NULL,NULL,NULL,'',NULL),(2431,35,572,'funding',16500.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(2432,428,573,'support',300000.00,NULL,NULL,'',NULL),(2433,428,573,'funding',300000.00,NULL,NULL,'',NULL),(2434,740,573,'field',NULL,NULL,NULL,'',NULL),(2438,734,575,'sponsor',NULL,NULL,NULL,'',NULL),(2439,734,575,'funding',146371.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(2440,689,574,'support',NULL,NULL,NULL,'',NULL),(2441,678,574,'support',NULL,NULL,NULL,'',NULL),(2442,641,574,'support',NULL,NULL,NULL,'',NULL),(2443,8,574,'support',NULL,NULL,NULL,'',NULL),(2444,678,575,'support',NULL,NULL,NULL,'',NULL),(2445,641,575,'support',NULL,NULL,NULL,'',NULL),(2446,689,575,'support',NULL,NULL,NULL,'',NULL),(2447,8,575,'support',NULL,NULL,NULL,'',NULL),(2448,43,575,'support',NULL,NULL,NULL,'',NULL),(2449,43,574,'support',NULL,NULL,NULL,'',NULL),(2450,737,573,'funding',22718844.00,NULL,NULL,'',NULL),(2451,739,525,'support',NULL,NULL,NULL,'',NULL),(2452,738,525,'support',NULL,NULL,NULL,'',NULL),(2453,654,357,'field',NULL,NULL,NULL,'',NULL),(2454,654,546,'field',NULL,NULL,NULL,'',NULL),(2455,654,212,'field',NULL,NULL,NULL,'',NULL),(2456,654,352,'field',NULL,NULL,NULL,'',NULL),(2457,654,304,'field',NULL,NULL,NULL,'',NULL),(2461,741,560,'funding',7946.00,NULL,NULL,'',NULL),(2841,744,616,'field',NULL,'','','',NULL),(2463,732,576,'field',NULL,NULL,NULL,'',NULL),(2464,733,576,'field',NULL,NULL,NULL,'',NULL),(2465,366,576,'funding',3150.00,NULL,NULL,'',NULL),(2466,381,576,'funding',3850.00,NULL,NULL,'',NULL),(2467,43,576,'funding',5500.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2468,366,576,'support',NULL,NULL,NULL,'',NULL),(2469,742,576,'field',NULL,NULL,NULL,'',NULL),(2470,743,571,'field',NULL,NULL,NULL,'',NULL),(2471,43,577,'support',NULL,NULL,NULL,'',NULL),(2472,745,577,'field',NULL,NULL,NULL,'',NULL),(2731,815,577,'sponsor',NULL,NULL,NULL,'',NULL),(2475,669,450,'funding',110512.00,'','','',NULL),(2476,758,450,'funding',63989.00,'','','',NULL),(2477,759,578,'field',NULL,NULL,NULL,'',NULL),(2478,106,578,'support',NULL,NULL,NULL,'',NULL),(2479,759,578,'funding',10000.00,NULL,NULL,'',NULL),(2480,96,578,'funding',22000.00,NULL,NULL,'',NULL),(4184,556,831,'field',NULL,'','','',NULL),(2482,42,574,'support',NULL,NULL,NULL,'',NULL),(2483,760,338,'funding',7863.00,NULL,NULL,'',NULL),(2484,730,393,'field',NULL,NULL,NULL,'',NULL),(2485,398,293,'funding',35000.00,NULL,NULL,'',NULL),(2486,793,293,'funding',2500.00,NULL,NULL,'',NULL),(2487,585,422,'field',NULL,NULL,NULL,'',NULL),(2488,585,420,'field',NULL,NULL,NULL,'',NULL),(2489,585,418,'field',NULL,NULL,NULL,'',NULL),(2490,585,416,'field',NULL,NULL,NULL,'',NULL),(2491,585,411,'field',NULL,NULL,NULL,'',NULL),(2492,585,410,'field',NULL,NULL,NULL,'',NULL),(2493,585,278,'field',NULL,NULL,NULL,'',NULL),(2494,640,574,'field',NULL,NULL,NULL,'',NULL),(2495,273,579,'support',NULL,'','106287','',NULL),(2496,794,579,'field',NULL,NULL,NULL,'',NULL),(2497,727,580,'field',NULL,NULL,NULL,'',NULL),(2498,273,580,'support',NULL,'','106283','',NULL),(2499,273,580,'funding',75000.00,NULL,NULL,'',NULL),(2500,273,581,'support',NULL,'','104744','',NULL),(2501,795,581,'field',NULL,NULL,NULL,'',NULL),(2502,273,581,'funding',208000.00,NULL,NULL,'',NULL),(3215,908,582,'funding',10000.00,'','','','sponsor'),(2504,796,578,'field',NULL,NULL,NULL,'',NULL),(2505,787,499,'funding',8000.00,NULL,NULL,'',NULL),(2655,747,501,'field',NULL,NULL,NULL,'',NULL),(2507,747,501,'funding',32539.00,NULL,NULL,'',NULL),(2656,747,502,'funding',52861.00,NULL,NULL,'',NULL),(2509,747,502,'field',NULL,NULL,NULL,'',NULL),(2510,780,506,'funding',40231.75,NULL,NULL,'',NULL),(2511,781,506,'funding',NULL,NULL,NULL,'',NULL),(2512,750,507,'funding',4500.00,NULL,NULL,'',NULL),(2513,751,507,'funding',27800.00,NULL,NULL,'',NULL),(2514,782,509,'funding',12214.07,NULL,NULL,'',NULL),(2657,789,508,'funding',14000.00,NULL,NULL,'',NULL),(2517,787,499,'field',NULL,NULL,NULL,'',NULL),(2518,273,500,'support',NULL,'','104592','',NULL),(2519,294,499,'support',NULL,NULL,NULL,'',NULL),(2520,294,500,'support',NULL,NULL,NULL,'',NULL),(2521,294,501,'support',NULL,NULL,NULL,'',NULL),(2522,294,502,'support',NULL,NULL,NULL,'',NULL),(2523,294,504,'support',NULL,NULL,NULL,'',NULL),(2524,294,505,'support',NULL,NULL,NULL,'',NULL),(2525,781,506,'field',NULL,NULL,NULL,'',NULL),(2526,294,506,'support',NULL,NULL,NULL,'',NULL),(2527,750,507,'field',NULL,NULL,NULL,'',NULL),(2528,294,507,'support',NULL,NULL,NULL,'',NULL),(2529,294,508,'support',NULL,NULL,NULL,'',NULL),(2530,294,509,'support',NULL,NULL,NULL,'',NULL),(2631,319,417,'funding',15000.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2532,294,510,'support',NULL,NULL,NULL,'',NULL),(2533,747,511,'field',NULL,NULL,NULL,'',NULL),(2534,294,511,'support',NULL,NULL,NULL,'',NULL),(2535,747,511,'funding',15458.99,NULL,NULL,'',NULL),(2536,294,512,'support',NULL,NULL,NULL,'',NULL),(2537,752,512,'field',NULL,NULL,NULL,'',NULL),(2538,752,512,'funding',6966.53,NULL,NULL,'',NULL),(2539,294,513,'support',NULL,NULL,NULL,'',NULL),(2540,753,513,'field',NULL,NULL,NULL,'',NULL),(2541,754,513,'field',NULL,NULL,NULL,'',NULL),(2662,807,570,'field',NULL,NULL,NULL,'',NULL),(2543,753,513,'funding',32525.50,NULL,NULL,'',NULL),(2544,294,514,'support',NULL,NULL,NULL,'',NULL),(2545,761,514,'field',NULL,NULL,NULL,'',NULL),(2547,753,515,'funding',89000.00,NULL,NULL,'',NULL),(2548,294,515,'support',NULL,NULL,NULL,'',NULL),(2661,801,520,'funding',45000.00,NULL,NULL,'',NULL),(2550,754,515,'field',NULL,NULL,NULL,'',NULL),(2552,294,516,'support',NULL,NULL,NULL,'',NULL),(2553,746,516,'funding',7500.00,NULL,NULL,'',NULL),(2554,294,517,'support',NULL,NULL,NULL,'',NULL),(2555,764,517,'field',NULL,NULL,NULL,'',NULL),(2556,764,517,'funding',5414.00,NULL,NULL,'',NULL),(2557,294,518,'support',NULL,NULL,NULL,'',NULL),(2558,765,518,'funding',32271.13,NULL,NULL,'',NULL),(2653,765,518,'field',NULL,NULL,NULL,'',NULL),(2560,294,519,'support',NULL,NULL,NULL,'',NULL),(2561,294,520,'support',NULL,NULL,NULL,'',NULL),(2562,766,520,'field',NULL,NULL,NULL,'',NULL),(2632,772,531,'field',NULL,NULL,NULL,'',NULL),(2660,806,520,'funding',45000.00,NULL,NULL,'',NULL),(2565,767,530,'funding',2272.00,NULL,NULL,'',NULL),(2566,768,530,'field',NULL,NULL,NULL,'',NULL),(2567,294,530,'support',NULL,NULL,NULL,'',NULL),(2568,767,530,'field',NULL,NULL,NULL,'',NULL),(2569,294,531,'support',NULL,NULL,NULL,'',NULL),(2570,772,531,'funding',400.00,NULL,NULL,'',NULL),(2571,294,532,'support',NULL,NULL,NULL,'',NULL),(2572,773,532,'field',NULL,NULL,NULL,'',NULL),(2573,773,532,'funding',41599.63,NULL,NULL,'',NULL),(2630,294,521,'support',NULL,NULL,NULL,'',NULL),(2575,294,535,'support',NULL,NULL,NULL,'',NULL),(2576,774,535,'field',NULL,NULL,NULL,'',NULL),(2577,774,535,'funding',1802.00,NULL,NULL,'',NULL),(2578,294,536,'support',NULL,NULL,NULL,'',NULL),(2579,746,536,'funding',20232.00,NULL,NULL,'',NULL),(2652,274,519,'funding',10000.00,NULL,NULL,'',NULL),(2581,294,536,'funding',2225.46,NULL,NULL,'',NULL),(2582,775,537,'field',NULL,NULL,NULL,'',NULL),(2583,294,537,'support',NULL,NULL,NULL,'',NULL),(2584,775,537,'funding',26319.61,NULL,NULL,'',NULL),(2585,294,538,'support',NULL,NULL,NULL,'',NULL),(2586,638,538,'field',NULL,NULL,NULL,'',NULL),(2587,638,538,'funding',12034.93,NULL,NULL,'',NULL),(2588,294,539,'support',NULL,NULL,NULL,'',NULL),(2589,777,539,'field',NULL,NULL,NULL,'',NULL),(2633,761,514,'funding',7806.57,NULL,NULL,'',NULL),(2591,777,539,'funding',2668.00,NULL,NULL,'',NULL),(2592,294,540,'support',NULL,NULL,NULL,'',NULL),(2593,785,540,'funding',3726.54,NULL,NULL,'',NULL),(2594,785,540,'field',NULL,NULL,NULL,'',NULL),(2595,294,541,'support',NULL,NULL,NULL,'',NULL),(2596,778,541,'field',NULL,NULL,NULL,'',NULL),(2597,778,541,'funding',2676.00,'','','',NULL),(2598,294,542,'support',NULL,NULL,NULL,'',NULL),(2628,294,569,'support',NULL,NULL,NULL,'',NULL),(2600,779,542,'field',NULL,NULL,NULL,'',NULL),(2601,779,542,'funding',187000.00,NULL,NULL,'',NULL),(2602,294,553,'support',NULL,NULL,NULL,'',NULL),(2603,784,553,'funding',950.00,NULL,NULL,'',NULL),(2629,245,329,'funding',3500.00,NULL,NULL,'',NULL),(2605,784,553,'field',NULL,NULL,NULL,'',NULL),(2606,294,554,'support',NULL,NULL,NULL,'',NULL),(2607,762,554,'field',NULL,NULL,NULL,'',NULL),(2608,762,554,'funding',NULL,NULL,NULL,'',NULL),(2609,746,554,'funding',4896.20,NULL,NULL,'',NULL),(2610,294,561,'support',NULL,NULL,NULL,'',NULL),(4369,294,779,'support',NULL,'','','',NULL),(2612,788,561,'field',NULL,NULL,NULL,'',NULL),(2613,788,561,'funding',5620.00,NULL,NULL,'',NULL),(2614,769,562,'field',NULL,NULL,NULL,'',NULL),(2654,763,517,'field',NULL,NULL,NULL,'',NULL),(2616,771,562,'field',NULL,NULL,NULL,'',NULL),(2617,294,562,'support',NULL,NULL,NULL,'',NULL),(2618,769,562,'funding',120695.25,NULL,NULL,'',NULL),(2619,294,563,'support',NULL,NULL,NULL,'',NULL),(2620,789,563,'funding',1000.00,NULL,NULL,'',NULL),(2621,789,563,'field',NULL,NULL,NULL,'',NULL),(2622,294,564,'funding',20626.00,NULL,NULL,'',NULL),(2623,294,565,'support',NULL,NULL,NULL,'',NULL),(3301,909,674,'field',NULL,'','','',NULL),(2625,792,570,'field',NULL,NULL,NULL,'',NULL),(2626,294,570,'funding',1500.00,NULL,NULL,'',NULL),(2627,781,202,'field',NULL,NULL,NULL,'',NULL),(2634,800,516,'field',NULL,NULL,NULL,'',NULL),(2635,273,579,'funding',153091.00,NULL,NULL,'',NULL),(2636,585,417,'field',NULL,NULL,NULL,'',NULL),(2637,804,565,'funding',7722.00,NULL,NULL,'',NULL),(2668,811,584,'field',NULL,NULL,NULL,'',NULL),(2667,273,584,'funding',63418.00,NULL,NULL,'',NULL),(2640,791,569,'funding',1000.00,NULL,NULL,'',NULL),(2669,168,584,'funding',10500.00,NULL,NULL,'',NULL),(2642,791,569,'field',NULL,NULL,NULL,'',NULL),(2643,804,565,'field',NULL,NULL,NULL,'',NULL),(2644,273,510,'field',NULL,NULL,NULL,'',NULL),(2658,454,583,'field',NULL,NULL,NULL,'',NULL),(2646,751,507,'field',NULL,NULL,NULL,'',NULL),(2647,34,583,'support',NULL,NULL,NULL,'',NULL),(2648,272,583,'sponsor',NULL,NULL,NULL,'',NULL),(2649,319,583,'support',NULL,NULL,NULL,'',NULL),(2650,454,583,'funding',12000.00,NULL,NULL,'',NULL),(2651,274,519,'field',NULL,NULL,NULL,'',NULL),(2670,319,585,'support',NULL,NULL,NULL,'',NULL),(2671,34,585,'support',NULL,NULL,NULL,'',NULL),(2672,272,585,'sponsor',NULL,NULL,NULL,'',NULL),(2673,812,585,'field',NULL,NULL,NULL,'',NULL),(2674,319,585,'funding',48594.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2675,34,586,'support',NULL,NULL,NULL,'',NULL),(2676,319,586,'support',NULL,NULL,NULL,'',NULL),(2677,272,586,'sponsor',NULL,NULL,NULL,'',NULL),(2678,757,586,'field',NULL,NULL,NULL,'',NULL),(2679,319,586,'funding',50752.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2680,273,503,'support',NULL,'','106155','',NULL),(2681,816,575,'field',NULL,NULL,NULL,'',NULL),(2682,273,503,'funding',350000.00,NULL,NULL,'',NULL),(2683,319,587,'support',NULL,NULL,NULL,'',NULL),(2684,272,587,'sponsor',NULL,NULL,NULL,'',NULL),(2685,817,587,'field',NULL,NULL,NULL,'',NULL),(2686,319,587,'funding',170848.00,'NL-1-PPR-22163','','http://search-api.openaid.nl/projectdetail_api/1272/',NULL),(2687,34,587,'support',NULL,NULL,NULL,'',NULL),(2688,821,521,'funding',110000.00,NULL,NULL,'',NULL),(2689,59,588,'field',NULL,NULL,NULL,'',NULL),(2756,168,332,'funding',11702.00,NULL,NULL,'',NULL),(2691,444,330,'funding',120875.00,NULL,NULL,'',NULL),(2692,43,330,'funding',96700.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2693,815,342,'sponsor',NULL,NULL,NULL,'',NULL),(2694,43,589,'support',NULL,NULL,NULL,'',NULL),(2695,43,589,'funding',5000.00,NULL,NULL,'',NULL),(2696,180,589,'funding',4500.00,NULL,NULL,'',NULL),(2827,840,362,'funding',0.00,'','','',NULL),(2698,815,340,'sponsor',NULL,NULL,NULL,'',NULL),(2699,815,588,'sponsor',NULL,NULL,NULL,'',NULL),(2700,43,588,'support',NULL,NULL,NULL,'',NULL),(2755,43,332,'funding',19548.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2702,819,525,'support',NULL,NULL,NULL,'',NULL),(2703,820,525,'support',NULL,NULL,NULL,'',NULL),(2736,43,597,'support',NULL,NULL,NULL,'',NULL),(3911,168,590,'funding',25000.00,'','','',NULL),(3910,825,590,'funding',39400.00,'','','',NULL),(2707,808,565,'field',NULL,NULL,NULL,'',NULL),(2708,8,591,'support',NULL,NULL,NULL,'',NULL),(2709,689,591,'support',NULL,NULL,NULL,'',NULL),(2710,204,591,'field',NULL,NULL,NULL,'',NULL),(2711,689,591,'funding',214667.00,NULL,NULL,'',NULL),(2712,8,591,'funding',70000.00,NULL,NULL,'',NULL),(2713,734,591,'sponsor',NULL,NULL,NULL,'',NULL),(2714,43,590,'support',NULL,NULL,NULL,'',NULL),(2715,822,342,'funding',0.00,NULL,NULL,'',NULL),(2716,8,592,'support',NULL,NULL,NULL,'',NULL),(2717,823,592,'field',NULL,NULL,NULL,'',NULL),(2718,824,592,'funding',NULL,NULL,NULL,'',NULL),(2719,428,593,'funding',85800.00,NULL,NULL,'',NULL),(2720,428,593,'support',NULL,NULL,NULL,'',NULL),(2721,428,593,'field',NULL,NULL,NULL,'',NULL),(2871,113,594,'sponsor',NULL,'','','',NULL),(2872,815,594,'sponsor',NULL,'','','',NULL),(2725,808,540,'field',NULL,NULL,NULL,'',NULL),(2727,43,596,'support',NULL,NULL,NULL,'',NULL),(3909,273,590,'funding',15000.00,'','','',NULL),(2729,826,590,'field',NULL,NULL,NULL,'',NULL),(2730,43,596,'funding',17389.00,NULL,NULL,'',NULL),(2732,644,595,'funding',43600.00,NULL,NULL,'',NULL),(2733,43,595,'funding',34880.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2734,692,595,'funding',78480.00,NULL,NULL,'',NULL),(2735,692,595,'field',NULL,NULL,NULL,'',NULL),(2737,815,597,'sponsor',NULL,NULL,NULL,'',NULL),(2738,168,597,'funding',5280.00,'','','',NULL),(2739,127,315,'funding',3000.00,'','','',NULL),(2740,511,597,'field',NULL,NULL,NULL,'',NULL),(2741,515,597,'field',NULL,NULL,NULL,'',NULL),(2742,512,597,'field',NULL,NULL,NULL,'',NULL),(2743,513,597,'field',NULL,NULL,NULL,'',NULL),(2744,514,597,'field',NULL,NULL,NULL,'',NULL),(2809,113,597,'sponsor',NULL,NULL,NULL,'',NULL),(2746,428,598,'support',NULL,NULL,NULL,'',NULL),(2747,828,599,'field',NULL,NULL,NULL,'',NULL),(2748,828,599,'support',NULL,NULL,NULL,'',NULL),(2749,827,598,'funding',442760.00,NULL,NULL,'',NULL),(2750,428,598,'field',NULL,NULL,NULL,'',NULL),(2753,168,342,'funding',250.00,NULL,NULL,'',NULL),(2840,360,616,'support',NULL,'','','',NULL),(2760,115,600,'field',NULL,NULL,NULL,'',NULL),(2761,43,600,'support',NULL,NULL,NULL,'',NULL),(2764,815,600,'sponsor',NULL,NULL,NULL,'',NULL),(2768,360,602,'support',NULL,'','','',NULL),(2766,679,601,'funding',0.00,'','','',NULL),(2885,850,340,'funding',5584.49,'','','',NULL),(2769,744,602,'support',NULL,NULL,NULL,'',NULL),(2770,744,602,'field',NULL,NULL,NULL,'',NULL),(2771,43,590,'funding',44350.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2772,530,603,'funding',575.00,NULL,NULL,'',NULL),(2773,162,603,'funding',7070.00,'','','',NULL),(2781,540,605,'field',NULL,NULL,NULL,'',NULL),(3311,113,340,'sponsor',NULL,'','','',NULL),(2783,539,605,'funding',3.00,'','','',NULL),(3310,113,342,'sponsor',NULL,'','','',NULL),(2785,540,606,'field',NULL,NULL,NULL,'',NULL),(2786,538,606,'field',NULL,NULL,NULL,'',NULL),(2787,539,606,'support',NULL,'','','',NULL),(2788,539,606,'funding',2.00,'','','',NULL),(3315,360,675,'sponsor',NULL,'','','',NULL),(2790,540,607,'field',NULL,NULL,NULL,'',NULL),(2791,538,607,'field',NULL,NULL,NULL,'',NULL),(2792,539,607,'funding',1.00,'','','',NULL),(2793,539,607,'support',NULL,'','','',NULL),(3316,744,675,'field',NULL,'','','',NULL),(2795,540,608,'field',NULL,NULL,NULL,'',NULL),(2796,538,608,'field',NULL,NULL,NULL,'',NULL),(2828,841,613,'support',NULL,'','','',NULL),(2798,539,608,'support',NULL,'','','',NULL),(3289,902,670,'support',NULL,'','','',NULL),(2800,832,609,'support',NULL,NULL,NULL,'',NULL),(2801,77,610,'field',NULL,NULL,NULL,'',NULL),(2802,43,610,'support',NULL,NULL,NULL,'',NULL),(2803,815,610,'sponsor',NULL,NULL,NULL,'',NULL),(2804,113,610,'sponsor',NULL,NULL,NULL,'',NULL),(2805,360,611,'support',NULL,'','','',NULL),(2806,744,611,'support',NULL,NULL,NULL,'',NULL),(2807,744,611,'funding',1500.00,NULL,NULL,'',NULL),(2808,744,611,'field',NULL,NULL,NULL,'',NULL),(3060,856,621,'support',NULL,'','','',NULL),(2884,849,340,'funding',33000.00,'','','',NULL),(2816,360,613,'support',NULL,'','','',NULL),(2873,43,594,'support',NULL,'','','',NULL),(2819,102,614,'field',NULL,'','','',NULL),(2820,43,614,'support',NULL,'','','',NULL),(2821,43,614,'funding',11690.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(2822,102,614,'funding',11655.00,'','','',NULL),(2826,815,427,'sponsor',NULL,'','','',NULL),(2829,844,613,'support',NULL,'','','',NULL),(2830,842,613,'support',NULL,'','','',NULL),(2831,843,613,'field',NULL,'','','',NULL),(3111,815,646,'sponsor',NULL,'','','',NULL),(2834,815,310,'sponsor',NULL,'','','',NULL),(2835,207,615,'funding',305556.00,'','','',NULL),(2836,43,615,'support',NULL,'','','',NULL),(2837,815,615,'sponsor',NULL,'','','',NULL),(2845,829,340,'sponsor',NULL,'','','',NULL),(2846,829,600,'sponsor',NULL,'','','',NULL),(2847,829,615,'sponsor',NULL,'','','',NULL),(2848,829,610,'sponsor',NULL,'','','',NULL),(2849,829,427,'sponsor',NULL,'','','',NULL),(2851,846,608,'field',NULL,'','','',NULL),(2852,846,607,'field',NULL,'','','',NULL),(2853,846,606,'field',NULL,'','','',NULL),(2854,846,605,'field',NULL,'','','',NULL),(2855,846,604,'field',NULL,'','','',NULL),(2856,846,382,'field',NULL,'','','',NULL),(2857,846,381,'field',NULL,'','','',NULL),(2858,846,380,'field',NULL,'','','',NULL),(2859,846,379,'field',NULL,'','','',NULL),(2860,846,378,'field',NULL,'','','',NULL),(2861,846,377,'field',NULL,'','','',NULL),(2862,846,376,'field',NULL,'','','',NULL),(2863,846,375,'field',NULL,'','','',NULL),(2864,846,374,'field',NULL,'','','',NULL),(2865,846,373,'field',NULL,'','','',NULL),(2866,846,372,'field',NULL,'','','',NULL),(2867,846,371,'field',NULL,'','','',NULL),(2868,846,370,'field',NULL,'','','',NULL),(2869,846,369,'field',NULL,'','','',NULL),(2870,846,358,'field',NULL,'','','',NULL),(2874,837,594,'field',NULL,'','','',NULL),(3095,848,603,'funding',7070.00,'','','',NULL),(2883,168,340,'funding',500.00,'','','',NULL),(2880,848,603,'field',NULL,'','','',NULL),(2881,678,601,'support',NULL,'','','',NULL),(2882,678,601,'field',NULL,'','','',NULL),(2886,498,340,'funding',3550.75,'','','',NULL),(2887,539,608,'funding',2.00,'','','',NULL),(2888,494,529,'funding',500.00,'','','',NULL),(4677,209,210,'sponsor',NULL,'','','',NULL),(2889,464,618,'funding',1825667.87,'','','',NULL),(2890,856,618,'funding',771552.92,'','','',NULL),(2891,857,618,'funding',488990.90,'','','',NULL),(2892,464,619,'funding',250367.47,'','','',NULL),(2893,856,619,'funding',112880.24,'','','',NULL),(2894,857,619,'funding',57947.23,'','','',NULL),(2895,851,618,'field',NULL,'','','',NULL),(2896,852,618,'field',NULL,'','','',NULL),(2897,853,618,'field',NULL,'','','',NULL),(2898,854,618,'field',NULL,'','','',NULL),(2899,851,619,'field',NULL,'','','',NULL),(2900,852,619,'field',NULL,'','','',NULL),(2901,853,619,'field',NULL,'','','',NULL),(2902,854,619,'field',NULL,'','','',NULL),(2903,464,620,'funding',231636.10,'','','',NULL),(2904,856,620,'funding',108108.88,'','','',NULL),(2905,857,620,'funding',53367.32,'','','',NULL),(2906,851,620,'field',NULL,'','','',NULL),(2907,852,620,'field',NULL,'','','',NULL),(2908,853,620,'field',NULL,'','','',NULL),(2909,854,620,'field',NULL,'','','',NULL),(2910,464,621,'funding',953202.02,'','','',NULL),(2911,856,621,'funding',476601.01,'','','',NULL),(2912,857,621,'funding',178587.47,'','','',NULL),(2913,851,621,'field',NULL,'','','',NULL),(2914,858,621,'field',NULL,'','','',NULL),(2915,859,621,'field',NULL,'','','',NULL),(2916,860,621,'field',NULL,'','','',NULL),(2917,464,622,'funding',273898.57,'','','',NULL),(2918,856,622,'funding',129573.92,'','','',NULL),(2919,857,622,'funding',59292.11,'','','',NULL),(2920,851,622,'field',NULL,'','','',NULL),(2921,858,622,'field',NULL,'','','',NULL),(2922,859,622,'field',NULL,'','','',NULL),(2923,860,622,'field',NULL,'','','',NULL),(2924,464,623,'funding',118492.83,'','','',NULL),(2925,856,623,'funding',80026.86,'','','',NULL),(2926,857,623,'funding',68236.41,'','','',NULL),(2927,851,623,'field',NULL,'','','',NULL),(2928,858,623,'field',NULL,'','','',NULL),(2929,859,623,'field',NULL,'','','',NULL),(2930,860,623,'field',NULL,'','','',NULL),(2931,464,624,'funding',953299.28,'','','',NULL),(2932,856,624,'funding',435308.70,'','','',NULL),(2933,857,624,'funding',223646.48,'','','',NULL),(2934,851,624,'field',NULL,'','','',NULL),(2935,861,624,'field',NULL,'','','',NULL),(2936,862,624,'field',NULL,'','','',NULL),(2937,863,624,'field',NULL,'','','',NULL),(2938,464,625,'funding',491854.97,'','','',NULL),(2939,464,626,'funding',454216.60,'','','',NULL),(2940,856,626,'funding',222963.02,'','','',NULL),(2941,857,626,'funding',91658.69,'','','',NULL),(2942,851,626,'field',NULL,'','','',NULL),(2943,861,626,'field',NULL,'','','',NULL),(2944,862,626,'field',NULL,'','','',NULL),(2945,863,626,'field',NULL,'','','',NULL),(3054,856,627,'support',NULL,'','','',NULL),(2947,464,627,'funding',365946.15,'','','',NULL),(2948,856,627,'funding',173325.46,'','','',NULL),(2949,864,627,'funding',102112.11,'','','',NULL),(2950,865,627,'field',NULL,'','','',NULL),(4419,1126,633,'field',NULL,'','','',NULL),(2952,867,627,'field',NULL,'','','',NULL),(3048,856,635,'support',NULL,'','','',NULL),(3047,856,618,'support',NULL,'','','',NULL),(2955,464,628,'funding',536854.48,'','','',NULL),(2956,856,628,'funding',288341.92,'','','',NULL),(2957,864,628,'funding',104938.84,'','','',NULL),(2958,865,628,'field',NULL,'','','',NULL),(4418,1120,633,'field',NULL,'','','',NULL),(2960,867,628,'field',NULL,'','','',NULL),(3053,856,628,'support',NULL,'','','',NULL),(3052,856,629,'support',NULL,'','','',NULL),(3051,856,631,'support',NULL,'','','',NULL),(3050,856,632,'support',NULL,'','','',NULL),(2967,856,625,'funding',255844.18,'','','',NULL),(2968,857,625,'funding',77604.67,'','','',NULL),(2969,851,625,'field',NULL,'','','',NULL),(2970,861,625,'field',NULL,'','','',NULL),(2971,862,625,'field',NULL,'','','',NULL),(2972,863,625,'field',NULL,'','','',NULL),(3049,856,633,'support',NULL,'','','',NULL),(2975,464,629,'funding',365946.15,'','','',NULL),(2976,856,629,'funding',173325.46,'','','',NULL),(2977,864,629,'funding',102112.11,'','','',NULL),(2978,865,629,'field',NULL,'','','',NULL),(4417,1116,630,'field',NULL,'','','',NULL),(2980,867,629,'field',NULL,'','','',NULL),(3046,856,634,'support',NULL,'','','',NULL),(2982,857,630,'funding',1106548.02,'','','',NULL),(2983,856,630,'funding',531528.82,'','','',NULL),(2984,864,630,'funding',260240.36,'','','',NULL),(2985,865,630,'field',NULL,'','','',NULL),(2986,870,630,'field',NULL,'','','',NULL),(2987,869,630,'field',NULL,'','','',NULL),(2988,868,630,'field',NULL,'','','',NULL),(2989,856,630,'support',NULL,'','','',NULL),(2990,464,631,'funding',872587.74,'','','',NULL),(2991,856,631,'funding',471159.77,'','','',NULL),(2992,864,631,'funding',176122.71,'','','',NULL),(2993,865,631,'field',NULL,'','','',NULL),(2994,869,631,'field',NULL,'','','',NULL),(2995,870,631,'field',NULL,'','','',NULL),(3055,856,626,'support',NULL,'','','',NULL),(2997,464,632,'funding',208104.63,'','','',NULL),(2998,856,632,'funding',106464.40,'','','',NULL),(2999,864,632,'funding',52549.60,'','','',NULL),(3000,865,632,'field',NULL,'','','',NULL),(3001,868,632,'field',NULL,'','','',NULL),(3002,869,632,'field',NULL,'','','',NULL),(3003,870,632,'field',NULL,'','','',NULL),(3056,856,625,'support',NULL,'','','',NULL),(3005,464,633,'funding',649396.74,'','','',NULL),(3006,856,633,'funding',311460.93,'','','',NULL),(3007,864,633,'funding',151502.81,'','','',NULL),(3008,865,633,'field',NULL,'','','',NULL),(3009,871,633,'field',NULL,'','','',NULL),(3010,872,633,'field',NULL,'','','',NULL),(3011,873,633,'field',NULL,'','','',NULL),(3057,856,624,'support',NULL,'','','',NULL),(3013,464,634,'funding',168750.60,'','','',NULL),(3014,856,634,'funding',93930.98,'','','',NULL),(3015,864,634,'funding',40321.59,'','','',NULL),(3016,865,634,'field',NULL,'','','',NULL),(3017,874,634,'field',NULL,'','','',NULL),(3018,872,634,'field',NULL,'','','',NULL),(3019,873,634,'field',NULL,'','','',NULL),(3058,856,623,'support',NULL,'','','',NULL),(3021,464,635,'funding',463108.38,'','','',NULL),(3022,856,635,'funding',237546.22,'','','',NULL),(3023,864,635,'funding',113573.78,'','','',NULL),(3024,865,635,'field',NULL,'','','',NULL),(3025,871,635,'field',NULL,'','','',NULL),(3026,872,635,'field',NULL,'','','',NULL),(3027,873,635,'field',NULL,'','','',NULL),(3059,856,622,'support',NULL,'','','',NULL),(3029,332,300,'funding',1800.00,'','','',NULL),(3034,319,636,'support',NULL,'','','',NULL),(3033,272,636,'sponsor',NULL,'','','',NULL),(3035,34,636,'support',NULL,'','','',NULL),(3037,305,636,'field',NULL,'','','',NULL),(3038,319,304,'funding',67726.00,'','','',NULL),(3039,428,637,'funding',70000.00,'','','',NULL),(3040,746,637,'funding',345000.00,'','','',NULL),(3041,428,637,'support',NULL,'','','',NULL),(3042,877,638,'funding',994134.00,'','','',NULL),(3043,428,639,'funding',729052.00,'','','',NULL),(3044,875,639,'funding',70200.00,'','','',NULL),(3061,856,620,'support',NULL,'','','',NULL),(3062,856,619,'support',NULL,'','','',NULL),(3063,273,617,'funding',50000.00,'','','',NULL),(3064,168,617,'funding',230000.00,'','','',NULL),(3065,847,617,'field',NULL,'','','',NULL),(3066,273,617,'support',NULL,'','105243','',NULL),(3169,43,654,'funding',29455.00,'','','',NULL),(3073,301,205,'funding',500.00,'','','',NULL),(3070,273,641,'funding',57000.00,'','','',NULL),(3071,273,641,'support',NULL,'','106302','',NULL),(3072,499,641,'field',NULL,'','','',NULL),(3074,428,642,'funding',75000.00,'','','',NULL),(3076,963,642,'funding',525000.00,'','','',NULL),(3077,428,638,'funding',363077.00,'','','',NULL),(3078,878,638,'funding',249297.00,'','','',NULL),(3079,876,638,'funding',38000.00,'','','',NULL),(3080,360,643,'support',NULL,'','','',NULL),(3081,744,643,'field',NULL,'','','',NULL),(3082,744,643,'support',NULL,'','','',NULL),(3094,43,603,'funding',18230.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(3110,678,646,'support',NULL,'','','',NULL),(3086,43,644,'support',NULL,'','','',NULL),(3109,679,646,'sponsor',0.00,'','','',NULL),(3104,8,644,'funding',0.00,'','','',NULL),(3089,113,644,'sponsor',NULL,'','','',NULL),(3090,815,644,'sponsor',NULL,'','','',NULL),(3091,559,644,'field',NULL,'','','',NULL),(3092,558,644,'field',NULL,'','','',NULL),(3098,227,298,'funding',1.00,'','','',NULL),(3100,43,645,'support',NULL,'','','',NULL),(3101,879,645,'funding',17000.00,'','','',NULL),(3102,168,645,'funding',6666.00,'','','',NULL),(3112,113,646,'sponsor',NULL,'','','',NULL),(3113,204,646,'field',NULL,'','','',NULL),(3517,815,645,'sponsor',NULL,'','','',NULL),(3115,880,646,'field',NULL,'','','',NULL),(3121,428,648,'funding',62000.00,'','','',NULL),(3119,189,647,'field',NULL,'','','',NULL),(3120,489,647,'field',NULL,'','','',NULL),(3122,833,648,'funding',1476000.00,'','','',NULL),(3124,43,647,'support',NULL,'','','',NULL),(3125,113,647,'sponsor',NULL,'','','',NULL),(3126,815,647,'sponsor',NULL,'','','',NULL),(3128,1013,649,'funding',983445.00,'','','',NULL),(3129,678,649,'funding',255060.00,'','','',NULL),(3130,851,649,'funding',100000.00,'','','',NULL),(3131,678,649,'support',NULL,'','','',NULL),(3132,204,649,'field',NULL,'','','',NULL),(3133,881,649,'support',NULL,'','','',NULL),(3519,815,668,'sponsor',NULL,'','','',NULL),(3135,881,650,'support',NULL,'','','',NULL),(3136,678,650,'field',NULL,'','','',NULL),(3137,678,650,'funding',897034.00,'','','',NULL),(3138,881,650,'funding',88000.00,'','','',NULL),(3139,882,650,'funding',2477578.00,'','','',NULL),(3140,883,650,'support',NULL,'','','',NULL),(3523,273,712,'support',NULL,'','108382','',NULL),(3142,881,651,'support',NULL,'','','',NULL),(3143,883,651,'support',NULL,'','','',NULL),(3144,678,651,'field',NULL,'','','',NULL),(3524,950,712,'sponsor',NULL,'','','',NULL),(3146,1013,652,'funding',300443.33,'','','',NULL),(3147,678,652,'funding',90066.67,'','','',NULL),(3148,881,652,'funding',7500.00,'','','',NULL),(3149,884,652,'support',NULL,'','','',NULL),(3150,689,653,'funding',NULL,'','','',NULL),(3151,735,653,'sponsor',NULL,'','','',NULL),(3152,896,653,'support',NULL,'','','',NULL),(3153,556,653,'field',NULL,'','','',NULL),(3154,42,653,'support',NULL,'','','',NULL),(3155,43,640,'support',NULL,'','','',NULL),(3156,8,640,'funding',0.00,'','','',NULL),(3157,113,640,'sponsor',NULL,'','','',NULL),(3158,444,640,'sponsor',NULL,'','','',NULL),(3159,823,640,'field',NULL,'','','',NULL),(3161,885,654,'field',NULL,'','','',NULL),(3162,43,654,'support',NULL,'','','',NULL),(3164,43,655,'support',NULL,'','','',NULL),(3165,885,655,'field',NULL,'','','',NULL),(3166,885,655,'funding',12871.00,'','','',NULL),(3167,43,655,'funding',22871.00,'','','',NULL),(3168,168,655,'funding',10000.00,'','','',NULL),(3995,1046,654,'funding',29455.00,'','','',NULL),(3177,42,657,'support',NULL,'','','',NULL),(3173,43,656,'support',NULL,'','','',NULL),(3174,43,656,'funding',20000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(3175,885,656,'funding',20000.00,'','','',NULL),(3176,885,656,'field',NULL,'','','',NULL),(3178,736,657,'sponsor',NULL,'','','',NULL),(3179,689,657,'support',NULL,'','','',NULL),(3180,678,657,'support',NULL,'','','',NULL),(3181,641,657,'support',NULL,'','','',NULL),(3182,8,657,'support',NULL,'','','',NULL),(3183,43,657,'support',NULL,'','','',NULL),(3184,678,657,'field',NULL,'','','',NULL),(3185,273,658,'support',NULL,'','107000','',NULL),(3189,360,659,'sponsor',NULL,'','','',NULL),(3190,361,659,'field',NULL,'','','',NULL),(3191,886,659,'field',NULL,'','','',NULL),(3192,361,659,'support',NULL,'','','',NULL),(3194,42,660,'support',NULL,'','','',NULL),(3195,802,660,'field',NULL,'','','',NULL),(3196,887,660,'support',NULL,'','','',NULL),(3197,888,660,'field',NULL,'','','',NULL),(3199,42,661,'support',NULL,'','','',NULL),(3200,802,661,'support',NULL,'','','',NULL),(3201,888,661,'field',NULL,'','','',NULL),(3202,887,661,'field',NULL,'','','',NULL),(3203,881,660,'support',NULL,'','','',NULL),(3204,889,661,'field',NULL,'','','',NULL),(3205,802,661,'funding',372180.33,'','','',NULL),(3206,881,661,'funding',72267.00,'','','',NULL),(3207,444,640,'funding',80000.00,'','','',NULL),(3208,43,640,'funding',80000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(3209,168,640,'funding',104000.00,'','','',NULL),(3211,890,659,'field',NULL,'','','',NULL),(3212,1032,582,'field',NULL,'','','','funding'),(3213,1051,582,'funding',10000.00,'','','',NULL),(3214,42,582,'support',NULL,'','','','sponsor'),(3216,893,433,'field',NULL,'','','',NULL),(3217,35,533,'support',NULL,'','','',NULL),(3218,405,533,'support',NULL,'','','',NULL),(3219,35,533,'funding',53304.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(3220,405,533,'funding',21258.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(3221,275,662,'sponsor',NULL,'','','',NULL),(3222,8,662,'support',NULL,'','','',NULL),(3223,8,662,'funding',90000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(3224,475,662,'funding',30000.00,'','','',NULL),(3225,405,662,'support',NULL,'','','',NULL),(3226,405,662,'funding',15000.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(3227,475,662,'support',NULL,'','','',NULL),(3228,895,662,'field',NULL,'','','',NULL),(3229,888,663,'field',NULL,'','','',NULL),(3230,887,663,'field',NULL,'','','',NULL),(3231,889,663,'field',NULL,'','','',NULL),(3232,802,663,'funding',372180.33,'','','',NULL),(3233,881,663,'funding',72267.00,'','','',NULL),(3234,42,663,'support',NULL,'','','',NULL),(3235,802,663,'support',NULL,'','','',NULL),(3236,888,664,'field',NULL,'','','',NULL),(3237,887,664,'field',NULL,'','','',NULL),(3238,889,664,'field',NULL,'','','',NULL),(3239,802,664,'funding',372180.33,'','','',NULL),(3240,881,664,'funding',72267.00,'','','',NULL),(3241,42,664,'support',NULL,'','','',NULL),(3242,802,664,'support',NULL,'','','',NULL),(3243,1013,665,'funding',300443.33,'','','',NULL),(3244,678,665,'funding',90066.67,'','','',NULL),(3245,881,665,'funding',7500.00,'','','',NULL),(3582,964,610,'funding',0.00,'','','',NULL),(3247,884,665,'support',NULL,'','','',NULL),(3248,1013,666,'funding',300443.33,'','','',NULL),(3249,678,666,'funding',90066.67,'','','',NULL),(3250,881,666,'funding',7500.00,'','','',NULL),(3252,884,666,'support',NULL,'','','',NULL),(3253,204,667,'field',NULL,'','','',NULL),(3254,1013,667,'funding',491722.50,'','','',NULL),(3255,678,667,'funding',127530.00,'','','',NULL),(3256,851,667,'funding',50000.00,'','','',NULL),(3526,951,680,'funding',0.00,'','','',NULL),(3258,678,667,'support',NULL,'','','',NULL),(3259,881,667,'support',NULL,'','','',NULL),(3288,168,297,'funding',1000.00,'','','',NULL),(3522,679,668,'funding',86500.00,'','','',NULL),(3262,678,668,'support',NULL,'','','',NULL),(3266,127,603,'funding',1000.00,'','','',NULL),(4019,1050,582,'support',NULL,'','','',NULL),(3276,428,670,'funding',2100000.00,'','','',NULL),(3275,272,466,'sponsor',NULL,'','','',NULL),(3270,275,669,'sponsor',NULL,'','','',NULL),(3271,901,669,'support',NULL,'','','',NULL),(3272,829,668,'sponsor',NULL,'','','',NULL),(3273,113,668,'sponsor',NULL,'','','',NULL),(3277,728,671,'funding',2800000.00,'','','',NULL),(3278,428,671,'support',NULL,'','','',NULL),(3284,43,672,'support',NULL,'','','',NULL),(3281,43,340,'funding',35919.00,'','','',NULL),(3285,905,672,'field',NULL,'','','',NULL),(3286,168,672,'funding',23340.00,'','','',NULL),(3287,905,672,'funding',8000.00,'','','',NULL),(3290,903,670,'field',NULL,'','','',NULL),(3291,904,670,'field',NULL,'','','',NULL),(3292,908,670,'funding',40000.00,'','','',NULL),(3317,744,675,'support',NULL,'','','',NULL),(3319,912,676,'sponsor',NULL,'','','',NULL),(3320,1012,676,'field',NULL,'','','',NULL),(3324,360,677,'support',NULL,'','','',NULL),(3325,361,677,'field',NULL,'','','',NULL),(3326,361,677,'support',NULL,'','','',NULL),(3327,428,678,'funding',50000.00,'','','',NULL),(3532,878,678,'support',NULL,'','','',NULL),(3329,886,677,'field',NULL,'','','',NULL),(3330,428,679,'funding',582392.00,'','','',NULL),(3457,273,700,'support',NULL,'','108626','',NULL),(3332,913,680,'field',NULL,'','','',NULL),(3333,43,680,'support',NULL,'','','',NULL),(3334,113,680,'sponsor',NULL,'','','',NULL),(3335,815,680,'sponsor',NULL,'','','',NULL),(3336,275,681,'sponsor',NULL,'','','',NULL),(3337,405,681,'funding',122500.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(3338,405,681,'support',NULL,'','','',NULL),(3339,568,681,'field',NULL,'','','',NULL),(3340,649,681,'field',NULL,'','','',NULL),(3341,565,681,'field',NULL,'','','',NULL),(3342,577,681,'field',NULL,'','','',NULL),(3344,168,682,'funding',1238115.00,'','','',NULL),(3345,405,682,'support',NULL,'','','',NULL),(3346,275,682,'sponsor',NULL,'','','',NULL),(3347,568,682,'field',NULL,'','','',NULL),(3348,405,682,'funding',179503.00,'NL-1-PPR-22168','','http://search-api.openaid.nl/projectdetail_api/278/',NULL),(3349,914,683,'funding',100000.00,'','','',NULL),(3350,914,683,'support',NULL,'','','',NULL),(3352,919,684,'field',NULL,'','','',NULL),(3353,920,684,'field',NULL,'','','',NULL),(3354,464,684,'funding',144459.00,'','','',NULL),(3355,856,684,'funding',194815.00,'','','',NULL),(3356,864,684,'funding',23377.00,'','','',NULL),(3363,42,686,'support',NULL,'','','',NULL),(3358,34,685,'support',NULL,'','','',NULL),(3359,319,685,'support',NULL,'','','',NULL),(3360,272,685,'sponsor',NULL,'','','',NULL),(3361,921,685,'field',NULL,'','','',NULL),(3362,319,685,'funding',44723.00,'','','',NULL),(3364,917,686,'support',NULL,'','','',NULL),(3365,464,686,'funding',458223.70,'','','',NULL),(3366,856,686,'funding',87375.84,'','','',NULL),(3367,922,686,'funding',19489.26,'','','',NULL),(3516,113,645,'sponsor',NULL,'','','',NULL),(3369,360,687,'support',NULL,'','','',NULL),(3370,916,687,'funding',6248.00,'','','',NULL),(3371,916,687,'field',NULL,'','','',NULL),(3372,915,687,'field',NULL,'','','',NULL),(3373,42,688,'support',NULL,'','','',NULL),(3374,923,688,'field',NULL,'','','',NULL),(3375,924,688,'field',NULL,'','','',NULL),(3376,925,688,'field',NULL,'','','',NULL),(3377,464,688,'funding',535489.00,'','','',NULL),(3378,856,688,'funding',88071.00,'','','',NULL),(3379,922,688,'funding',53907.00,'','','',NULL),(3380,923,689,'field',NULL,'','','',NULL),(3388,42,690,'support',NULL,'','','',NULL),(3396,42,691,'support',NULL,'','','',NULL),(3383,464,689,'funding',212452.00,'','','',NULL),(3384,856,689,'funding',74131.00,'','','',NULL),(3385,922,689,'funding',16272.00,'','','',NULL),(3386,42,689,'support',NULL,'','','',NULL),(3389,926,690,'support',NULL,'','','',NULL),(3390,927,690,'field',NULL,'','','',NULL),(3411,933,692,'field',NULL,'','','',NULL),(3392,464,690,'funding',764966.15,'','','',NULL),(3393,856,690,'funding',119334.72,'','','',NULL),(3394,922,690,'funding',33658.51,'','','',NULL),(3397,464,691,'funding',305986.62,'','','',NULL),(3398,856,691,'funding',71197.20,'','','',NULL),(3399,922,691,'funding',30797.51,'','','',NULL),(3400,917,691,'support',NULL,'','','',NULL),(3401,924,691,'support',NULL,'','','',NULL),(3402,934,691,'support',NULL,'','','',NULL),(3403,930,692,'field',NULL,'','','',NULL),(3404,931,692,'field',NULL,'','','',NULL),(3405,932,692,'field',NULL,'','','',NULL),(3406,464,692,'funding',708178.00,'','','',NULL),(3407,856,692,'funding',162555.00,'','','',NULL),(3408,922,692,'funding',96898.00,'','','',NULL),(3409,42,692,'support',NULL,'','','',NULL),(3410,42,693,'support',NULL,'','','',NULL),(3412,464,693,'funding',510022.19,'','','',NULL),(3413,856,693,'funding',82878.61,'','','',NULL),(3414,922,693,'funding',82878.61,'','','',NULL),(3415,935,693,'support',NULL,'','','',NULL),(3416,924,693,'field',NULL,'','','',NULL),(3417,42,694,'support',NULL,'','','',NULL),(3418,464,694,'funding',225281.14,'','','',NULL),(3419,856,694,'funding',42592.59,'','','',NULL),(3420,922,694,'funding',16076.89,'','','',NULL),(3421,936,694,'support',NULL,'','','',NULL),(3422,924,694,'field',NULL,'','','',NULL),(3423,925,694,'field',NULL,'','','',NULL),(3424,42,695,'support',NULL,'','','',NULL),(3425,464,695,'funding',600375.11,'','','',NULL),(3426,856,695,'funding',70129.97,'','','',NULL),(3427,922,695,'funding',19105.31,'','','',NULL),(3428,936,695,'support',NULL,'','','',NULL),(3429,464,696,'funding',676333.21,'','','',NULL),(3430,856,696,'funding',185379.60,'','','',NULL),(3431,922,696,'funding',74152.01,'','','',NULL),(3432,42,696,'support',NULL,'','','',NULL),(3433,936,696,'support',NULL,'','','',NULL),(3434,868,696,'field',NULL,'','','',NULL),(3478,464,697,'funding',431750.00,'','','',NULL),(3436,937,697,'field',NULL,'','','',NULL),(3437,641,697,'field',NULL,'','','',NULL),(3441,833,673,'funding',950358.89,'','','',NULL),(3442,273,698,'support',NULL,'','107288','',NULL),(3443,678,698,'field',NULL,'','','',NULL),(3444,851,698,'field',NULL,'','','',NULL),(3445,204,698,'field',NULL,'','','',NULL),(3446,880,698,'funding',NULL,'','','',NULL),(3521,679,646,'funding',73766.00,'','','',NULL),(3448,939,697,'support',NULL,'','','',NULL),(3449,902,673,'support',NULL,'','','',NULL),(3450,941,673,'field',NULL,'','','',NULL),(3451,940,673,'field',NULL,'','','',NULL),(3452,42,609,'sponsor',NULL,'','','',NULL),(3453,360,699,'support',NULL,'','','',NULL),(3454,938,699,'field',NULL,'','','',NULL),(3458,274,700,'field',NULL,'','','',NULL),(3459,273,700,'funding',101670.00,'','','',NULL),(3460,360,701,'support',NULL,'','','',NULL),(3461,506,701,'field',NULL,'','','',NULL),(3553,678,718,'field',NULL,'','','',NULL),(3463,555,702,'field',NULL,'','','',NULL),(3464,273,702,'funding',138188.00,'','','',NULL),(3468,506,701,'funding',10000.00,'','','',NULL),(3469,946,698,'sponsor',NULL,'','','',NULL),(3470,829,680,'sponsor',NULL,'','','',NULL),(3472,947,703,'support',NULL,'','','',NULL),(3473,947,703,'funding',7815000.00,'','','',NULL),(3480,945,704,'field',NULL,'','','',NULL),(3481,273,704,'funding',76741.00,'','','',NULL),(3482,487,209,'funding',3455.00,'','','',NULL),(3486,297,205,'funding',5779.00,'','','',NULL),(3484,43,362,'funding',13114.00,'','','',NULL),(3485,815,362,'sponsor',NULL,'','','',NULL),(3488,948,697,'field',NULL,'','','',NULL),(3489,939,705,'support',NULL,'','','',NULL),(3490,641,705,'field',NULL,'','','',NULL),(3491,937,705,'field',NULL,'','','',NULL),(3492,464,705,'funding',388500.00,'','','',NULL),(3493,939,706,'support',NULL,'','','',NULL),(3494,464,706,'funding',399250.00,'NL-1-PPR-23718 ','','http://search-api.openaid.nl/projectdetail_api/2284/',NULL),(3495,937,706,'field',NULL,'','','',NULL),(3496,641,706,'field',NULL,'','','',NULL),(3497,939,707,'support',NULL,'','','',NULL),(3498,464,707,'funding',468000.00,'','','',NULL),(3499,948,707,'field',NULL,'','','',NULL),(3500,937,707,'field',NULL,'','','',NULL),(3501,939,708,'support',NULL,'','','',NULL),(3502,464,708,'funding',233000.00,'','','',NULL),(3503,641,708,'field',NULL,'','','',NULL),(3504,948,708,'field',NULL,'','','',NULL),(3505,464,709,'funding',205000.00,'','','',NULL),(3506,939,709,'support',NULL,'','','',NULL),(3507,948,709,'field',NULL,'','','',NULL),(3508,939,710,'support',NULL,'','','',NULL),(3509,464,710,'funding',410000.00,'','','',NULL),(3510,641,710,'field',NULL,'','','',NULL),(3511,939,711,'support',NULL,'','','',NULL),(3512,641,711,'field',NULL,'','','',NULL),(3513,937,711,'field',NULL,'','','',NULL),(3514,464,711,'funding',421500.00,'NL-1-PPR-19499','','http://search-api.openaid.nl/projectdetail_api/1059/',NULL),(3584,949,722,'sponsor',NULL,'','','',NULL),(3528,273,713,'support',NULL,'','108519','',NULL),(3529,953,713,'sponsor',NULL,'','','',NULL),(3530,954,713,'field',NULL,'','','',NULL),(3531,42,683,'sponsor',NULL,'','','',NULL),(3533,428,714,'support',NULL,'','','',NULL),(3626,679,653,'support',NULL,'','','',NULL),(3535,273,715,'support',NULL,'','103273','',NULL),(3536,955,715,'sponsor',NULL,'','','',NULL),(3537,956,714,'funding',6324128.00,'','','',NULL),(3538,428,642,'support',NULL,'','','',NULL),(3542,952,716,'field',NULL,'','','',NULL),(3541,273,716,'funding',300000.00,'','','',NULL),(4176,506,808,'funding',10000.00,'','','',NULL),(3544,171,717,'funding',165600.00,'','','',NULL),(4175,506,808,'field',NULL,'','','',NULL),(3548,273,719,'funding',214370.00,'','','',NULL),(3547,273,716,'support',NULL,'','106288','',NULL),(3549,814,719,'field',NULL,'','','',NULL),(3550,316,80,'funding',0.00,'','','',NULL),(3551,316,128,'funding',0.00,'','','',NULL),(3552,958,645,'field',NULL,'','','',NULL),(3554,678,718,'funding',413634.00,'','','',NULL),(3555,881,718,'funding',223750.00,'','','',NULL),(3556,882,718,'funding',649395.00,'','','',NULL),(3557,881,718,'support',NULL,'','','',NULL),(3558,883,718,'support',NULL,'','','',NULL),(3559,42,718,'support',NULL,'','','',NULL),(3560,678,720,'field',NULL,'','','',NULL),(3561,678,720,'funding',413634.00,'','','',NULL),(3562,881,720,'funding',223750.00,'','','',NULL),(3563,882,720,'funding',649395.00,'','','',NULL),(3564,881,720,'support',NULL,'','','',NULL),(3565,42,720,'support',NULL,'','','',NULL),(3566,273,702,'support',NULL,'','107914','',NULL),(3568,678,721,'field',NULL,'','','',NULL),(3569,678,721,'funding',413634.00,'','','',NULL),(3570,881,721,'funding',223750.00,'','','',NULL),(3571,882,721,'funding',649395.00,'','','',NULL),(3572,881,721,'support',NULL,'','','',NULL),(3573,883,721,'support',NULL,'','','',NULL),(3574,42,721,'support',NULL,'','','',NULL),(3575,273,722,'support',NULL,'','108774','',NULL),(3576,957,722,'field',NULL,'','','',NULL),(3577,273,722,'funding',172500.00,'','','',NULL),(3578,273,723,'support',NULL,'','108749','',NULL),(3579,491,723,'field',NULL,'','','',NULL),(3580,273,723,'funding',333863.00,'','','',NULL),(3585,949,716,'sponsor',NULL,'','','',NULL),(3586,949,704,'sponsor',NULL,'','','',NULL),(3587,949,702,'sponsor',NULL,'','','',NULL),(3588,949,641,'sponsor',NULL,'','','',NULL),(3589,949,617,'sponsor',NULL,'','','',NULL),(3590,949,590,'sponsor',NULL,'','','',NULL),(3591,949,584,'sponsor',NULL,'','','',NULL),(3592,949,581,'sponsor',NULL,'','','',NULL),(3593,949,580,'sponsor',NULL,'','','',NULL),(3594,949,579,'sponsor',NULL,'','','',NULL),(3595,949,567,'sponsor',NULL,'','','',NULL),(3596,949,550,'sponsor',NULL,'','','',NULL),(3597,949,549,'sponsor',NULL,'','','',NULL),(3598,949,503,'sponsor',NULL,'','','',NULL),(3599,949,500,'sponsor',NULL,'','','',NULL),(3600,949,496,'sponsor',NULL,'','','',NULL),(3601,949,493,'sponsor',NULL,'','','',NULL),(3602,949,486,'sponsor',NULL,'','','',NULL),(3603,949,480,'sponsor',NULL,'','','',NULL),(3604,949,473,'sponsor',NULL,'','','',NULL),(3605,949,406,'sponsor',NULL,'','','',NULL),(3606,949,385,'sponsor',NULL,'','','',NULL),(3607,949,365,'sponsor',NULL,'','','',NULL),(3608,949,348,'sponsor',NULL,'','','',NULL),(3609,949,343,'sponsor',NULL,'','','',NULL),(3610,949,341,'sponsor',NULL,'','','',NULL),(3611,949,337,'sponsor',NULL,'','','',NULL),(3612,949,336,'sponsor',NULL,'','','',NULL),(3613,949,331,'sponsor',NULL,'','','',NULL),(3614,949,221,'sponsor',NULL,'','','',NULL),(3615,949,218,'sponsor',NULL,'','','',NULL),(3616,949,216,'sponsor',NULL,'','','',NULL),(3617,949,215,'sponsor',NULL,'','','',NULL),(3618,949,212,'sponsor',NULL,'','','',NULL),(3619,949,208,'sponsor',NULL,'','','',NULL),(3620,949,194,'sponsor',NULL,'','','',NULL),(3621,949,723,'sponsor',NULL,'','','',NULL),(3627,679,575,'support',NULL,'','','',NULL),(3623,273,724,'support',NULL,'','108182','',NULL),(3624,955,724,'sponsor',NULL,'','','',NULL),(3625,965,724,'field',NULL,'','','',NULL),(3628,679,574,'support',NULL,'','','',NULL),(3629,679,657,'support',NULL,'','','',NULL),(3630,679,591,'support',NULL,'','','',NULL),(3637,35,112,'funding',23509.00,'','','',NULL),(3632,319,725,'funding',15118.00,'','','',NULL),(3633,34,725,'support',NULL,'','','',NULL),(3634,272,725,'sponsor',NULL,'','','',NULL),(3635,319,725,'support',NULL,'','','',NULL),(3636,966,725,'field',NULL,'','','',NULL),(3651,967,275,'funding',5000.00,'','','',NULL),(3639,43,726,'support',NULL,'','','',NULL),(3640,113,726,'sponsor',NULL,'','','',NULL),(3641,815,726,'sponsor',NULL,'','','',NULL),(3642,561,726,'funding',0.00,'','','',NULL),(3643,968,726,'funding',7899.00,'','','',NULL),(3644,43,726,'funding',28800.00,'','','',NULL),(3646,43,727,'support',NULL,'','','',NULL),(3647,823,727,'field',NULL,'','','',NULL),(3648,8,727,'funding',250000.00,'','','',NULL),(3649,43,727,'funding',200000.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(3653,444,315,'funding',20149.00,'','','',NULL),(3654,405,728,'support',NULL,'','','',NULL),(3655,969,728,'sponsor',NULL,'','','',NULL),(3657,969,660,'field',NULL,'','','',NULL),(3658,1094,703,'field',NULL,'','','',NULL),(3659,1049,703,'field',NULL,'','','',NULL),(3664,971,729,'field',NULL,'','','',NULL),(3661,273,729,'support',NULL,'','108718','',NULL),(3662,961,729,'sponsor',NULL,'','','',NULL),(3663,273,729,'funding',250000.00,'','','',NULL),(3665,273,730,'support',NULL,'','108244','',NULL),(3666,961,730,'sponsor',NULL,'','','',NULL),(3667,973,730,'funding',467250.00,'','','',NULL),(3668,972,730,'field',NULL,'','','',NULL),(3669,273,731,'support',NULL,'','107590','',NULL),(3670,961,731,'sponsor',NULL,'','','',NULL),(3671,273,731,'funding',91250.00,'','','',NULL),(3672,974,731,'field',NULL,'','','',NULL),(3673,539,374,'support',NULL,'','','',NULL),(3674,539,605,'support',NULL,'','','',NULL),(3675,539,372,'funding',4.00,'','','',NULL),(3676,539,370,'funding',5.00,'','','',NULL),(3719,539,371,'funding',5.00,'','','',NULL),(3678,540,732,'field',NULL,'','','',NULL),(3679,538,732,'field',NULL,'','','',NULL),(3680,846,732,'field',NULL,'','','',NULL),(3683,540,733,'field',NULL,'','','',NULL),(3682,539,732,'support',NULL,'','','',NULL),(3684,538,733,'field',NULL,'','','',NULL),(3685,846,733,'field',NULL,'','','',NULL),(3686,539,733,'support',NULL,'','','',NULL),(3687,540,734,'field',NULL,'','','',NULL),(3688,538,734,'field',NULL,'','','',NULL),(3689,846,734,'field',NULL,'','','',NULL),(3690,539,734,'support',NULL,'','','',NULL),(3691,540,735,'field',NULL,'','','',NULL),(3692,538,735,'field',NULL,'','','',NULL),(3693,846,735,'field',NULL,'','','',NULL),(3694,539,735,'support',NULL,'','','',NULL),(3695,540,736,'field',NULL,'','','',NULL),(3696,538,736,'field',NULL,'','','',NULL),(3697,846,736,'field',NULL,'','','',NULL),(3698,539,736,'support',NULL,'','','',NULL),(3699,540,737,'field',NULL,'','','',NULL),(3700,538,737,'field',NULL,'','','',NULL),(3701,846,737,'field',NULL,'','','',NULL),(3702,539,737,'support',NULL,'','','',NULL),(3703,540,738,'field',NULL,'','','',NULL),(3704,538,738,'field',NULL,'','','',NULL),(3705,846,738,'field',NULL,'','','',NULL),(3706,539,738,'support',NULL,'','','',NULL),(3707,540,739,'field',NULL,'','','',NULL),(3708,538,739,'field',NULL,'','','',NULL),(3709,846,739,'field',NULL,'','','',NULL),(3710,539,739,'support',NULL,'','','',NULL),(3711,540,740,'field',NULL,'','','',NULL),(3712,538,740,'field',NULL,'','','',NULL),(3713,846,740,'field',NULL,'','','',NULL),(3714,539,740,'support',NULL,'','','',NULL),(3715,540,741,'field',NULL,'','','',NULL),(3716,538,741,'field',NULL,'','','',NULL),(3717,846,741,'field',NULL,'','','',NULL),(3718,539,741,'support',NULL,'','','',NULL),(3720,960,742,'sponsor',NULL,'','','',NULL),(3721,976,742,'field',NULL,'','','',NULL),(3722,977,742,'field',NULL,'','','',NULL),(3723,978,742,'field',NULL,'','','',NULL),(3725,979,742,'field',NULL,'','','',NULL),(3726,980,742,'field',NULL,'','','',NULL),(3727,981,742,'field',NULL,'','','',NULL),(3728,982,742,'field',NULL,'','','',NULL),(3729,983,742,'field',NULL,'','','',NULL),(3730,984,742,'field',NULL,'','','',NULL),(3731,986,742,'field',NULL,'','','',NULL),(3732,987,742,'field',NULL,'','','',NULL),(3733,988,742,'field',NULL,'','','',NULL),(3734,946,743,'sponsor',NULL,'','','',NULL),(3735,989,743,'field',NULL,'','','',NULL),(3736,990,743,'field',NULL,'','','',NULL),(3737,991,743,'field',NULL,'','','',NULL),(3738,992,743,'field',NULL,'','','',NULL),(3739,993,743,'field',NULL,'','','',NULL),(3740,994,743,'field',NULL,'','','',NULL),(3741,963,743,'funding',224000.00,'','','',NULL),(3742,959,744,'sponsor',NULL,'','','',NULL),(3743,995,744,'field',NULL,'','','',NULL),(3745,273,744,'support',NULL,'','106316','',NULL),(3754,998,745,'field',NULL,'','','',NULL),(3747,273,743,'support',NULL,'','107287','',NULL),(3748,273,742,'support',NULL,'','106413','',NULL),(3749,273,745,'support',NULL,'','107292','',NULL),(3750,946,745,'sponsor',NULL,'','','',NULL),(3751,963,745,'funding',174586.00,'','','',NULL),(3752,996,745,'field',NULL,'','','',NULL),(3753,997,745,'field',NULL,'','','',NULL),(3755,999,745,'field',NULL,'','','',NULL),(3756,273,746,'support',NULL,'','104519','',NULL),(3757,955,746,'sponsor',NULL,'','','',NULL),(3758,1000,746,'field',NULL,'','','',NULL),(3759,273,747,'funding',290000.00,'','','',NULL),(3760,950,747,'sponsor',NULL,'','','',NULL),(3761,273,747,'support',NULL,'','147/10101','',NULL),(3762,273,748,'support',NULL,'','107771','',NULL),(3763,960,748,'sponsor',NULL,'','','',NULL),(3764,273,748,'funding',60000.00,'','','',NULL),(3765,273,749,'support',NULL,'','107030','',NULL),(3766,959,749,'sponsor',NULL,'','','',NULL),(3767,273,749,'funding',152636.00,'','','',NULL),(3768,1001,749,'field',NULL,'','','',NULL),(3769,1002,748,'field',NULL,'','','',NULL),(3770,273,750,'support',NULL,'','105391','',NULL),(3771,953,750,'sponsor',NULL,'','','',NULL),(3772,1003,750,'field',NULL,'','','',NULL),(3773,273,750,'funding',800000.00,'','','',NULL),(3774,273,751,'support',NULL,'','106014','',NULL),(3775,949,751,'sponsor',NULL,'','','',NULL),(3776,876,751,'funding',11140200.00,'','','',NULL),(3779,273,715,'funding',150000.00,'','','',NULL),(3778,1004,698,'funding',153586.00,'','','',NULL),(3780,273,724,'funding',260000.00,'','','',NULL),(3781,273,752,'support',NULL,'','108296','',NULL),(3782,950,752,'sponsor',NULL,'','','',NULL),(3783,1005,752,'field',NULL,'','','',NULL),(3784,273,752,'funding',294650.00,'','','',NULL),(3785,273,753,'support',NULL,'','107680','',NULL),(3786,953,753,'sponsor',NULL,'','','',NULL),(3787,273,753,'funding',2500000.00,'','','',NULL),(3788,1006,753,'field',NULL,'','','',NULL),(3789,464,742,'funding',443000.00,'','','',NULL),(3791,273,744,'funding',100000.00,'','','',NULL),(3792,273,746,'funding',159945.00,'','','',NULL),(3803,273,713,'funding',1000000.00,'','','',NULL),(3794,273,712,'funding',500000.00,'','','',NULL),(3795,273,754,'support',NULL,'','106312','',NULL),(3796,959,754,'sponsor',NULL,'','','',NULL),(3797,1007,754,'field',NULL,'','','',NULL),(3798,273,754,'funding',100000.00,'','','',NULL),(3799,273,755,'support',NULL,'','108170','',NULL),(3800,273,755,'funding',60000.00,'','','',NULL),(3801,959,755,'sponsor',NULL,'','','',NULL),(3802,1008,755,'field',NULL,'','','',NULL),(3804,610,358,'funding',15.00,'','','',NULL),(3805,610,369,'funding',137.00,'','','',NULL),(3806,540,756,'field',NULL,'','','',NULL),(3807,538,756,'field',NULL,'','','',NULL),(3808,846,756,'field',NULL,'','','',NULL),(3809,539,756,'support',NULL,'','','',NULL),(3810,540,757,'field',NULL,'','','',NULL),(3811,538,757,'field',NULL,'','','',NULL),(3812,846,757,'field',NULL,'','','',NULL),(3813,539,757,'support',NULL,'','','',NULL),(3814,540,758,'field',NULL,'','','',NULL),(3815,538,758,'field',NULL,'','','',NULL),(3816,846,758,'field',NULL,'','','',NULL),(3817,539,758,'support',NULL,'','','',NULL),(3818,540,759,'field',NULL,'','','',NULL),(3819,538,759,'field',NULL,'','','',NULL),(3820,846,759,'field',NULL,'','','',NULL),(4051,1058,794,'support',NULL,'','','',NULL),(3822,540,760,'field',NULL,'','','',NULL),(3823,538,760,'field',NULL,'','','',NULL),(3824,846,760,'field',NULL,'','','',NULL),(3825,539,760,'support',NULL,'','','',NULL),(3826,540,761,'field',NULL,'','','',NULL),(3827,538,761,'field',NULL,'','','',NULL),(3828,846,761,'field',NULL,'','','',NULL),(3829,539,761,'support',NULL,'','','',NULL),(3830,540,762,'field',NULL,'','','',NULL),(3831,538,762,'field',NULL,'','','',NULL),(3832,846,762,'field',NULL,'','','',NULL),(3833,539,762,'support',NULL,'','','',NULL),(3834,540,763,'field',NULL,'','','',NULL),(3835,538,763,'field',NULL,'','','',NULL),(3836,846,763,'field',NULL,'','','',NULL),(3837,539,763,'support',NULL,'','','',NULL),(3838,540,764,'field',NULL,'','','',NULL),(3839,538,764,'field',NULL,'','','',NULL),(3840,846,764,'field',NULL,'','','',NULL),(3841,539,764,'support',NULL,'','','',NULL),(3842,540,765,'field',NULL,'','','',NULL),(3843,538,765,'field',NULL,'','','',NULL),(3844,846,765,'field',NULL,'','','',NULL),(3845,539,765,'support',NULL,'','','',NULL),(3846,275,766,'sponsor',NULL,'','','',NULL),(3847,660,766,'field',NULL,'','','',NULL),(3848,568,766,'field',NULL,'','','',NULL),(3849,712,766,'field',NULL,'','','',NULL),(3850,648,766,'field',NULL,'','','',NULL),(3851,1013,651,'funding',2500000.00,'','','',NULL),(4716,833,917,'funding',2913885.00,'','','',NULL),(3892,1023,768,'field',NULL,'','','',NULL),(3891,1022,768,'field',NULL,'','','',NULL),(4715,428,917,'funding',470880.00,'','','',NULL),(3889,1021,768,'funding',2883.00,'','','',NULL),(3888,1021,768,'field',NULL,'','','',NULL),(3887,405,768,'funding',76865.00,'','','',NULL),(3886,1020,768,'field',NULL,'','','',NULL),(3885,405,768,'support',NULL,'','','',NULL),(3884,275,768,'sponsor',NULL,'','','',NULL),(3883,405,767,'support',NULL,'','','',NULL),(3882,1020,767,'field',NULL,'','','',NULL),(3881,275,767,'sponsor',NULL,'','','',NULL),(3880,405,767,'funding',68120.00,'','','',NULL),(3879,815,612,'sponsor',NULL,'','','',NULL),(3878,113,612,'sponsor',NULL,'','','',NULL),(3877,113,727,'sponsor',NULL,'','','',NULL),(3876,815,727,'sponsor',NULL,'','','',NULL),(3894,275,769,'sponsor',NULL,'','','',NULL),(3895,405,769,'support',NULL,'','','',NULL),(3896,1022,769,'field',NULL,'','','',NULL),(3897,405,769,'funding',68517.00,'','','',NULL),(3898,1022,769,'funding',3606.00,'','','',NULL),(3899,275,770,'sponsor',NULL,'','','',NULL),(3900,405,770,'support',NULL,'','','',NULL),(3901,1023,770,'field',NULL,'','','',NULL),(3902,405,770,'funding',65438.00,'','','',NULL),(3903,43,771,'support',NULL,'','','',NULL),(3904,113,771,'sponsor',NULL,'','','',NULL),(3905,289,771,'sponsor',NULL,'','','',NULL),(3906,444,771,'sponsor',NULL,'','','',NULL),(3907,289,771,'funding',5500.00,'','','',NULL),(3908,444,771,'funding',5500.00,'','','',NULL),(3912,610,732,'funding',350.00,'','','',NULL),(3913,610,733,'funding',224.00,'','','',NULL),(3914,610,734,'funding',350.00,'','','',NULL),(3915,610,735,'funding',350.00,'','','',NULL),(3916,610,736,'funding',9.00,'','','',NULL),(3917,610,737,'funding',350.00,'','','',NULL),(3918,540,772,'field',NULL,'','','',NULL),(3919,538,772,'field',NULL,'','','',NULL),(3920,846,772,'field',NULL,'','','',NULL),(3921,539,772,'support',NULL,'','','',NULL),(3922,610,738,'funding',350.00,'','','',NULL),(3923,610,739,'funding',284.00,'','','',NULL),(3924,610,740,'funding',350.00,'','','',NULL),(3925,610,741,'funding',350.00,'','','',NULL),(3926,610,756,'funding',350.00,'','','',NULL),(3927,610,757,'funding',350.00,'','','',NULL),(3928,610,758,'funding',318.00,'','','',NULL),(4659,42,773,'field',NULL,'','','',NULL),(4661,243,415,'field',NULL,'','','',NULL),(3932,1060,773,'funding',117500.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(3933,610,763,'funding',3.00,'','','',NULL),(3934,127,333,'funding',3082.00,'','','',NULL),(3935,42,728,'field',NULL,'','','',NULL),(3936,969,774,'sponsor',NULL,'','','',NULL),(3937,260,774,'field',NULL,'','','',NULL),(3938,912,775,'sponsor',NULL,'','','',NULL),(3939,1029,775,'field',NULL,'','','',NULL),(3940,260,774,'funding',10000.00,'','','',NULL),(3943,969,776,'sponsor',NULL,'','','',NULL),(3944,876,776,'support',NULL,'','','',NULL),(3945,908,776,'support',NULL,'','','',NULL),(3946,746,776,'support',NULL,'','','',NULL),(3947,136,776,'support',NULL,'','','',NULL),(3948,610,431,'funding',12.00,'','','',NULL),(3949,1032,776,'funding',7500.00,'','','',NULL),(3950,969,777,'sponsor',NULL,'','','',NULL),(3951,1033,777,'field',NULL,'','','',NULL),(3952,1033,777,'funding',60000.00,'','','',NULL),(3954,42,777,'support',NULL,'','','',NULL),(3955,42,777,'support',NULL,'','','',NULL),(4372,113,415,'sponsor',NULL,'','','',NULL),(3958,829,727,'sponsor',NULL,'','','',NULL),(3959,829,674,'sponsor',NULL,'','','',NULL),(3960,829,645,'sponsor',NULL,'','','',NULL),(3961,829,644,'sponsor',NULL,'','','',NULL),(3962,829,594,'sponsor',NULL,'','','',NULL),(3963,829,310,'sponsor',NULL,'','','',NULL),(3965,294,779,'field',NULL,'','','',NULL),(3966,746,779,'funding',NULL,'','','',NULL),(3967,753,779,'funding',306687.00,'','','',NULL),(3968,273,780,'support',NULL,'','106608','',NULL),(3969,961,780,'sponsor',NULL,'','','',NULL),(3970,273,780,'funding',111000.00,'','','',NULL),(3971,1042,780,'field',NULL,'','','',NULL),(3972,1041,780,'field',NULL,'','','',NULL),(3973,970,676,'field',NULL,'','','',NULL),(3974,576,676,'field',NULL,'','','',NULL),(3975,1014,676,'field',NULL,'','','',NULL),(3976,1040,676,'field',NULL,'','','',NULL),(3981,43,134,'funding',20812.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(3980,444,134,'funding',27733.00,'','','',NULL),(3982,1030,775,'field',NULL,'','','',NULL),(3983,1027,775,'field',NULL,'','','',NULL),(3984,1031,775,'field',NULL,'','','',NULL),(4433,1060,800,'sponsor',NULL,'','','',NULL),(4432,1060,801,'sponsor',NULL,'','','',NULL),(3988,912,781,'sponsor',NULL,'','','',NULL),(3989,527,781,'field',NULL,'','','',NULL),(3990,912,782,'sponsor',NULL,'','','',NULL),(3991,1011,782,'field',NULL,'','','',NULL),(3992,1010,782,'field',NULL,'','','',NULL),(3993,1009,782,'field',NULL,'','','',NULL),(3994,1018,782,'field',NULL,'','','',NULL),(3996,43,315,'funding',19545.00,'NL-1-PPR-19884','','http://search-api.openaid.nl/projectdetail_api/2669/',NULL),(4000,322,783,'field',NULL,'','','',NULL),(3998,539,762,'funding',1.00,'','','',NULL),(4001,113,783,'sponsor',NULL,'','','',NULL),(4002,815,783,'sponsor',NULL,'','','',NULL),(4003,43,783,'support',NULL,'','','',NULL),(4004,43,783,'funding',90000.00,'','','',NULL),(4005,110,784,'field',NULL,'1077889','Pump Aid','http://www.pumpaid.org/','field'),(4012,947,786,'support',NULL,'','','',NULL),(4011,272,785,'support',NULL,'','','',NULL),(4010,969,785,'sponsor',NULL,'','','',NULL),(4009,110,784,'support',NULL,'107889','Pump Aid','http://www.pumpaid.org/','field'),(4013,136,786,'field',NULL,'','','',NULL),(4014,947,787,'support',NULL,'','','',NULL),(4015,1048,787,'field',NULL,'','','',NULL),(4016,947,788,'support',NULL,'','','',NULL),(4017,1047,788,'field',NULL,'','','',NULL),(4018,947,789,'support',NULL,'','','',NULL),(4021,1052,771,'field',NULL,'','','',NULL),(4022,1053,771,'field',NULL,'','','',NULL),(4023,113,790,'sponsor',NULL,'','','',NULL),(4024,815,790,'sponsor',NULL,'','','',NULL),(4028,1055,790,'field',NULL,'','','',NULL),(4026,43,790,'support',NULL,'','','',NULL),(4027,8,790,'funding',235070.00,'','','',NULL),(4029,646,791,'field',NULL,'','','',NULL),(4030,43,791,'support',NULL,'','','',NULL),(4031,43,791,'funding',4000.00,'','','',NULL),(4032,1057,791,'funding',5000.00,'','','',NULL),(4033,275,792,'sponsor',NULL,'','','',NULL),(4034,569,792,'field',NULL,'','','',NULL),(4035,405,792,'support',NULL,'','','',NULL),(4036,405,792,'funding',8542.00,'','','',NULL),(4038,815,771,'sponsor',NULL,'','','',NULL),(4039,901,669,'funding',29476.00,'','','',NULL),(4046,462,793,'support',NULL,'','','',NULL),(4045,8,793,'support',NULL,'','','',NULL),(4044,912,793,'sponsor',NULL,'','','',NULL),(4047,1015,793,'field',NULL,'','','',NULL),(4048,1039,793,'field',NULL,'','','',NULL),(4049,1025,793,'field',NULL,'','','',NULL),(4050,1035,793,'field',NULL,'','','',NULL),(4052,168,794,'funding',300000.00,'','','',NULL),(4053,1058,795,'support',NULL,'','','',NULL),(4054,52,795,'funding',5000.00,'','','',NULL),(4055,444,647,'sponsor',NULL,'','','',NULL),(4056,444,647,'funding',13087.00,'','','',NULL),(4057,43,647,'funding',10469.00,'','','',NULL),(4059,734,796,'funding',146371.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(4060,734,796,'sponsor',NULL,'','','',NULL),(4071,734,797,'funding',146371.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(4070,640,797,'field',NULL,'','','',NULL),(4064,8,796,'support',NULL,'','','',NULL),(4069,678,797,'support',NULL,'','','',NULL),(4068,830,796,'field',NULL,'','','',NULL),(4067,823,796,'field',NULL,'','','',NULL),(4075,734,798,'funding',146371.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(4074,689,798,'support',NULL,'','','',NULL),(4076,734,798,'sponsor',NULL,'','','',NULL),(4077,818,798,'field',NULL,'','','',NULL),(4078,818,799,'field',NULL,'','','',NULL),(4079,734,799,'funding',146371.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(4080,734,799,'sponsor',NULL,'','','',NULL),(4081,689,799,'support',NULL,'','','',NULL),(4082,816,800,'field',NULL,'','','',NULL),(4083,734,800,'funding',146371.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(4084,734,800,'sponsor',NULL,'','','',NULL),(4085,679,800,'support',NULL,'','','',NULL),(4086,678,800,'support',NULL,'','','',NULL),(4087,830,801,'field',NULL,'','','',NULL),(4088,204,801,'field',NULL,'','','',NULL),(4089,734,801,'sponsor',217968.00,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(4095,1060,801,'funding',217968.00,'','','',NULL),(4091,689,801,'support',NULL,'','','',NULL),(4092,1034,653,'support',NULL,'','','',NULL),(4093,1059,653,'field',NULL,'','','',NULL),(4094,641,801,'support',NULL,'','','',NULL),(4377,43,391,'funding',12000.00,'','','',NULL),(4098,359,342,'funding',4000.00,'','','',NULL),(4099,360,802,'support',NULL,'','','',NULL),(4100,506,802,'field',NULL,'','','',NULL),(4101,506,802,'funding',2000.00,'','','',NULL),(4102,360,803,'support',NULL,'','','',NULL),(4103,506,803,'field',NULL,'','','',NULL),(4104,506,803,'funding',850000.00,'','','',NULL),(4105,360,804,'support',NULL,'','','',NULL),(4106,506,804,'field',NULL,'','','',NULL),(4107,506,804,'funding',800000.00,'','','',NULL),(4108,360,805,'support',NULL,'','','',NULL),(4109,506,805,'field',NULL,'','','',NULL),(4110,506,805,'funding',35000.00,'','','',NULL),(4111,360,806,'support',NULL,'','','',NULL),(4112,506,806,'field',NULL,'','','',NULL),(4113,506,806,'funding',35000.00,'','','',NULL),(4114,360,807,'support',NULL,'','','',NULL),(4115,506,807,'field',NULL,'','','',NULL),(4116,506,807,'funding',50000.00,'','','',NULL),(4117,1062,795,'field',NULL,'','','',NULL),(4118,360,808,'support',NULL,'','','',NULL),(4119,947,786,'funding',1192000.00,'','','',NULL),(4120,947,787,'funding',942000.00,'','','',NULL),(4121,947,788,'funding',1020000.00,'','','',NULL),(4122,746,810,'funding',10000000.00,'','','',NULL),(4123,42,811,'sponsor',NULL,'','','',NULL),(4124,1061,812,'sponsor',NULL,'','','',NULL),(4125,746,813,'funding',20000000.00,'','','',NULL),(4126,746,813,'support',NULL,'','','',NULL),(4127,1069,813,'field',NULL,'','','',NULL),(4128,1061,814,'sponsor',NULL,'','','',NULL),(4129,1032,815,'support',NULL,'','','',NULL),(4130,1071,815,'field',NULL,'','','',NULL),(4131,1032,815,'funding',50000.00,'','','',NULL),(4132,908,816,'support',NULL,'','','',NULL),(4133,820,817,'support',NULL,'','','',NULL),(4134,1084,817,'field',NULL,'','','',NULL),(4135,1078,818,'support',NULL,'','','',NULL),(4136,1061,813,'sponsor',NULL,'','','','sponsor'),(4145,1065,820,'support',NULL,'','','',NULL),(4144,1061,820,'sponsor',NULL,'','','',NULL),(4140,467,819,'field',NULL,'','','',NULL),(4141,113,819,'sponsor',NULL,'','','',NULL),(4142,815,819,'sponsor',NULL,'','','',NULL),(4143,43,819,'support',NULL,'','','',NULL),(4146,1067,820,'field',NULL,'','','',NULL),(4147,1083,820,'field',NULL,'','','',NULL),(4164,1061,824,'sponsor',NULL,'','','',NULL),(4162,1089,650,'funding',127000.00,'','','',NULL),(4161,883,650,'funding',757500.00,'','','',NULL),(4153,1061,822,'sponsor',NULL,'','','',NULL),(4154,1080,822,'support',NULL,'','','',NULL),(4155,1068,822,'field',NULL,'','','',NULL),(4156,1083,822,'field',NULL,'','','',NULL),(4157,1084,822,'field',NULL,'','','',NULL),(4158,1061,823,'sponsor',NULL,'','','',NULL),(4159,1080,823,'support',NULL,'','','',NULL),(4160,1067,823,'field',NULL,'','','',NULL),(4165,273,825,'support',NULL,'','108050','',NULL),(4166,949,825,'sponsor',NULL,'','','',NULL),(4167,273,825,'funding',3455850.00,'','','',NULL),(4168,273,826,'support',NULL,'','','',NULL),(4169,960,826,'sponsor',NULL,'','','',NULL),(4170,1091,826,'field',NULL,'','','',NULL),(4171,1092,826,'field',NULL,'','','',NULL),(4174,1061,828,'sponsor',NULL,'','','',NULL),(4177,360,829,'support',NULL,'','','',NULL),(4178,1090,829,'field',NULL,'','','',NULL),(4179,405,830,'support',NULL,'','','',NULL),(4180,275,830,'sponsor',NULL,'','','',NULL),(4181,405,830,'funding',88271.00,'','','',NULL),(4182,1088,822,'field',NULL,'','','',NULL),(4185,1034,831,'field',NULL,'','','',NULL),(4189,556,832,'field',NULL,'','','',NULL),(4190,1034,832,'field',NULL,'','','',NULL),(4187,735,831,'sponsor',NULL,'','','',NULL),(4188,42,831,'support',NULL,'','','',NULL),(4191,735,832,'sponsor',NULL,'','','',NULL),(4192,42,832,'field',NULL,'','','',NULL),(4193,556,833,'field',NULL,'','','',NULL),(4194,1034,833,'field',NULL,'','','',NULL),(4195,735,833,'sponsor',NULL,'','','',NULL),(4196,1059,833,'field',NULL,'','','',NULL),(4201,1034,835,'field',NULL,'','','',NULL),(4198,1034,834,'field',NULL,'','','',NULL),(4199,735,834,'sponsor',NULL,'','','',NULL),(4200,896,834,'support',NULL,'','','',NULL),(4202,735,835,'sponsor',NULL,'','','',NULL),(4203,1059,835,'support',NULL,'','','',NULL),(4204,1034,836,'field',NULL,'','','',NULL),(4205,735,836,'sponsor',NULL,'','','',NULL),(4206,896,836,'field',NULL,'','','',NULL),(4207,556,837,'field',NULL,'','','',NULL),(4208,1034,837,'field',NULL,'','','',NULL),(4209,735,837,'sponsor',NULL,'','','',NULL),(4210,42,837,'field',NULL,'','','',NULL),(4215,1034,839,'field',NULL,'','','',NULL),(4212,1034,838,'field',NULL,'','','',NULL),(4213,735,838,'sponsor',NULL,'','','',NULL),(4214,1059,838,'field',NULL,'','','',NULL),(4216,735,839,'support',NULL,'','','',NULL),(4217,1059,839,'field',NULL,'','','',NULL),(4218,1095,788,'field',NULL,'','','',NULL),(4219,1095,787,'field',NULL,'','','',NULL),(4220,1095,786,'field',NULL,'','','',NULL),(4221,1095,703,'field',NULL,'','','',NULL),(4222,150,840,'field',NULL,'','','',NULL),(4223,35,840,'support',NULL,'','','',NULL),(4274,1061,815,'sponsor',NULL,'','','',NULL),(4273,1061,810,'sponsor',NULL,'','','',NULL),(4227,42,788,'field',NULL,'','','',NULL),(4228,42,787,'field',NULL,'','','',NULL),(4229,42,786,'field',NULL,'','','',NULL),(4230,42,703,'field',NULL,'','','',NULL),(4741,42,880,'support',NULL,'','','',NULL),(4234,538,841,'field',NULL,'','','',NULL),(4235,846,841,'field',NULL,'','','',NULL),(4236,539,841,'support',NULL,'','','',NULL),(4237,540,842,'field',NULL,'','','',NULL),(4238,538,842,'field',NULL,'','','',NULL),(4239,846,842,'field',NULL,'','','',NULL),(4240,539,842,'support',NULL,'','','',NULL),(4241,540,843,'field',NULL,'','','',NULL),(4242,538,843,'field',NULL,'','','',NULL),(4243,846,843,'field',NULL,'','','',NULL),(4244,539,843,'support',NULL,'','','',NULL),(4245,540,844,'field',NULL,'','','',NULL),(4246,538,844,'field',NULL,'','','',NULL),(4247,846,844,'field',NULL,'','','',NULL),(4248,539,844,'support',NULL,'','','',NULL),(4249,540,845,'field',NULL,'','','',NULL),(4250,538,845,'field',NULL,'','','',NULL),(4251,846,845,'field',NULL,'','','',NULL),(4252,539,845,'support',NULL,'','','',NULL),(4253,540,846,'field',NULL,'','','',NULL),(4254,538,846,'field',NULL,'','','',NULL),(4255,846,846,'field',NULL,'','','',NULL),(4256,539,846,'support',NULL,'','','',NULL),(4257,540,847,'field',NULL,'','','',NULL),(4258,538,847,'field',NULL,'','','',NULL),(4259,846,847,'field',NULL,'','','',NULL),(4260,539,847,'support',NULL,'','','',NULL),(4261,540,848,'field',NULL,'','','',NULL),(4262,538,848,'field',NULL,'','','',NULL),(4263,846,848,'field',NULL,'','','',NULL),(4264,539,848,'support',NULL,'','','',NULL),(4265,540,849,'field',NULL,'','','',NULL),(4266,538,849,'field',NULL,'','','',NULL),(4267,846,849,'field',NULL,'','','',NULL),(4268,539,849,'support',NULL,'','','',NULL),(4269,540,850,'field',NULL,'','','',NULL),(4270,538,850,'field',NULL,'','','',NULL),(4271,846,850,'field',NULL,'','','',NULL),(4272,539,850,'support',NULL,'','','',NULL),(4275,113,273,'sponsor',NULL,'','','',NULL),(4276,444,273,'funding',3275.00,'','','',NULL),(4277,43,273,'funding',444.00,'','','',NULL),(4278,1096,851,'field',NULL,'','','',NULL),(4279,1096,851,'funding',28000.00,'','','',NULL),(4280,106,851,'support',NULL,'','','',NULL),(4281,360,852,'support',NULL,'','','',NULL),(4282,361,852,'field',NULL,'','','',NULL),(4283,886,852,'field',NULL,'','','',NULL),(4284,1064,814,'field',NULL,'','','',NULL),(4285,1098,829,'field',NULL,'','','','funding'),(4286,1097,829,'field',NULL,'','','','funding'),(4287,428,853,'funding',18750.00,'','','',NULL),(4288,428,854,'support',NULL,'','','',NULL),(4289,833,853,'funding',752025.00,'','','',NULL),(4290,168,854,'funding',700.00,'','','',NULL),(4294,1099,856,'sponsor',NULL,'','','',NULL),(4292,736,855,'sponsor',NULL,'','','',NULL),(4293,689,855,'support',NULL,'','','',NULL),(4295,273,856,'support',NULL,'','105994','',NULL),(4296,1100,856,'field',NULL,'','','',NULL),(4297,464,856,'funding',300447.00,'','','',NULL),(4298,273,857,'support',NULL,'','108096','',NULL),(4373,113,329,'sponsor',NULL,'','','',NULL),(4300,1099,857,'sponsor',NULL,'','','',NULL),(4301,303,857,'field',NULL,'','','',NULL),(4302,1101,857,'field',NULL,'','','',NULL),(4303,464,857,'funding',291219.00,'','','',NULL),(4304,273,859,'support',NULL,'','109108','',NULL),(4305,1099,859,'sponsor',NULL,'','','',NULL),(4306,1102,859,'field',NULL,'','','',NULL),(4307,464,859,'funding',60000.00,'','','',NULL),(4308,1103,859,'field',NULL,'','','',NULL),(4309,736,860,'sponsor',NULL,'','','',NULL),(4310,689,860,'support',NULL,'','','',NULL),(4311,736,861,'sponsor',NULL,'','','',NULL),(4312,679,861,'support',NULL,'','','',NULL),(4313,273,862,'support',NULL,'','108914','',NULL),(4314,1099,862,'sponsor',NULL,'','','',NULL),(4315,464,862,'funding',80000.00,'','','',NULL),(4316,1104,862,'field',NULL,'','','',NULL),(4317,911,861,'field',NULL,'','','',NULL),(4321,907,864,'field',NULL,'','','',NULL),(4319,736,863,'sponsor',NULL,'','','',NULL),(4320,907,863,'field',NULL,'','','',NULL),(4322,736,864,'sponsor',NULL,'','','',NULL),(4323,113,362,'sponsor',NULL,'','','',NULL),(4324,294,865,'support',NULL,'','','',NULL),(4325,113,391,'sponsor',NULL,'','','',NULL),(4326,227,158,'funding',0.00,'','','',NULL),(4327,1080,866,'support',NULL,'','','',NULL),(4328,1068,866,'field',NULL,'','','',NULL),(4713,43,915,'funding',15258.00,'','','',NULL),(4330,1061,866,'sponsor',NULL,'','','',NULL),(4653,1149,867,'field',NULL,'','','',NULL),(4332,1043,867,'support',NULL,'','','',NULL),(4333,462,867,'support',NULL,'','','',NULL),(4334,912,868,'sponsor',NULL,'','','',NULL),(4335,1043,868,'support',NULL,'','','',NULL),(4336,462,868,'support',NULL,'','','',NULL),(4337,1044,868,'support',NULL,'','','',NULL),(4465,42,836,'field',NULL,'','','',NULL),(4464,42,838,'field',NULL,'','','',NULL),(4463,42,839,'field',NULL,'','','',NULL),(4341,1036,869,'field',NULL,'','','',NULL),(4342,1024,869,'field',NULL,'','','',NULL),(4343,1026,869,'field',NULL,'','','',NULL),(4344,168,822,'funding',500000.00,'','','',NULL),(4345,912,870,'sponsor',NULL,'','','',NULL),(4346,172,870,'field',NULL,'','','',NULL),(4347,798,870,'field',NULL,'','','',NULL),(4348,1043,870,'support',NULL,'','','',NULL),(4349,8,870,'support',NULL,'','','',NULL),(4350,462,870,'support',NULL,'','','',NULL),(4351,95,870,'support',NULL,'','','',NULL),(4352,843,613,'funding',1158.00,'','','',NULL),(4353,168,871,'funding',700.00,'','','',NULL),(4354,428,871,'support',NULL,'','','',NULL),(4384,273,878,'support',NULL,'','105880','',NULL),(4378,1105,865,'field',NULL,'','','',NULL),(4358,168,872,'funding',700.00,'','','',NULL),(4359,428,872,'support',NULL,'','','',NULL),(4361,168,873,'funding',700.00,'','','',NULL),(4362,428,873,'support',NULL,'','','',NULL),(4364,168,874,'funding',700.00,'','','',NULL),(4365,428,874,'support',NULL,'','','',NULL),(4379,1105,865,'funding',170000.00,'','','',NULL),(4367,168,875,'funding',700.00,'','','',NULL),(4368,428,875,'support',NULL,'','','',NULL),(4385,946,878,'sponsor',NULL,'','','',NULL),(4382,654,877,'support',NULL,'','','',NULL),(4383,1106,877,'field',NULL,'','','',NULL),(4386,1107,878,'field',NULL,'','','',NULL),(4387,1108,878,'field',NULL,'','','',NULL),(4388,1109,878,'field',NULL,'','','',NULL),(4389,1110,878,'field',NULL,'','','',NULL),(4390,1111,878,'field',NULL,'','','',NULL),(4391,1112,878,'funding',NULL,'','','',NULL),(4392,1113,854,'funding',8000.00,'','','',NULL),(4393,1113,871,'funding',8000.00,'','','',NULL),(4394,1113,872,'funding',8000.00,'','','',NULL),(4395,1113,873,'funding',8000.00,'','','',NULL),(4396,1113,874,'funding',8000.00,'','','',NULL),(4397,1113,875,'funding',8000.00,'','','',NULL),(4404,43,568,'support',NULL,'','','',NULL),(4403,564,391,'funding',937.00,'','','',NULL),(4405,56,568,'field',NULL,'','','',NULL),(4406,1114,568,'funding',11043.00,'','','',NULL),(4407,43,568,'funding',9035.00,'','','',NULL),(4409,444,362,'funding',16392.00,'','','',NULL),(4410,428,853,'support',NULL,'','','',NULL),(4411,428,879,'funding',45330.19,'','','',NULL),(4412,963,879,'funding',419845.50,'','','',NULL),(4413,428,879,'support',NULL,'','','',NULL),(4414,1071,814,'support',NULL,'','','',NULL),(4415,1064,814,'funding',1600.00,'','','',NULL),(4416,1129,627,'field',NULL,'','','',NULL),(4420,1130,633,'field',NULL,'','','',NULL),(4421,1119,633,'field',NULL,'','','',NULL),(4422,1123,633,'field',NULL,'','','',NULL),(4423,1132,630,'field',NULL,'','','',NULL),(4424,1133,633,'field',NULL,'','','',NULL),(4425,1115,684,'field',NULL,'','','',NULL),(4426,1130,635,'field',NULL,'','','',NULL),(4427,1138,879,'field',NULL,'','','',NULL),(4428,1135,879,'field',NULL,'','','',NULL),(4429,1136,879,'field',NULL,'','','',NULL),(4430,1137,879,'field',NULL,'','','',NULL),(4431,1136,879,'funding',33781.47,'','','',NULL),(4434,1060,773,'sponsor',NULL,'NL-1-PPR-23872','','http://search-api.openaid.nl/projectdetail_api/660/',NULL),(4435,1060,591,'sponsor',NULL,'','','',NULL),(4436,1060,575,'sponsor',NULL,'','','',NULL),(4437,1060,574,'sponsor',NULL,'','','',NULL),(4438,1060,657,'sponsor',NULL,'','','',NULL),(4439,1060,864,'sponsor',NULL,'','','',NULL),(4440,1060,863,'sponsor',NULL,'','','',NULL),(4441,1060,861,'sponsor',NULL,'','','',NULL),(4442,1060,860,'sponsor',NULL,'','','',NULL),(4443,1060,855,'sponsor',NULL,'','','',NULL),(4444,1060,839,'sponsor',NULL,'','','',NULL),(4445,1060,838,'sponsor',NULL,'','','',NULL),(4446,1060,837,'sponsor',NULL,'','','',NULL),(4447,1060,836,'sponsor',NULL,'','','',NULL),(4448,1060,835,'sponsor',NULL,'','','',NULL),(4449,1060,834,'sponsor',NULL,'','','',NULL),(4450,1060,833,'sponsor',NULL,'','','',NULL),(4451,1060,832,'sponsor',NULL,'','','',NULL),(4452,1060,831,'sponsor',NULL,'','','',NULL),(4453,1060,796,'sponsor',NULL,'','','',NULL),(4454,1060,797,'sponsor',NULL,'','','',NULL),(4455,1060,798,'sponsor',NULL,'','','',NULL),(4456,1060,799,'sponsor',NULL,'','','',NULL),(4652,1150,868,'field',NULL,'','','',NULL),(4459,912,867,'sponsor',NULL,'','','',NULL),(4460,294,877,'funding',850.00,'','','',NULL),(4461,912,870,'funding',6127000.00,'','','',NULL),(4462,912,869,'funding',3038000.00,'','','',NULL),(4466,42,835,'field',NULL,'','','',NULL),(4467,42,834,'field',NULL,'','','',NULL),(4468,42,833,'support',NULL,'','','',NULL),(4469,1143,810,'field',NULL,'','','',NULL),(4470,947,880,'support',NULL,'','','',NULL),(4471,947,881,'support',NULL,'','','',NULL),(4472,1083,823,'field',NULL,'','','',NULL),(4473,1074,823,'field',NULL,'','','',NULL),(4474,1072,823,'field',NULL,'','','',NULL),(4475,1048,880,'field',NULL,'','','',NULL),(4476,93,880,'field',NULL,'','','',NULL),(4477,16,880,'field',NULL,'','','',NULL),(4478,746,880,'funding',8000000.00,'','','',NULL),(4479,488,583,'field',NULL,'','','',NULL),(4534,482,785,'field',NULL,'','','',NULL),(4481,1061,164,'sponsor',NULL,'','','',NULL),(4482,1061,776,'sponsor',NULL,'','','',NULL),(4483,1061,74,'sponsor',NULL,'','','',NULL),(4484,1083,816,'funding',118431.46,'','','',NULL),(4485,1061,816,'sponsor',NULL,'','','',NULL),(4486,1083,816,'field',NULL,'','','',NULL),(4492,1064,883,'funding',1600.00,'','','',NULL),(4493,1061,883,'sponsor',NULL,'','','',NULL),(4494,1064,884,'field',NULL,'','','',NULL),(4495,1064,884,'funding',1600.00,'','','',NULL),(4496,1061,884,'sponsor',NULL,'','','',NULL),(4497,1064,884,'support',NULL,'','','',NULL),(4498,1064,885,'field',NULL,'','','',NULL),(4499,1064,885,'funding',1600.00,'','','',NULL),(4500,1061,885,'sponsor',NULL,'','','',NULL),(4501,1064,885,'support',NULL,'','','',NULL),(4502,1064,886,'field',NULL,'','','',NULL),(4503,1064,886,'funding',1600.00,'','','',NULL),(4504,1061,886,'sponsor',NULL,'','','',NULL),(4505,1064,886,'support',NULL,'','','',NULL),(4506,1064,887,'field',NULL,'','','',NULL),(4507,1064,887,'funding',1600.00,'','','',NULL),(4508,1061,887,'sponsor',NULL,'','','',NULL),(4509,1064,887,'support',NULL,'','','',NULL),(4510,1064,888,'field',NULL,'','','',NULL),(4511,1064,888,'funding',1600.00,'','','',NULL),(4512,1061,888,'sponsor',NULL,'','','',NULL),(4513,1064,888,'support',NULL,'','','',NULL),(4514,1064,889,'field',NULL,'','','',NULL),(4515,1064,889,'funding',1600.00,'','','',NULL),(4516,1061,889,'sponsor',NULL,'','','',NULL),(4517,1064,889,'support',NULL,'','','',NULL),(4518,1064,890,'field',NULL,'','','',NULL),(4519,1064,890,'funding',1600.00,'','','',NULL),(4520,1061,890,'sponsor',NULL,'','','',NULL),(4521,1064,890,'support',NULL,'','','',NULL),(4522,1064,891,'field',NULL,'','','',NULL),(4523,1064,891,'funding',1600.00,'','','',NULL),(4524,1061,891,'sponsor',NULL,'','','',NULL),(4525,1064,891,'support',NULL,'','','',NULL),(4526,1064,882,'support',NULL,'','','',NULL),(4527,1064,883,'support',NULL,'','','',NULL),(4528,273,809,'support',NULL,'','108050','',NULL),(4529,1145,809,'field',NULL,'','','',NULL),(4530,949,809,'sponsor',NULL,'','','',NULL),(4533,273,785,'funding',11309.39,'','','',NULL),(4535,294,785,'field',NULL,'','','',NULL),(4536,1064,893,'field',NULL,'','','',NULL),(4537,1064,892,'field',NULL,'','','',NULL),(4538,1064,893,'funding',NULL,'','','',NULL),(4539,1064,892,'funding',NULL,'','','',NULL),(4540,1061,893,'sponsor',NULL,'','','',NULL),(4541,1061,892,'sponsor',NULL,'','','',NULL),(4542,1064,892,'support',NULL,'','','',NULL),(4543,1064,894,'field',NULL,'','','',NULL),(4544,1064,893,'support',NULL,'','','',NULL),(4545,1064,894,'funding',1600.00,'','','',NULL),(4546,1061,894,'sponsor',NULL,'','','',NULL),(4547,1071,894,'support',NULL,'','','',NULL),(4548,428,895,'funding',123000.00,'','','',NULL),(4549,430,895,'funding',1125382.00,'','','',NULL),(4550,430,895,'support',NULL,'','','',NULL),(4551,1064,896,'field',NULL,'','','',NULL),(4552,1064,896,'funding',1600.00,'','','',NULL),(4553,1061,896,'sponsor',NULL,'','','',NULL),(4554,1071,896,'support',NULL,'','','',NULL),(4555,1064,897,'field',NULL,'','','',NULL),(4556,1064,897,'funding',1600.00,'','','',NULL),(4557,1061,897,'sponsor',NULL,'','','',NULL),(4558,1071,897,'support',NULL,'','','',NULL),(4559,1064,898,'field',NULL,'','','',NULL),(4560,1064,898,'funding',1600.00,'','','',NULL),(4561,1061,898,'sponsor',NULL,'','','',NULL),(4562,1071,898,'support',NULL,'','','',NULL),(4563,1064,899,'field',NULL,'','','',NULL),(4564,1064,899,'funding',1600.00,'','','',NULL),(4565,1061,899,'sponsor',NULL,'','','',NULL),(4566,1071,899,'support',NULL,'','','',NULL),(4567,1064,900,'field',NULL,'','','',NULL),(4568,1064,900,'funding',1600.00,'','','',NULL),(4569,1061,900,'sponsor',NULL,'','','',NULL),(4570,1071,900,'support',NULL,'','','',NULL),(4571,1064,901,'field',NULL,'','','',NULL),(4572,1064,901,'funding',NULL,'','','',NULL),(4573,1061,901,'sponsor',NULL,'','','',NULL),(4574,1064,901,'support',NULL,'','','',NULL),(4575,1064,902,'field',NULL,'','','',NULL),(4576,1064,902,'funding',1600.00,'','','',NULL),(4577,1061,902,'sponsor',NULL,'','','',NULL),(4578,1071,902,'support',NULL,'','','',NULL),(4579,1064,903,'field',NULL,'','','',NULL),(4580,1064,903,'funding',1600.00,'','','',NULL),(4581,1061,903,'sponsor',NULL,'','','',NULL),(4582,1071,903,'support',NULL,'','','',NULL),(4583,1064,904,'field',NULL,'','','',NULL),(4584,1064,904,'funding',1600.00,'','','',NULL),(4585,1061,904,'sponsor',NULL,'','','',NULL),(4586,1064,904,'support',NULL,'','','',NULL),(4587,1064,905,'field',NULL,'','','',NULL),(4588,1064,905,'funding',1600.00,'','','',NULL),(4589,1061,905,'sponsor',NULL,'','','',NULL),(4590,1064,905,'support',NULL,'','','',NULL),(4591,1064,906,'field',NULL,'','','',NULL),(4592,1064,906,'funding',NULL,'','','',NULL),(4593,1061,906,'sponsor',NULL,'','','',NULL),(4594,1064,906,'support',NULL,'','','',NULL),(4595,1064,907,'field',NULL,'','','',NULL),(4596,1064,907,'funding',1600.00,'','','',NULL),(4597,1061,907,'sponsor',NULL,'','','',NULL),(4598,1071,907,'support',NULL,'','','',NULL),(4599,1064,908,'field',NULL,'','','',NULL),(4600,1064,908,'funding',1600.00,'','','',NULL),(4601,1061,908,'sponsor',NULL,'','','',NULL),(4602,1064,908,'support',NULL,'','','',NULL),(4603,1064,909,'field',NULL,'','','',NULL),(4604,1064,909,'funding',1600.00,'','','',NULL),(4605,1061,909,'sponsor',NULL,'','','',NULL),(4606,1064,909,'support',NULL,'','','',NULL),(4607,1064,910,'field',NULL,'','','',NULL),(4608,1064,910,'funding',1575.00,'','','',NULL),(4609,1061,910,'sponsor',NULL,'','','',NULL),(4610,1071,910,'support',NULL,'','','',NULL),(4611,1064,911,'field',NULL,'','','',NULL),(4612,1064,911,'funding',NULL,'','','',NULL),(4613,1061,911,'sponsor',NULL,'','','',NULL),(4614,1064,911,'support',NULL,'','','',NULL),(4615,1146,895,'funding',2000.00,'','','',NULL),(4616,1148,895,'field',NULL,'','','',NULL),(4617,1147,895,'field',NULL,'','','',NULL),(4618,1064,912,'field',NULL,'','','',NULL),(4619,1064,912,'funding',1500.00,'','','',NULL),(4620,1061,912,'sponsor',NULL,'','','',NULL),(4621,1071,912,'support',NULL,'','','',NULL),(4622,1064,913,'field',NULL,'','','',NULL),(4623,1064,913,'funding',1600.00,'','','',NULL),(4624,1061,913,'sponsor',NULL,'','','',NULL),(4625,1071,913,'support',NULL,'','','',NULL),(4626,1064,914,'field',NULL,'','','',NULL),(4627,1064,914,'funding',1600.00,'','','',NULL),(4628,1061,914,'sponsor',NULL,'','','',NULL),(4629,1064,914,'support',NULL,'','','',NULL),(4630,912,869,'sponsor',NULL,'','','',NULL),(4631,912,868,'funding',3766000.00,'','','',NULL),(4632,912,867,'funding',3399000.00,'','','',NULL),(4633,912,793,'funding',3870000.00,'','','',NULL),(4634,912,782,'funding',2916000.00,'','','',NULL),(4635,8,782,'support',NULL,'','','',NULL),(4636,462,782,'support',NULL,'','','',NULL),(4637,912,781,'funding',3614000.00,'','','',NULL),(4638,912,775,'funding',5461000.00,'','','',NULL),(4639,1060,653,'funding',494062.00,'','','',NULL),(4640,1060,831,'funding',52875.00,'','','',NULL),(4641,1060,834,'funding',342200.00,'','','',NULL),(4642,1060,838,'funding',53466.00,'','','',NULL),(4643,912,676,'funding',7055000.00,'','','',NULL),(4646,444,329,'funding',3305.00,'','','',NULL),(4647,289,329,'funding',3414.00,'','','',NULL),(4648,43,329,'funding',12109.00,'','','',NULL),(4649,444,427,'funding',72430.00,'','','',NULL),(4650,95,427,'funding',52570.00,'','','',NULL),(4651,444,415,'funding',22000.00,'','','',NULL),(4654,1019,782,'field',NULL,'','','',NULL),(4655,1151,467,'funding',0.00,'','','',NULL),(4656,113,467,'sponsor',NULL,'','','',NULL),(4657,168,823,'funding',73933.70,'','','',NULL),(4658,463,870,'field',NULL,'','','',NULL),(4662,1157,868,'field',NULL,'','','',NULL),(4663,1155,868,'field',NULL,'','','',NULL),(4664,1153,868,'field',NULL,'','','',NULL),(4665,1156,868,'field',NULL,'','','',NULL),(4666,1152,868,'field',NULL,'','','',NULL),(4667,1154,868,'field',NULL,'','','',NULL),(4668,43,778,'support',NULL,'','','',NULL),(4669,1158,778,'field',NULL,'','','',NULL),(4670,1158,778,'funding',51437.00,'','','',NULL),(4671,43,778,'funding',30013.00,'','','',NULL),(4672,168,778,'funding',18550.00,'','','',NULL),(4673,168,851,'funding',2500.00,'','','',NULL),(4674,815,597,'funding',22344.00,'','','',NULL),(4675,815,415,'sponsor',NULL,'','','',NULL),(4676,35,840,'funding',1493.00,'','','',NULL),(4678,209,210,'funding',84000.00,'','','',NULL),(4679,494,784,'funding',1000.00,'','','',NULL),(4681,1162,915,'funding',11000.00,'','','',NULL),(4682,1159,868,'field',NULL,'','','',NULL),(4683,1160,868,'field',NULL,'','','',NULL),(4684,1054,789,'field',NULL,'','','',NULL),(4685,1161,915,'funding',8073.00,'','','',NULL),(4686,43,915,'support',NULL,'','','',NULL),(4687,1163,915,'field',NULL,'','','',NULL),(4688,1048,881,'field',NULL,'','','',NULL),(4689,16,881,'field',NULL,'','','',NULL),(4690,529,881,'field',NULL,'','','',NULL),(4691,93,881,'field',NULL,'','','',NULL),(4692,42,789,'field',NULL,'','','',NULL),(4693,1095,789,'field',NULL,'','','',NULL),(4694,1049,881,'field',NULL,'','','',NULL),(4695,947,916,'support',NULL,'','','',NULL),(4696,529,916,'field',NULL,'','','',NULL),(4697,93,916,'field',NULL,'','','',NULL),(4698,16,916,'field',NULL,'','','',NULL),(4699,273,346,'support',NULL,'','113/9504E','',NULL),(4700,273,491,'support',NULL,'','101255','',NULL),(4701,273,384,'support',NULL,'','103323','',NULL),(4702,273,212,'support',NULL,'','106021','',NULL),(4703,273,194,'support',NULL,'','158/10121','',NULL),(4704,273,478,'support',NULL,'','106006','',NULL),(4705,273,345,'support',NULL,'','106299','',NULL),(4706,273,221,'support',NULL,'','154/10180','',NULL),(4707,273,208,'support',NULL,'','103139','',NULL),(4708,273,219,'support',NULL,'','107885','',NULL),(4709,273,218,'support',NULL,'','103139','',NULL),(4710,1164,830,'field',NULL,'','','',NULL),(4711,405,408,'support',NULL,'','','',NULL),(4712,34,408,'support',NULL,'','','',NULL),(4718,428,917,'support',NULL,'','','',NULL),(4719,739,918,'funding',200000.00,'','','',NULL),(4720,428,918,'funding',435100.00,'','','',NULL),(4721,739,918,'support',NULL,'','','',NULL),(4722,1167,916,'support',NULL,'','','',NULL),(4723,1166,916,'funding',1155181.00,'','','',NULL),(4724,1168,880,'field',NULL,'','','',NULL),(4725,272,408,'sponsor',NULL,'','','',NULL),(4726,52,919,'funding',NULL,'','','',NULL),(4727,726,919,'field',NULL,'','','',NULL),(4728,726,920,'field',NULL,'','','',NULL),(4729,52,920,'funding',NULL,'','','',NULL),(4730,428,918,'support',NULL,'','','',NULL),(4731,1082,810,'field',NULL,'','','',NULL),(4732,1071,810,'support',NULL,'','','',NULL),(4733,273,215,'support',NULL,'','102/10010','',NULL),(4734,273,473,'support',NULL,'','105983','',NULL),(4735,273,510,'support',NULL,'','105519','',NULL),(4736,273,719,'support',NULL,'','108297','',NULL),(4737,273,785,'support',NULL,'','106211','',NULL),(4738,273,590,'support',NULL,'','107277.009','',NULL),(4739,43,674,'funding',9492.00,'','','',NULL),(4740,815,674,'funding',11877.00,'','','',NULL),(4742,1170,880,'support',NULL,'','','',NULL),(4743,43,880,'support',NULL,'','','',NULL),(4744,260,880,'support',NULL,'','','',NULL);
/*!40000 ALTER TABLE `rsr_partnership_copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_partnersite`
--

DROP TABLE IF EXISTS `rsr_partnersite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_partnersite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation_id` int(11) NOT NULL,
  `hostname` varchar(50) NOT NULL,
  `cname` varchar(100) DEFAULT NULL,
  `custom_return_url` varchar(200) NOT NULL,
  `custom_css` varchar(100) NOT NULL,
  `custom_logo` varchar(100) NOT NULL,
  `custom_favicon` varchar(100) NOT NULL,
  `about_box` longtext NOT NULL,
  `about_image` varchar(100) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `default_language` varchar(5) NOT NULL,
  `ui_translation` tinyint(1) NOT NULL,
  `google_translation` tinyint(1) NOT NULL,
  `notes` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hostname` (`hostname`),
  UNIQUE KEY `cname` (`cname`),
  KEY `rsr_partnersite_28b1ef86` (`organisation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_partnersite`
--

LOCK TABLES `rsr_partnersite` WRITE;
/*!40000 ALTER TABLE `rsr_partnersite` DISABLE KEYS */;
INSERT INTO `rsr_partnersite` VALUES (8,360,'commonsites','projects.commonsites.net','http://www.commonsites.net/','db/partner_sites/commonsites/custom_98.css','db/partner_sites/commonsites/logo/CommonSites header.jpg','db/partner_sites/commonsites/favicon.ico','','db/partner_sites/commonsites/image/Projectpage-blok_5.jpg',1,'en',1,0,''),(53,947,'mwawater',NULL,'http://www.mwawater.org/','db/partner_sites/mwawater/custom_26.css','db/partner_sites/mwawater/logo/banner-mwa.jpg','','','db/partner_sites/mwawater/image/blokje-mwa2.jpg',1,'en',1,0,''),(95,912,'srhr',NULL,'http://www.srhralliance.org/','db/partner_sites/srhr/custom_13.css','db/partner_sites/srhr/logo/banner2-SRHR_6.jpg','','','db/partner_sites/srhr/image/blokje-SRHR-1.jpg',1,'en',1,1,'');
/*!40000 ALTER TABLE `rsr_partnersite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_partnertype`
--

DROP TABLE IF EXISTS `rsr_partnertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_partnertype` (
  `id` varchar(8) NOT NULL,
  `label` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_partnertype`
--

LOCK TABLES `rsr_partnertype` WRITE;
/*!40000 ALTER TABLE `rsr_partnertype` DISABLE KEYS */;
INSERT INTO `rsr_partnertype` VALUES ('field','Field partner'),('funding','Funding partner'),('sponsor','Sponsor partner'),('support','Support partner');
/*!40000 ALTER TABLE `rsr_partnertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_paymentgatewayselector`
--

DROP TABLE IF EXISTS `rsr_paymentgatewayselector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_paymentgatewayselector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `paypal_gateway_id` int(11) NOT NULL,
  `mollie_gateway_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`),
  KEY `rsr_paymentgatewayselector_e228d4` (`paypal_gateway_id`),
  KEY `rsr_paymentgatewayselector_1b3a0675` (`mollie_gateway_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1092 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_paymentgatewayselector`
--

LOCK TABLES `rsr_paymentgatewayselector` WRITE;
/*!40000 ALTER TABLE `rsr_paymentgatewayselector` DISABLE KEYS */;
INSERT INTO `rsr_paymentgatewayselector` VALUES (593,613,1,1),(769,789,1,1),(849,869,1,1);
/*!40000 ALTER TABLE `rsr_paymentgatewayselector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_paypalgateway`
--

DROP TABLE IF EXISTS `rsr_paypalgateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_paypalgateway` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `currency` varchar(3) NOT NULL,
  `notification_email` varchar(75) NOT NULL,
  `account_email` varchar(75) NOT NULL,
  `locale` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_paypalgateway`
--

LOCK TABLES `rsr_paypalgateway` WRITE;
/*!40000 ALTER TABLE `rsr_paypalgateway` DISABLE KEYS */;
INSERT INTO `rsr_paypalgateway` VALUES (1,'Default','Default Akvo PayPal account','EUR','thomas@akvo.org','thomas@akvo.org','US'),(2,'GWC','US Dollar PayPal account for GWC projects.','USD','thomas@akvo.org','ahamblin@globalwaterchallenge.org','US');
/*!40000 ALTER TABLE `rsr_paypalgateway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_project`
--

DROP TABLE IF EXISTS `rsr_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `subtitle` varchar(75) NOT NULL,
  `status` varchar(1) NOT NULL,
  `project_plan_summary` longtext NOT NULL,
  `current_image` varchar(100) NOT NULL,
  `current_image_caption` varchar(50) NOT NULL,
  `goals_overview` longtext NOT NULL,
  `current_status` longtext NOT NULL,
  `project_plan` longtext NOT NULL,
  `sustainability` longtext NOT NULL,
  `background` longtext NOT NULL,
  `project_rating` int(11) NOT NULL,
  `notes` longtext NOT NULL,
  `currency` varchar(3) NOT NULL,
  `date_request_posted` date NOT NULL,
  `date_complete` date DEFAULT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `funds` decimal(10,2) DEFAULT NULL,
  `funds_needed` decimal(10,2) DEFAULT NULL,
  `primary_location_id` int(11) DEFAULT NULL,
  `language` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_project_25153470` (`primary_location_id`),
  KEY `rsr_project_36528e23` (`status`),
  KEY `rsr_project_7be581d8` (`title`),
  KEY `rsr_project_30f59932` (`funds`),
  KEY `rsr_project_54b98049` (`funds_needed`),
  KEY `rsr_project_67de8a86` (`budget`)
) ENGINE=MyISAM AUTO_INCREMENT=1112 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_project`
--

LOCK TABLES `rsr_project` WRITE;
/*!40000 ALTER TABLE `rsr_project` DISABLE KEYS */;
INSERT INTO `rsr_project` VALUES (613,'Underwater Cultural Heritage in Vietnam','Raising awareness and building capacity','H','The Bach Dang Battlefield Research Group, in collaboration with the Institute of Archaeology (IA) in Vietnam and together with Nautical Archaeology Society (NAS), Monash University and the Asia Research Centre at Murdoch University will provide NAS training to students and members of local, provincial and national institutions to help Vietnam preserve and protect its underwater cultural heritage. ','db/project/613/Project_613_current_image_2012-09-19_09.15.23.jpg','Bach Dang Research Group underwater survey','The project has three key objectives:\r\n1) Increase awareness of underwater cultural  heritage in Vietnam by increasing local, provincial and national awareness and understanding\r\n2) Capacity building in maritime archaeology and underwater cultural heritage management in Vietnam\r\n3) Establish a Vietnamese version of NAS training that can be used throughout Vietnam\r\n','The capacity building project and awareness raising campaign are part of a larger, on-going research project. Members of the Bach Dang project have conducted preliminary investigations of available historical sources, maps, charts and aerial photographs. This research is complimented by archaeological survey, test excavations and stratigraphic coring at Bach Dang and builds upon pilot studies initiated in 2008 by Dr. Lê Thi Lien of the Institute of Archaeology in Hanoi. Work done at Bach Dang hopes to be spread throughout Vietnam and will continue in Van Don in the near future.','The Bach Dang Battlefield Research project investigates sites where historically significant naval battles took place at which the armies and naval forces of Chinese emperor Kublai Khan were defeated by the Vietnamese in 1288AD. This project is designed to increase awareness at local, provincial and national levels about the extent and nature of Vietnam’s underwater and maritime cultural heritage.\r\n\r\nThis project will capitalise on the presence and experience of international teams of maritime archaeologists and underwater cultural heritage managers as they visit Vietnam on an annual basis for the Bach Dang Battlefield Research project. The Bach Dang project team brings together a team from Australia, USA, Canada and Japan whose primary language for communication and publication is English. \r\n\r\nThis project intends to provide translation of NAS training into the Vietnamese language in order to increase the number of local participants and increase in-country capacity for underwater research, conservation and management. This project will offer field training to members of local, provincial and national organizations and helps raise awareness of Vietnams underwater cultural heritage.   ','Archaeological research at Bach Dang has been supported and conducted by Vietnamese researchers and their partners for more than fifty years. The Bach Dang site and research project has local, provincial and national support guaranteeing sustainability. This awareness raising and capacity building project will form part of this large and on-going research project in Vietnam and is designed to provide the Vietnamese people with the knowledge and capacity to protect and preserve their underwater and maritime cultural heritage in the future.\r\n','The preservation and protection of underwater and maritime cultural heritage in Vietnam has had a low priority. There has been little or no formal teaching of maritime archaeology at universities in Vietnam and only a few government archaeologists have received any training in this subject area primarily by going overseas. We provide underwater (NAS) training to Students and University staff, government archaeologists, cultural heritage officers and local community members.This project is designed to increase awareness at local, provincial and national levels about the extent and nature of Vietnam’s underwater and maritime cultural heritage. \r\n',0,'','EUR','2012-09-17','2014-12-31',12000.00,1249.08,10750.92,696,'en'),(789,'MWA-LAP: Colombia','Replenishment of Water for Sustainable and Healthy Communities','A','Positively impact 8,000 people in La Guajira, Colombia by:\r\n• Installing appropriate water technologies (solar pump, household filters) to improve access and water quality\r\n• Piloting and adapting composting latrines for effective use\r\n• Strengthening Aguayuda’s Mobile WASH Support Service Model to ensure sustainability of clean water\r\n• Providing WASH education to communities and school','db/project/789/Project_789_current_image_2013-06-19_16.36.22.png','','Aguayuda provides clean water, sanitation and education to thousands of vulnerable people in developing countries through the implementation of cost-effective, sustainable water and sanitation solutions. Our work helps build healthy communities where children are able to spend more time in school, and adults have more time to work as well as participate as productive members of the community.','The program has already installed the first community-level water treatment station using SkyHydrant technology, and is set to perform the baseline survey in July 2013.','Component 1 – Install water technologies (solar pump and household filters) to improve access and water quality:\r\nAguayuda has identified 11 Wayúu communities in La Guajira for water supply and quality improvement. For one group of four communities, Aguayuda is partnering with Hybrytec (a Colombian solar company) and Corpoguajira (a Colombian governmental entity) to implement a complete WASH project including a new well, a solar pump, a flexible water tank, LifeStraw Family household filters and composting latrines.\r\n\r\nFor a further seven communities and schools, Aguayuda will provide SkyBox household water filters at strategic locations such as a school, near a water storage tank or hand pump. Whether the water point is a retention pond, river, rain water or well, the SkyBox household filter can purify water to meet WHO standards.\r\n\r\nComponent 2 – Pilot and adapt composting latrines for effective use:\r\nAguayuda has identified 6 Wayúu communities in La Guajira that currently have no sanitation facilities. In the past, water-flush latrines have been installed in various communities in region, but insufficient water supply contributed to their failure. A culture-related problem with the typical latrine design in La Guajira is the housing for the latrines is very narrow and small. Many Wayúu are sensitive to confined spaces and therefore abandon the latrines after a short time.\r\n\r\nTherefore, Aguayuda will pilot the use of \"Loveable Loo\" type composting latrines that save water, are affordable to build, and are sanitary and environmentally friendly when used properly.\r\n\r\nThe sanitation activities for this project also include:\r\n- Implementing the Community Led Total Sanitation (CLTS) methodology\r\n- Designing composting latrines with the community using locally available materials.\r\n- Building composting latrines with the community members to transfer knowledge and to increase community participation and sense of ownership and pride.\r\n- Piloting the use of compost to grow trees in the communities.\r\n\r\nComponent 3 – Strengthen Aguayuda’s Mobile WASH Support Service Model to ensure sustainability of clean water\r\nAguayuda will adapt the Circuit Rider model to create the sustainable Mobile WASH Support Service. The model utilizes mobile technicians and teachers to monitor and maintain a network of Aguayuda’s projects, and educate rural communities on WASH related topics. With the support of Aguayuda, a legal association of the community water committees will be created. This association will empower local communities to effectively organize and work with their government to secure basic services such as water, sanitation, and education.\r\n\r\nComponent 4 – Provide WASH education to communities and schools\r\nAguayuda has identified 20 communities and 3 schools where it will train education committees and teachers to conduct WASH workshops using Aguayuda’s educational materials on the water cycle, clean water, water and disease, handwashing and hygiene, wastewater disposal, water conservation, and water storage.\r\n\r\nAguayuda has created two sets of educational materials: one for instructors and one for students. The instructor’s manual, to be used by teachers, consists of lessons plans with exercises and games. The complimentary student workbook consists of information and activities using mostly pictures with minimal text. Most of the targeted communities have high rates of illiteracy and in general approximately 80% of the Wayúu have not completed primary school. Therefore, Aguayuda created these colorful and easy-to-follow materials to teach the most integral WASH concepts in a way that is easy to comprehend.','The key sustainability provision is the incubation of the Mobile WASH Support Service model, based on the Circuit Rider model. \"Circuit riding\" is the act of traveling to sites within a geographic region. Circuit riding models have experienced challenges in regards to sustainability such as insufficient funding, little government support, unmanagable workloads for technicians, minimal community involvement, high training costs, poor organizational structure, and lack of transparency.\r\n\r\nAguayuda will address these sustainability challenges and adapt the existing model to establish a scalable, sustainable and replicable model for maintaining water projects. The Mobile WASH Support Service model seeks to address these potential pitfalls while bridging the gap between technical hardware implementation, and the systematic culture of monitoring, support, and education, which is imperative for long term sustainability.\r\n\r\nTo address the shortcomings of the circuit riding models, Aguayuda will implement the following improvements:\r\n- Establish clear structure and responsibilities for each component of the model\r\n- Transparency at every level\r\n- Community engagement through WASH fees and representation in the Regional WASH association\r\n- Government engagement through financial support and representation in the Regional WASH association\r\n- Engagement of non-profit organizations through financial support and representation in the Regional WASH association\r\n- Trained Mobile WASH Support Service technicians and teachers\r\n- Continuous monitoring and evaluation of the WASH projects including establishing a baseline of communities\' water, sanitation and education situations\r\n- Internal controls and training for accounting and administration\r\n- Continuous and open communication and interaction between each component\r\n\r\nUltimately, the goal is that the Mobile WASH Support Service model implemented in La Guajira, Colombia will require little to no supervision or financing from Aguayuda. Such a model will empower communities and the local government to manage their own WASH projects, and allows Aguayuda to focus its efforts on new WASH projects. Beyond the prospect of a self-sustaining network of WASH projects, one of the most exciting aspects of Aguayuda’s Mobile WASH Support Service will be the consolidation of community committees established by Aguayuda and others. The consolidation of these committees into one cohesive legal association will empower the unified communities to effectively work with their government to secure basic services such as water, sanitation, and education.','La Guajira is one of the most impoverished regions in Colombia where half of the population lives in rural areas and 9 of 10 live in poverty. La Guajira is the Colombian region with the largest indigenous population, primarily Wayúu.\r\n\r\nThe majority of the population lacks almost all access to basic public services. The most pressing need is access to clean water and sanitation. In La Guajira only 16.3% of the rural population have access to water and the remaining 83.7% are forced to use contaminated distant water sources for human consumption, laundry and bathing, resulting in severe illnesses such as diarrhea, infections, and skin rashes. Additionally, according to national statistics provided by the Public Services of Colombia, only 4% of the population in La Guajira has access to improved sanitation.',0,'','USD','2013-01-31','2015-12-31',399469.00,399469.00,0.00,951,'en'),(869,'Unite for Body Rights, Pakistan','SRHR Alliance','A','Pakistan Alliance for SRHR Movement envisages a society which is fair, safe, and equal for all in the context of SRHR. The UFBR programme is implemented in two districts in Pakistan, namely Multan and Quetta. ','db/project/869/Project_869_current_image_2013-03-14_13.54.34.jpg','Rutgers WPF, Pakistan','1. Increased capacity of young people, women and marginalized groups to make safe and informed decisions on issues concerning relationships and sexuality, to deal with gender power relations and to seek quality, comprehensive SRHR services and information \r\n2. Increased capacity of CSO to manage SRHR education and services interventions\r\n3. Increased quality of and access to comprehensive SRHR and SGBV services for young people, women and marginalised groups.\r\n4. Policy dialogue maintained or increased in favour of SRHR in civil society organisation\'s countries and/or the region','The dance4 life school programme and the Life Skills Based Education programme of Rutgers WPF positively influence each other, combining inspiration, motivation and LSB Education.',' Activities related to Direct Poverty Alleviation: \r\nThe SRHR Alliance will improve access to quality comprehensive sexuality education for young people. Through Life Skills Based Education (LSBE) youth, but particularly girls, will be empowered with knowledge, skills and attitudes needed to make safe choices in matters of sexuality and reproduction. LSBE (electronic and printed) will be made available to young people through the formal public and private education system and through informal religious educational institutions. Three contextualized curricula will be developed to meet the specific needs of these diverse target groups. As parents are the unchallenged stakeholders in socializing their children and passing on essential information and life skills, the UFBR programme will involve parents and communities not only in pressing SRHR issues facing young people (early marriage and sexual harassment), but also on SRHR issues affecting women (unplanned pregnancies, maternal and infant mortality and SGBV). \r\nThe programme will also include an SGBV prevention intervention in all three target districts, with capacity building of partners and CBOs on SGBV using a Toolkit on SGBV and Reproductive Health, developed earlier with World Bank support. To ensure men’s engagement in gender equality, experiences from current collaboration with UNIFEM  and from SRHR-Alliance expertise in male counselling (developed in Indonesia and South Africa)  will be integrated. Awareness raising activities on SGBV will be undertaken in the communities, with parents of young people enrolled in LSBE for a more concentrated approach to changing the socio-cultural and religious norms and values that are so dominant in shaping gender relations in Pakistan. Local media will be involved to report sensitively on the existing situation of SGBV issues in their respective communities. \r\n\r\nStrengthening the formal health system: \r\nTo increase access to and quality of comprehensive SRH services, the UFBR will focus on training healthcare providers on, among others non-judgmental and non-discriminatory attitudes towards young people accessing SRH services and the provision of services to survivors of gender based violence. Service protocols will be developed, and infrastructural improvements to make facilities more youth-friendly will be made . The UFBR programme will work closely with the Marie Stopes Society (MSS), the Family Planning Association of Pakistan (FPAP) in providing services particularly to young people and in training healthcare providers in the public health system in the Quetta and Multan Districts. In Matiari, the SRHR-Alliance will work with MSS, as FPAP’s presence in the district is limited. Moreover, the SRHR Alliance partner in Matiari, HANDS, is involved in several health-related programmes and has a good working relationship with a Health Department that is strongly committed to SRHR. Nevertheless, relationships with all 3 district Health Departments will be strengthened. Under the SGBV component of the UFBR programme, a strong referral system will be developed with service providers (including Pakistan Medical Association, Lawyers Forum, etc.) in project areas to provide comprehensive support to the survivors of violence.\r\n\r\nActivities related to Civil Society Building:\r\nThe UFBR programme will strengthen the capacity \r\nof partner organizations, CSOs, media and governmental agencies involved to ensure continued implementation of SRHR information and services to target groups. The UFBR programme will address CSO weaknesses as pointed out in section 5. More specifically, the capacity of civil society will be strengthened on research, SGBV, advocacy and integration of SRHR in strategic planning. Regular review meetings and exchange visits between different partners (including other Alliances working in Pakistan) will be realized. The programme will also work with religious groups in all three districts to ensure their support and to reach out to the community and grass root level. Groups will be sensitized and involved under the capacity-building component of the programme by building on WPF’s past two years of experience of working with a similar group.\r\n\r\nActivities related to Influencing Policy. \r\nTo create an environment that is more conducive to achieving the above objectives and to ensure sustainability, the SRHR Alliance and Pakistani counterparts will continuously advocate for SRHR. \r\nIn collaboration with PGRN, the Oxfam Novib IMPACT Alliance, UNICEF, UNIFEM, UNFPA and Plan Pakistan, the UFBR programme aims to ensure:\r\n- The inclusion of LSBE/Sexuality Education in the national curriculum of the Ministry of Education; \r\n- The availability of sufficient numbers of trained LSBE teachers and master trainers; \r\n- Availability and accessibility of youth-friendly services; the government’s budget allocation for CSE and services (see also Chapter on sustainability). \r\nAdvocacy will be implemented at national and at district levels. At the district level, the strong linkages with local education and health departments will be used, while linkages with electronic and printed local media will be established in order to raise awareness of SRHR and SGBV among communities. The SRHR Alliance will partner with the Oxfam/Novib IMPACT Alliance to design and carry out a national media campaign on SRHR.  The SRHR Alliance will work with UNFPA’s Youth Advisory Panel (YAP) to create “safe communities” for young people by advocating for including young people’s SRH rights in the national development agenda and to ensure non-judgmental and youth-friendly SRHR services. In collaboration with the Pakistan Alliance for Post Abortion Care (PAPAC), the SRHR Alliance will advocate for raising the minimum marriageable age to 18. Networking building and strengthening are key in this regard and therefore part and parcel of the UFBR programme.','The SRHR Alliance has adopted a planned approach to sustainability to ensure that achieved results will be maintained and further benefits to the target groups will be provided after phase-out of the SRHR Alliance in 2015. First of all programmatic approaches are aimed at embedding programme results. These approaches include aligning wherever possible with government policies, and advocating for the promotion of good SRHR in policy and laws. Secondly, sustainability will be ensured by the processes within the Alliance management, which work towards ownership and commitment of partners and target groups . \r\n\r\nSustainability principles are at the basis of all three intervention strategies in the UFBR programme. \r\nBuilding civil society is geared to sustainable positive SRHR outcomes, through:\r\n\r\nOrganizational development (OD) of partners and other CSOs:\r\nCore element of the UFBR programme is to sufficiently capacitate civil society organizations to facilitate and guide local processes, to maintain the progress made in the UFBR programme and push for additional change. Organizational development of CSOs is particularly necessary in the regions where the Alliance and its partners intervene. These often poorer and needier regions generally have lower institutional density and organizational strength, as well as less progressive societal attitudes. With organizational development the UFBR programme aims to support the Southern partners to such an extent that they become self-sufficient in the mobilization and use of resources and skills to independently design, implement and evaluate quality SRHR programmes . \r\n\r\nInstitutional strengthening: \r\nthe Alliance realizes that it is only in relation to the wider society that CSOs will be able to act as drivers of sustainable change. The UFBR programme will therefore support its partners in strengthening relations with key actors, such as government, local institutions, grass-roots organizations, communities, the private sector and research institutes. Linking and learning meetings, exchange and the establishment of networks are important activities geared towards sustainable outcomes. The UFBR programme has adopted an evidence-based approach. Systemic knowledge generation and documentation of good practices are core components of the country programmes. They provide opportunities for regional sharing and learning from each other’s successes and challenges. With the dissemination of good practices to policy makers and NGOs, the UFBR programme aims to provide opportunities for civil society to upscale successful models to increase impact, cost-effectiveness and sustainability. \r\nIn addition, the Alliance will strengthen the capacity of key stakeholders in knowledge management and research. The Alliance will collaborate with research institutes and universities in several countries, including the Netherlands . This will ensure collection of vital information and evidence on relevant SRHR topics. Documentation, publication and dissemination of lessons learned will demonstrate evidence-based results and support the image of knowledgeable civil society organizations with SRHR expertise.  Evidence-based results are important elements in successfully influencing policy and practice and fostering dialogue on sensitive SRHR issues, and increasing commitment and support for SRHR from key actors. It is also a way to increase the capacity and independence of Southern civil society. CSOs that can clearly demonstrate what works and does not work in their specific context are in the position to make strategic choices and decisions and will be able to strongly advocate for bottom-up approaches, instead of responding to donor-driven programmes.\r\n\r\nInfluencing policy contains the following in-built strategies towards sustainability: \r\nImproved SRHR for women, youth and marginalized groups will only become a sustained reality if there is political and financial commitment for quality SRHR at local, national and international level. Therefore, the UFBR Alliance will advocate for the implementation of government laws and policies to improve SRHR. The UFBR programme will also encourage the integration of SRHR services and education into national and local plans and budgets. The capacity of CSOs will be strengthened to monitor local plans and budgets and they will be supported to advocate for inclusion of comprehensive SRHR services and education in government plans and strategies. The international advocacy component of the UFBR programme is aimed at increased political commitment and resource allocation for SRHR at international and European level, and in the Netherlands. \r\n\r\nDirect Poverty Alleviation is based on the following sustainability principles:\r\n\r\nIntegration of activities in existing structures: \r\nThe UFBR programme will build on existing (community) structures and health and education systems and will work towards integration of comprehensive SRHR into these structures and systems. In, for example, the school-based sexuality education programmes, the Alliance promotes the adoption of comprehensive sexuality education into the school curricula, to ensure that CSE will still be given in schools after phase-out of the UFBR programme. \r\n\r\nStrengthening of systems: \r\nThe long-term impact on positive sexual and reproductive health outcomes largely depends on a well-functioning health system. The UFBR programme therefore focuses on strengthening health systems, ensuring that people, infrastructure and institutions on the ground have sufficient capacity to independently deliver quality SRHR services to the target groups. The UFBR programme will avoid building parallel structures in the health system, but will invest in making the existing health system more effective and responsive to the needs of the target groups. This will be done in compliance with national and international quality standards and local frameworks to ensure follow up by the Ministry of Health and sufficient allocation of human and financial resources by local and national authorities. As such, health systems become less and less dependent on programmes and support of (international) NGOs. \r\n\r\nEmpowerment of communities and people, and working towards gender equality: \r\nSocio-economic, cultural, religious, political, legal and gender barriers limit access to SRH information and services. The implementation and accessibility of services, especially for young people and marginalized groups, will not be sustainable as long as their direct environment does not accept their needs and rights towards these services. The UFBR programme addresses communities, parents, teachers, local authorities, religious and traditional leaders to increase their knowledge about SRHR, their understanding and acceptance of sexual rights for all, and to gain their support for SRHR interventions. The involvement of these stakeholders in the programme will ultimately lead to increased empowerment and motivation to demand sustainable implementation of SRHR services by (local) authorities.','With180 million inhabitants, Pakistan is the sixth largest country in the world. Sixty-four per cent of the population is below the age of 29. Pakistan’s Human Development Index (HDI) is a dismal 0.572, rank 141 out of 182 countries. Pakistan has suffered from decades of internal political disputes and low levels of foreign investment. Between 2001 and 2007, however, poverty levels decreased by 10%, as development spending increased. Growth slowed in 2008-2009, and unemployment rose. A third of the population now lives under the national poverty line, and more than half of the population is illiterate. Population and family planning programmes, including access to reproductive health services, maternal health, child spacing and the prevention of Sexually Transmitted Infections (STIs),  are part of Pakistan’s broad development strategy, However, investments to achieve these goals are insufficient. ',0,'','EUR','2011-01-01','2015-12-31',3038000.00,3038000.00,0.00,1058,'en');
/*!40000 ALTER TABLE `rsr_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_project_categories`
--

DROP TABLE IF EXISTS `rsr_project_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_project_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`,`category_id`),
  KEY `rsr_project_categories_499df97c` (`project_id`),
  KEY `rsr_project_categories_42dc49bc` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28756 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_project_categories`
--

LOCK TABLES `rsr_project_categories` WRITE;
/*!40000 ALTER TABLE `rsr_project_categories` DISABLE KEYS */;
INSERT INTO `rsr_project_categories` VALUES (25288,613,32),(25289,613,33),(25290,613,31),(27820,789,1),(27821,789,2),(27822,789,4),(27823,789,5),(27824,789,38),(27825,789,37),(27080,869,27),(27081,869,28),(27078,869,25),(27079,869,26),(27077,869,16),(27076,869,15),(27075,869,40);
/*!40000 ALTER TABLE `rsr_project_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_projectcomment`
--

DROP TABLE IF EXISTS `rsr_projectcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_projectcomment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` longtext NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_projectcomment_499df97c` (`project_id`),
  KEY `rsr_projectcomment_403f60f` (`user_id`),
  KEY `rsr_projectcomment_3a04cc98` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_projectcomment`
--

LOCK TABLES `rsr_projectcomment` WRITE;
/*!40000 ALTER TABLE `rsr_projectcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `rsr_projectcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_projectlocation`
--

DROP TABLE IF EXISTS `rsr_projectlocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_projectlocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `latitude` double NOT NULL DEFAULT '0',
  `longitude` double NOT NULL DEFAULT '0',
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country_id` int(11) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `primary` tinyint(1) NOT NULL DEFAULT '1',
  `location_target_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_projectlocation_534dd89` (`country_id`),
  KEY `rsr_projectlocation_301caae0` (`location_target_id`),
  KEY `rsr_projectlocation_5264a49a` (`primary`),
  KEY `rsr_projectlocation_761a2bbd` (`longitude`),
  KEY `rsr_projectlocation_63894e45` (`latitude`)
) ENGINE=MyISAM AUTO_INCREMENT=1401 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_projectlocation`
--

LOCK TABLES `rsr_projectlocation` WRITE;
/*!40000 ALTER TABLE `rsr_projectlocation` DISABLE KEYS */;
INSERT INTO `rsr_projectlocation` VALUES (696,20.981957,105.875244,'Hanoi','',43,'Institute of Archaeology building','','',1,613),(697,10.833306,106.66626,'Ho Chi Mon City','',43,'Training Venue 1','','',0,613),(698,15.982454,108.226318,'Da Nang','',43,'Training Venue 2','','',0,613),(951,11.27,-72.718506,'Rioacha','La Guajira',41,'','','',1,789),(1058,30.190189,71.458023,'Multan','',106,'','','',1,869),(1059,30.209459,67.018173,'Quetta','',106,'','','',0,869);
/*!40000 ALTER TABLE `rsr_projectlocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_projectupdate`
--

DROP TABLE IF EXISTS `rsr_projectupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_projectupdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `text` longtext NOT NULL,
  `photo` varchar(100) NOT NULL,
  `photo_location` varchar(1) NOT NULL,
  `photo_caption` varchar(75) NOT NULL,
  `photo_credit` varchar(25) NOT NULL,
  `video` varchar(200) NOT NULL,
  `video_caption` varchar(75) NOT NULL,
  `video_credit` varchar(25) NOT NULL,
  `update_method` varchar(1) NOT NULL,
  `time` datetime NOT NULL,
  `time_last_updated` datetime NOT NULL,
  `language` varchar(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rsr_projectupdate_499df97c` (`project_id`),
  KEY `rsr_projectupdate_403f60f` (`user_id`),
  KEY `rsr_projectupdate_5ca46af3` (`update_method`),
  KEY `rsr_projectupdate_7be581d8` (`title`),
  KEY `rsr_projectupdate_3a04cc98` (`time`),
  KEY `rsr_projectupdate_3e4ff600` (`time_last_updated`)
) ENGINE=MyISAM AUTO_INCREMENT=3264 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_projectupdate`
--

LOCK TABLES `rsr_projectupdate` WRITE;
/*!40000 ALTER TABLE `rsr_projectupdate` DISABLE KEYS */;
INSERT INTO `rsr_projectupdate` VALUES (3258,789,1181,'Baseline Survey with FLOW in Wayuunaiki','Kasiche, Colombia: Isabel, Aguayuda’s bi-lingual teacher, translates the Spanish community survey into Wayuunaiki to be able to communicate with the Wayúu in their native language.','db/project/789/update/3258/ProjectUpdate_3258_photo_2013-07-09_09.42.54.jpg','B','Isabel uses FLOW to the do the community survey.','Kate “Aguacate” Miller','','','','W','2013-07-06 04:11:19','2013-07-09 09:42:54','en'),(3259,613,1181,'New Underwater Archaeology Department! ','I am very happy to inform you that the new Underwater Archaeology Department of the Institute of Archaeology (In Vietnamese: Phòng Khảo cổ học Dưới nước) formally started operations on the 1st July, 2013, with the Decision No. 141/QĐ-KCH, dated the 25th June, 2013 which nominated Dr. Le Thi Lien as Head of the Underwater Archaeology Department.\r\nThe main functions of the Department are:\r\n1) Surveys, rescue excavations and inventory of underwater archaeological sites in Vietnam;\r\n2) Research on underwater archaeological sites and artifacts, and related documents to improve the knowledge on maritime history, history of cultural exchanges and trade on the sea around Vietnam;\r\n3) International cooperation in research and training programs, and in capacity building activities for Vietnamese underwater archaeology;\r\n4) In collaboration with the Journal “Khao co hoc” for the publication of papers on underwater archaeology.','','B','','','','','','W','2013-07-06 15:31:12','2013-07-09 09:43:04','en'),(3263,869,1181,'Outcome Measurement Workshop; June 2013','Outcome Measurement workshop was held on 17-19th June 2013 in PC Karachi. The workshop was attended by programme staff from partner organizations i.e. Quetta, Multan and Rutgers WPF Pakistan. Country Lead Ms. Teun Visser (Rutgers WPF Netherlands), Country Lead Pakistan Mr. Qadeer Baig and Ruth van Zorge, PME Coordination, Rutgers WPF Headquarters were also present in the workshop. ','db/project/869/update/3263/ProjectUpdate_3263_photo_2013-07-09_09.42.39.jpg','E','Outcome Measurement Workshop; June 2013','Rutgers WPF Pakistan','','','','W','2013-07-06 20:09:32','2013-07-09 09:42:39','en');
/*!40000 ALTER TABLE `rsr_projectupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_publishingstatus`
--

DROP TABLE IF EXISTS `rsr_publishingstatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_publishingstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_publishingstatus`
--

LOCK TABLES `rsr_publishingstatus` WRITE;
/*!40000 ALTER TABLE `rsr_publishingstatus` DISABLE KEYS */;
INSERT INTO `rsr_publishingstatus` VALUES (602,613,'published'),(778,789,'published'),(858,869,'published');
/*!40000 ALTER TABLE `rsr_publishingstatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_smsreporter`
--

DROP TABLE IF EXISTS `rsr_smsreporter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_smsreporter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userprofile_id` int(11) NOT NULL,
  `gw_number_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userprofile_id` (`userprofile_id`,`gw_number_id`,`project_id`),
  KEY `rsr_smsreporter_1be3128f` (`userprofile_id`),
  KEY `rsr_smsreporter_76b546c1` (`gw_number_id`),
  KEY `rsr_smsreporter_499df97c` (`project_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_smsreporter`
--

LOCK TABLES `rsr_smsreporter` WRITE;
/*!40000 ALTER TABLE `rsr_smsreporter` DISABLE KEYS */;
/*!40000 ALTER TABLE `rsr_smsreporter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rsr_userprofile`
--

DROP TABLE IF EXISTS `rsr_userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rsr_userprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `organisation_id` int(11) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `validation` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `rsr_userprofile_28b1ef86` (`organisation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1178 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rsr_userprofile`
--

LOCK TABLES `rsr_userprofile` WRITE;
/*!40000 ALTER TABLE `rsr_userprofile` DISABLE KEYS */;
/*!40000 ALTER TABLE `rsr_userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `south_migrationhistory`
--

DROP TABLE IF EXISTS `south_migrationhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `south_migrationhistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(255) NOT NULL,
  `migration` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `south_migrationhistory`
--

LOCK TABLES `south_migrationhistory` WRITE;
/*!40000 ALTER TABLE `south_migrationhistory` DISABLE KEYS */;
INSERT INTO `south_migrationhistory` VALUES (1,'oembed','0001_initial','2012-02-02 11:18:03'),(2,'ipn','0001_first_migration','2012-02-02 11:18:05'),(3,'rsr','0001_initial','2012-02-02 11:18:06'),(4,'rsr','0002_auto__add_projectpartner','2012-02-02 11:18:13'),(5,'rsr','0003_auto__chg_field_projectpartner_funding_amount','2012-02-02 11:18:13'),(6,'rsr','0004_refactor_project_partners','2012-02-02 11:18:24'),(7,'rsr','0005_auto__del_fieldpartner__del_supportpartner__del_sponsorpartner__del_fu','2012-02-02 11:18:25'),(8,'rsr','0006_rename_projectpartner_to_partnership','2012-02-02 11:18:26'),(9,'rsr','0007_auto__add_budgetitemlabel__add_field_budgetitem_label__add_field_budge','2012-02-29 12:43:44'),(10,'rsr','0008_dynamic_budget_item_labels','2012-02-29 12:43:54'),(11,'rsr','0009_auto__del_field_budgetitem_item__chg_field_budgetitem_label','2012-02-29 12:43:55'),(12,'rsr','0010_project_field_name_changes','2012-05-15 16:02:42'),(13,'rsr','0011_auto__add_goal','2012-05-15 16:02:42'),(14,'rsr','0012_migrate_goals_data','2012-05-15 16:02:51'),(15,'rsr','0013_auto__del_field_project_goal_2__del_field_project_goal_3__del_field_pr','2012-05-15 16:02:51'),(16,'rsr','0014_auto__add_field_project_budget__add_field_project_funds__add_field_pro','2012-06-08 12:37:48'),(17,'rsr','0015_populate_denorm_project_fields','2012-06-08 12:37:58'),(18,'rsr','0016_auto__del_field_projectupdate_featured__add_field_partnersite_default_','2012-06-08 12:37:58'),(19,'rsr','0017_auto__add_projectlocation__add_organisationlocation__add_field_project','2012-08-06 19:10:05'),(20,'rsr','0018_locations_migration','2012-08-06 19:10:50'),(21,'rsr','0019_auto__del_location','2012-08-06 19:10:51'),(22,'rsr','0020_auto__chg_field_organisation_primary_location__chg_field_project_prima','2012-08-06 19:10:51'),(23,'rsr','0021_double_newlines_for_markdown','2012-08-06 19:11:06'),(24,'rsr','0022_auto__add_field_partnership_iati_id','2012-09-17 12:55:26'),(25,'rsr','0023_auto__add_field_organisation_iati_id','2012-09-17 12:55:26'),(26,'rsr','0024_auto__del_field_organisation_iati_id__add_field_organisation_iati_org_','2012-09-17 12:55:27'),(28,'tastypie','0001_initial','2012-09-17 12:59:57'),(29,'rsr','0025_auto__create_indexes','2012-12-13 09:39:22'),(30,'rsr','0026_auto__add_field_partnership_iati_url','2012-12-13 09:39:23'),(31,'rsr','0027_auto__add_field_partnership_partner_type_extra','2012-12-13 09:39:23'),(32,'rsr','0028_auto__add_field_partnersite_ui_translation__add_field_partnersite_goog','2013-03-06 11:52:54'),(33,'rsr','0029_auto__add_field_organisation_language__add_field_project_language__add','2013-03-06 11:52:55'),(34,'rsr','0030_auto__add_field_organisation_new_organisation_type','2013-03-06 11:52:56'),(35,'rsr','0031_set_iati_org_types','2013-03-06 11:53:05'),(36,'tastypie','0002_add_apikey_index','2013-03-07 00:35:26'),(37,'djcelery','0001_initial','2013-03-07 00:36:14'),(38,'djcelery','0002_v25_changes','2013-03-07 00:36:14'),(39,'djcelery','0003_v26_changes','2013-03-07 00:36:14'),(40,'djcelery','0004_v30_changes','2013-03-07 00:36:14'),(41,'django','0001_initial','2013-03-07 00:36:34'),(42,'rsr','0032_set_empty_iati_org_id_to_null','2013-06-25 15:59:17'),(43,'rsr','0033_auto__add_internalorganisationid__add_unique_internalorganisationid_re','2013-06-25 15:59:19'),(44,'rsr','0034_cordaid_internal_orgs','2013-06-25 15:59:20'),(45,'rsr','0035_auto__chg_field_benchmarkname_name','2013-06-25 15:59:21'),(46,'rsr','0036_auto__add_field_partnersite_notes','2013-07-09 09:39:35'),(47,'rsr','0037_auto__add_partnertype','2013-07-09 09:39:36'),(48,'rsr','0038_limit_org_partner_types','2013-07-09 09:40:07');
/*!40000 ALTER TABLE `south_migrationhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tastypie_apiaccess`
--

DROP TABLE IF EXISTS `tastypie_apiaccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tastypie_apiaccess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `request_method` varchar(10) NOT NULL DEFAULT '',
  `accessed` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tastypie_apiaccess`
--

LOCK TABLES `tastypie_apiaccess` WRITE;
/*!40000 ALTER TABLE `tastypie_apiaccess` DISABLE KEYS */;
/*!40000 ALTER TABLE `tastypie_apiaccess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tastypie_apikey`
--

DROP TABLE IF EXISTS `tastypie_apikey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tastypie_apikey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `key` varchar(256) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '2012-09-17 12:59:57',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=505 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tastypie_apikey`
--

LOCK TABLES `tastypie_apikey` WRITE;
/*!40000 ALTER TABLE `tastypie_apikey` DISABLE KEYS */;
INSERT INTO `tastypie_apikey` VALUES (504,1181,'f4d23fcf7af559a5a06b55bbc44808d5843e681f','2013-07-09 09:56:17');
/*!40000 ALTER TABLE `tastypie_apikey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_state`
--

DROP TABLE IF EXISTS `workflows_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `workflow_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `workflows_state_26cddbc7` (`workflow_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_state`
--

LOCK TABLES `workflows_state` WRITE;
/*!40000 ALTER TABLE `workflows_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_state_transitions`
--

DROP TABLE IF EXISTS `workflows_state_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_state_transitions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_id` int(11) NOT NULL,
  `transition_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `state_id` (`state_id`,`transition_id`),
  KEY `workflows_state_transitions_469f723e` (`state_id`),
  KEY `workflows_state_transitions_78d221b3` (`transition_id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_state_transitions`
--

LOCK TABLES `workflows_state_transitions` WRITE;
/*!40000 ALTER TABLE `workflows_state_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_state_transitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_stateinheritanceblock`
--

DROP TABLE IF EXISTS `workflows_stateinheritanceblock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_stateinheritanceblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `workflows_stateinheritanceblock_469f723e` (`state_id`),
  KEY `workflows_stateinheritanceblock_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_stateinheritanceblock`
--

LOCK TABLES `workflows_stateinheritanceblock` WRITE;
/*!40000 ALTER TABLE `workflows_stateinheritanceblock` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_stateinheritanceblock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_stateobjectrelation`
--

DROP TABLE IF EXISTS `workflows_stateobjectrelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_stateobjectrelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) DEFAULT NULL,
  `content_id` int(10) unsigned DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`content_id`,`state_id`),
  KEY `workflows_stateobjectrelation_1bb8f392` (`content_type_id`),
  KEY `workflows_stateobjectrelation_469f723e` (`state_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_stateobjectrelation`
--

LOCK TABLES `workflows_stateobjectrelation` WRITE;
/*!40000 ALTER TABLE `workflows_stateobjectrelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_stateobjectrelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_statepermissionrelation`
--

DROP TABLE IF EXISTS `workflows_statepermissionrelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_statepermissionrelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `workflows_statepermissionrelation_469f723e` (`state_id`),
  KEY `workflows_statepermissionrelation_1e014c8f` (`permission_id`),
  KEY `workflows_statepermissionrelation_40f80fc0` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_statepermissionrelation`
--

LOCK TABLES `workflows_statepermissionrelation` WRITE;
/*!40000 ALTER TABLE `workflows_statepermissionrelation` DISABLE KEYS */;
INSERT INTO `workflows_statepermissionrelation` VALUES (1,1,2,2),(3,3,2,2),(4,4,2,2),(5,1,1,1),(7,3,1,1);
/*!40000 ALTER TABLE `workflows_statepermissionrelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_transition`
--

DROP TABLE IF EXISTS `workflows_transition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_transition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `workflow_id` int(11) NOT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `condition` varchar(100) NOT NULL,
  `permission_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflows_transition_26cddbc7` (`workflow_id`),
  KEY `workflows_transition_6f5f66fb` (`destination_id`),
  KEY `workflows_transition_1e014c8f` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_transition`
--

LOCK TABLES `workflows_transition` WRITE;
/*!40000 ALTER TABLE `workflows_transition` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_transition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_workflow`
--

DROP TABLE IF EXISTS `workflows_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_workflow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `initial_state_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `workflows_workflow_7b0b2bbd` (`initial_state_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_workflow`
--

LOCK TABLES `workflows_workflow` WRITE;
/*!40000 ALTER TABLE `workflows_workflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_workflowmodelrelation`
--

DROP TABLE IF EXISTS `workflows_workflowmodelrelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_workflowmodelrelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) NOT NULL,
  `workflow_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`),
  KEY `workflows_workflowmodelrelation_26cddbc7` (`workflow_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_workflowmodelrelation`
--

LOCK TABLES `workflows_workflowmodelrelation` WRITE;
/*!40000 ALTER TABLE `workflows_workflowmodelrelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_workflowmodelrelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_workflowobjectrelation`
--

DROP TABLE IF EXISTS `workflows_workflowobjectrelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_workflowobjectrelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) DEFAULT NULL,
  `content_id` int(10) unsigned DEFAULT NULL,
  `workflow_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`content_id`),
  KEY `workflows_workflowobjectrelation_1bb8f392` (`content_type_id`),
  KEY `workflows_workflowobjectrelation_26cddbc7` (`workflow_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_workflowobjectrelation`
--

LOCK TABLES `workflows_workflowobjectrelation` WRITE;
/*!40000 ALTER TABLE `workflows_workflowobjectrelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_workflowobjectrelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows_workflowpermissionrelation`
--

DROP TABLE IF EXISTS `workflows_workflowpermissionrelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows_workflowpermissionrelation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workflow_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workflow_id` (`workflow_id`,`permission_id`),
  KEY `workflows_workflowpermissionrelation_26cddbc7` (`workflow_id`),
  KEY `workflows_workflowpermissionrelation_1e014c8f` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows_workflowpermissionrelation`
--

LOCK TABLES `workflows_workflowpermissionrelation` WRITE;
/*!40000 ALTER TABLE `workflows_workflowpermissionrelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows_workflowpermissionrelation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-07-09  8:08:43
